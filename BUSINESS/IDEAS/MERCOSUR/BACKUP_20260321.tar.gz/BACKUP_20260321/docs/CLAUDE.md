# CLAUDE.md - MERCOSUR-EU Agreement Profit Opportunities

## Agreement Status (as of March 2026)

| Milestone | Date |
| Political agreement | Dec 6, 2024 |
| Council approval | Jan 9, 2026 |
| Signature | Jan 17, 2026 |
| Argentina ratification | Feb 26, 2026 |
| Uruguay ratification | Feb 27, 2026 |
| Brazil approval | Mar 4, 2026 |
| Paraguay ratification | Mar 17, 2026 |
| Expected provisional application | May 1, 2026 |
| EU Parliament CJEU referral | Jan 21, 2026 (18-24 months delay) |

**Bottom line:** Provisional application starting May 2026. Full ratification may take years due to CJEU review.

## Market Scale

- 700-780 million consumers
- 30% of global GDP
- 91% of EU goods get tariff elimination
- EU saves EUR 4 billion/year in tariffs
- 600,000+ EU jobs supported by Mercosur exports

## Who's Winning

| Winner | Why |
| German auto industry | 35% tariff on cars eliminated |
| EU wine/spirits producers | 35% tariff reduction |
| EU machinery exporters | 14-20% tariff cuts |
| EU pharma | 14% tariff elimination |
| Critical raw materials traders | Secure access to lithium, niobium |
| Brazilian/Argentine beef producers | 99K tonnes at 7.5% duty |
| South American soy/sugar exporters | New quotas into EU |

## Who's Losing

| Loser | Why |
| EU beef farmers | 99K tonnes competition at lower costs |
| EU poultry farmers | 180K tonnes quota duty-free |
| EU sugar producers | Competition from Brazil |
| Small EU farmers | Lower production standards abroad |
| Amazon rainforest (critics say) | Deforestation incentives |

---

## PROFIT OPPORTUNITIES FOR TUDOR

### TIER 1: Leverage Existing Infrastructure (Low Risk)

#### 1. Workforce Recruitment for EU Companies Exporting to Mercosur

Your InterJob system is already built for B2B recruitment. New angle:

- EU automotive/machinery companies expanding Mercosur operations need local staff
- EU companies opening Brazil/Argentina offices need bilingual workers
- Mercosur companies opening EU branches need workforce
- Target: German auto suppliers, Spanish machinery exporters, Italian food processors

**Action:** Add "Mercosur expansion support" service to existing recruitment emails. Database of companies exporting to South America.

#### 2. Import Agent/Broker for Romanian Companies

Romania voted FOR the agreement. 250 Romanian companies already export to Mercosur. New opportunity:

- Help Romanian SMEs navigate import/export procedures
- Broker connections between Romanian buyers and Mercosur suppliers
- Focus: agricultural machinery parts, chemicals, IT services

**Action:** Build database of Romanian companies trading with Mercosur. Offer consultation services.

### TIER 2: Trading Company (Medium Risk)

#### 3. Critical Raw Materials Broker

EU is 82% dependent on Mercosur for niobium, 79% for lithium. The EU Critical Raw Materials Act creates demand.

- Small-scale: Connect EU battery/tech manufacturers with Brazilian niobium suppliers
- Not physical trading initially - broker relationships for commission
- Target: Romanian/EU small manufacturers needing raw materials

**Action:** Research Brazilian lithium/niobium exporters. Build contact database. Offer sourcing services.

#### 4. Agricultural Product Import (Cooperative Model)

Form or join a cooperative to import under the new quotas:

| Product | Quota | Duty |
| Beef | 99K tonnes | 7.5% |
| Poultry | 180K tonnes | 0% (phased) |
| Honey | 45K tonnes | 0% (phased) |

**Cooperative advantage:** Pool resources, share import licenses, distribute risk.

**Action:** Research Romanian food import cooperatives. Contact existing honey/meat importers about partnership.

### TIER 3: Export to Mercosur (Higher Effort)

#### 5. Romanian Protected Products Export

15 Romanian geographical indications are protected under the agreement:

- Research which 15 products are protected
- Help Romanian producers export to Brazil/Argentina
- Commission-based export facilitation

**Action:** Get list of protected Romanian GIs from Ministry of Agriculture.

#### 6. IT/Digital Services Export

Agreement includes provisions for digital services. Romania has strong IT sector.

- Help Romanian IT companies bid on Mercosur government contracts
- Brazil federal procurement alone: EUR 8 billion/year
- Romanian IT outsourcing to Brazilian/Argentine companies

**Action:** Research Brazilian government procurement portal (ComprasNet).

---

## COOPERATIVE STRUCTURE OPTIONS

### Option A: Import Cooperative (Recommended)

```
Structure: Cooperativa Agricola or Societate Cooperativa
Members: 5-10 food importers/distributors
Focus: Honey, beef, specialty foods
Advantages:
- Shared import licenses
- Pooled capital for larger orders
- Risk distribution
- Collective bargaining power
```

### Option B: Export Consortium

```
Structure: Consortium agreement (not formal cooperative)
Members: Romanian producers of wine, spirits, machinery
Focus: Joint marketing in Mercosur
Advantages:
- Shared marketing costs
- Combined logistics
- Single point of contact for Mercosur buyers
```

### Option C: Trading Company (SRL)

```
Structure: Standard SRL
Focus: Brokerage/agency services
Services:
- Match EU buyers with Mercosur suppliers
- Handle documentation/compliance
- Commission: 3-5% of transaction value
Advantages:
- Lower capital requirement
- Flexible scope
- Can pivot based on market
```

---

## REQUIREMENTS & COMPLIANCE

### Deforestation-Free Products (EUDR)

Starting end of 2026, EU requires deforestation-free certification for:
- Soy, beef, palm oil, wood, cocoa, coffee, rubber

**Implication:** Any import must have traceability documentation.

### Food Safety Standards

EU maintains same standards - no exceptions for Mercosur.
- Hormone-free beef required
- Pesticide limits apply
- Only 1,220 Brazilian farms currently EU-approved

### Rules of Origin

Products must prove origin in EU or Mercosur to get preferential tariffs. Documentation critical.

---

## QUICK START ACTIONS

### Week 1-2
1. Research Romanian companies trading with Mercosur (Chamber of Commerce data)
2. Get list of 15 protected Romanian GIs
3. Contact Romanian honey importers about cooperative interest

### Month 1
4. Build database of Brazilian/Argentine suppliers (niobium, honey, specialty foods)
5. Draft cooperative agreement template
6. Research import licensing requirements in Romania

### Month 2-3
7. Reach out to 50 potential cooperative members
8. Create pitch deck for import/export services
9. Register trading company if proceeding solo

---

## SOURCES

### Agreement & Policy
- [EU-Mercosur Agreement - European Commission](https://commission.europa.eu/topics/trade/eu-mercosur-trade-agreement_en)
- [Council Press Release - Jan 9, 2026](https://www.consilium.europa.eu/en/press/press-releases/2026/01/09/eu-mercosur-council-greenlights-signature-of-the-comprehensive-partnership-and-trade-agreement/)
- [EU Trade - Mercosur Factsheets](https://policy.trade.ec.europa.eu/eu-trade-relationships-country-and-region/countries-and-regions/mercosur/eu-mercosur-agreement_en)
- [Romania-Mercosur Trade Statistics](https://policy.trade.ec.europa.eu/eu-trade-relationships-country-and-region/countries-and-regions/mercosur/eu-mercosur-trade-your-town/romania-mercosur-trade-your-town_en)

### Deals & Investments
- [Stellantis EUR 5.6B Investment](https://www.stellantis.com/en/news/press-releases/2024/march/stellantis-announces-5-6-billion-investment-in-south-america-marking-the-largest-investment-in-the-region-s-automotive-industry)
- [VW $580M Argentina Investment](https://finance.yahoo.com/news/vw-invests-580m-argentina-launch-163238258.html)
- [VW EUR 1B South America Plan](https://www.volkswagen-newsroom.com/en/press-releases/volkswagen-to-invest-some-1-billion-by-2026-south-america-region-to-be-geared-to-sustained-profitability-7592)
- [Minerva-Marfrig Acquisition](https://www.meatpoultry.com/articles/31011-minerva-completes-acquisition-of-marfrig-assets)
- [JBS European Expansion Plans](https://www.thebeefsite.com/news/jbs-eyes-european-meat-market-for-acquisitions)
- [Carrefour Brazil Buyout](https://ionanalytics.com/insights/mergermarket/european-outbound-ma-into-brazil-set-for-boost-if-trade-accord-lands-dealspeak-emea/)

### Critical Materials
- [Brazil Lithium/Rare Earths - Fastmarkets](https://www.fastmarkets.com/insights/eu-mercosur-agreement-boost-brazil-strategic-supplier-lithium-rare-earths/)
- [Critical Raw Materials - ECIPE Analysis](https://ecipe.org/publications/trade-diversification-the-role-of-mercosur/)
- [European Mining Investment - MiningSEE](https://www.miningsee.eu/europe-expands-critical-minerals-strategy-into-brazil-to-secure-lithium-nickel-copper-supply-chains/)

### Market Analysis
- [Beef Export Shifts - Fastmarkets](https://www.fastmarkets.com/insights/eu-mercosur-deal-boost-for-beef-exporters-minor-shifts-for-grains/)
- [Wine Trade Outlook - Vinetur](https://www.vinetur.com/en/amp/2026021296281/european-wines-set-to-drop-in-price-as-mercosur-eu-trade-deal-nears-implementation.html)
- [Farmer Protests - Al Jazeera](https://www.aljazeera.com/news/2025/12/18/angry-farmers-block-brussels-roads-with-tractors-over-mercosur-trade-deal)

---

## DEALS ALREADY DONE (2025-2026)

### AUTOMOTIVE SECTOR - EUR 7+ billion committed

| Company | Investment | Location | Details |
| Stellantis | EUR 5.6B | Brazil/Argentina | Largest ever in SA automotive |
| Stellantis | R$13B (~$2.5B) | Goiana, Brazil | 4 new bio-hybrid models |
| Stellantis | $270M | El Palomar, Argentina | New Peugeot 2008 SUV |
| Volkswagen | EUR 1B | South America | 15 new EV/flex models by 2025 |
| Volkswagen | $570M | Parana, Brazil | Tukan pickup production |
| Volkswagen | $580M | Pacheco, Argentina | Next-gen Amarok 2027 |

**Takeaway:** German/French automakers betting big on SA. Supply chain opportunities.

### RETAIL & M&A - $2+ billion in transactions

| Deal | Value | Buyer | Target | Status |
| Carrefour Brazil buyout | ~$1B | Carrefour France | Minority shares | Completed 2025 |
| Atacadao take-private | EUR 943M | Carrefour | Brazilian wholesaler | Feb 2025 |
| Minerva-Marfrig plants | R$5.68B ($1.1B) | Minerva | 16 meat plants | Completed 2025 |

**Takeaway:** European retail consolidating in Brazil. Meat industry consolidating.

### CRITICAL RAW MATERIALS - EUR 71-74B pipeline

| Development | Companies | Status |
| Brazil mining pipeline 2026-2030 | Various | EUR 71-74B planned |
| European investor coalition | 5+ funds | Early 2026 equity stakes |
| Sigma Lithium supply deal | Sigma | 150K tonnes at $140/t |
| Stellantis lithium stake | Argentina Litio | 19.9% stake acquired |

**Brazilian lithium producers:** Sigma Lithium, CBL, AMG (3 operational + 25 projects)

### BEEF TRADE - Major market disruption

| Event | Impact |
| US 50% tariff (Trump) | Brazil/Argentina pivot from US market |
| China 55% safeguard tariff | Quota limited to 1M tonnes |
| EU-Mercosur 99K tonnes | 7.5% duty - more attractive |
| Minerva record profit | R$848M ($162M) FY2025 |

**JBS expansion:** Actively seeking European meat acquisitions.

### WINE & SPIRITS - 344 GIs protected

| Metric | Data |
| Tariff cuts starting | June 2026 |
| Products affected | 5,000+ |
| EU GIs protected | 344 |
| Brazil wine imports 2024 | $518M (65% of Latin America) |

---

## RISKS & MITIGATION

| Risk | Mitigation |
| CJEU delays | Focus on provisional application sectors |
| Farmer opposition | Avoid direct competition with EU farmers |
| Deforestation compliance | Only work with certified suppliers |
| Currency volatility | Use EUR-denominated contracts |
| Logistics complexity | Partner with established forwarders |

---

## RELATED PROJECTS

- `/opt/ACTIVE/EU_FUNDING/` - EU funding consultancy
- `/opt/ACTIVE/SCRAPERS/` - Company data scraping
- `/opt/ACTIVE/EMAIL/CAMPAIGNS/` - Email outreach infrastructure

## NEXT RESEARCH

- [ ] List of 15 protected Romanian GIs under agreement
- [ ] Brazilian government procurement portal registration
- [ ] Romanian cooperative registration requirements
- [ ] Existing Romanian-Mercosur trade associations
- [ ] EU funding for SME export development

---

## Z.AI EXPLORATION BRIEF

See: `./CLAUDE/EXPLORE_TRADE_OPPORTUNITIES.md`

Research tasks assigned:
1. **Mercosur-EU** - Exporter databases, matching with TED winners
2. **Canada-EU (CETA)** - Tudor is Canadian, leverage dual access
3. **Romania agreements** - What Romania-specific advantages exist
4. **Canada agreements** - CETA + USMCA + CPTPP arbitrage
5. **Synthesis** - Rank all opportunities, propose first move

Core insight: Tudor has EU BUYER data (1.57M TED winners).
Need: SELLER data from trade agreement partners.
Model: Broker/matchmaker, commission-based.

---

## Implementation Directory

All implementation code and working files are located in:

| Type | Path |
| Implementation | `./CLAUDE/OPENCODE/` |
| Templates | `./CLAUDE/OPENCODE/campaigns/templates/` |
| Scrapers | `./CLAUDE/OPENCODE/scrapers/` |
| Docs | `./CLAUDE/OPENCODE/*.md` |
| Data | `./CLAUDE/OPENCODE/data/` |
| Matchers | `./CLAUDE/OPENCODE/matchers/` |
| Reports | `./CLAUDE/OPENCODE/reports/` |

---

## DEPLOYED WEBSITES (March 2026)

Three Mercosur category pages deployed as subfolders:

### Live URLs

| Site | URL | Purpose |
| Raw Materials | https://aluminumrecyclehub.com/mercosur/ | Lithium, niobium sourcing |
| Raw Materials | https://aluminumrecyclehub.com/mercosur/suppliers.html | 9 verified suppliers |
| Agriculture | https://agroevolution.com/mercosur/ | Beef, honey, poultry trade |
| Agriculture | https://agroevolution.com/mercosur/suppliers.html | 10 verified suppliers |
| Jobs | https://interjob.ro/mercosur/ | EU-Mercosur trade jobs |

### Main Sites Unchanged
- aluminumrecyclehub.com - "We Buy Aluminum Scrap"
- agroevolution.com - "Farms for sale"
- interjob.ro - "InterJob Solutions Europe"

### Local Source Files
```
/opt/ACTIVE/IDEAS/MERCOSUR/websites/
├── aluminumrecyclehub/
│   ├── index.html          # Raw materials landing
│   └── suppliers.html      # 6 lithium + 3 niobium suppliers
├── agroevolution/
│   ├── index.html          # Agriculture landing
│   └── suppliers.html      # 5 beef + 5 honey suppliers
├── interjob-mercosur/
│   └── index.html          # Trade jobs board
└── suppliers.json          # Master supplier data
```

### Supplier Directory (19 verified)

**Lithium (6):**
- Livent Corporation (Argentina) - 25K t/yr
- Allkem/Olaroz (Argentina) - 42.5K t/yr
- Arcadium Lithium (Argentina) - 75K t/yr
- Sigma Lithium (Brazil) - 104K t/yr, carbon neutral
- CBL (Brazil) - 6K t/yr
- AMG Lithium (Brazil) - 90K t/yr

**Niobium (3):**
- CBMM (Brazil) - 100K t/yr, 80% global supply
- CMOC/Niobras (Brazil) - 9.5K t/yr
- Mineracao Taboca (Brazil) - 2K t/yr

**Beef (5):**
- JBS S.A. (Brazil) - 37 EU-approved plants
- Minerva Foods (Brazil) - Record EUR 162M profit
- Marfrig (Brazil)
- Frigorifico Gorina (Argentina) - Hilton quota
- INAC Members (Uruguay) - 40+ plants, 100% traceable

**Honey (5):**
- NEXCO (Argentina) - 15K t/yr, organic
- Mieles del Sur (Argentina) - Patagonia, 5K t/yr
- Cooperativa COSAR (Argentina) - 3K t/yr
- Urucoop (Uruguay) - 2K t/yr
- CONAP Brazil - 8K t/yr

### Pending
- [ ] Set up Formspree/PHP for lead capture forms
- [ ] Add navigation links from main sites
- [ ] Configure mercosur.interjob.ro subdomain redirect
