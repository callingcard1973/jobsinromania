#!/usr/bin/env python3
"""
Colombia RUES/datos.gov.co Company Import
Downloads and imports Colombian company data.

Sources:
- datos.gov.co - Open data portal (CKAN)
- RUES - Business registry (Registro Unico Empresarial y Social)
- SECOP - Procurement portal

Usage:
    python3 colombia_rues.py --stats           # Show stats
    python3 colombia_rues.py --download        # Download data
    python3 colombia_rues.py --import          # Import to DB
"""

import sys
import json
import csv
import requests
from pathlib import Path
from typing import Iterator, Optional
import logging

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from base import (
    Company, ProcurementAward, get_db, insert_companies,
    insert_procurement_awards, parse_date, parse_float,
    sanitize, log, BATCH_SIZE
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Directories
DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/colombia')
DATA_DIR.mkdir(parents=True, exist_ok=True)

# datos.gov.co CKAN API
CKAN_API = "https://www.datos.gov.co/api/3/action/"

# Alternative: Socrata API (datos.gov.co uses Socrata)
SOCRATA_API = "https://www.datos.gov.co/resource/"

# Key dataset IDs on Socrata
SOCRATA_DATASETS = {
    'empresas_activas': 'xzkq-t4a3',  # Example ID
    'secop_contratos': 'jbjy-vk9h',   # SECOP II contracts
}

# Key searches for CKAN
DATASETS = {
    'empresas': {
        'search': 'empresas',
        'description': 'Registered companies',
    },
    'nit': {
        'search': 'NIT',
        'description': 'Tax ID registry',
    },
    'secop': {
        'search': 'SECOP contratacion',
        'description': 'Public procurement',
    },
    'camaras': {
        'search': 'camaras comercio',
        'description': 'Chamber of commerce',
    }
}


def search_datasets(query: str = "empresas") -> list:
    """Search for datasets on datos.gov.co."""
    url = f"{CKAN_API}package_search"
    params = {'q': query, 'rows': 50}

    try:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()
        if data.get('success'):
            return data['result']['results']
    except Exception as e:
        logger.error(f"Search error: {e}")

    return []


def get_dataset_resources(dataset_id: str) -> list:
    """Get resources (files) for a dataset."""
    url = f"{CKAN_API}package_show"
    params = {'id': dataset_id}

    try:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()
        if data.get('success'):
            return data['result'].get('resources', [])
    except Exception as e:
        logger.error(f"Dataset error: {e}")

    return []


def fetch_socrata_dataset(dataset_id: str, limit: int = 10000, offset: int = 0) -> list:
    """Fetch data from Socrata API."""
    url = f"{SOCRATA_API}{dataset_id}.json"
    params = {
        '$limit': limit,
        '$offset': offset
    }

    try:
        resp = requests.get(url, params=params, timeout=60)
        return resp.json()
    except Exception as e:
        logger.error(f"Socrata error: {e}")
        return []


def download_resource(resource: dict, output_dir: Path) -> Optional[Path]:
    """Download a CKAN resource."""
    url = resource.get('url')
    name = resource.get('name', 'data')
    fmt = resource.get('format', 'csv').lower()

    if not url:
        return None

    filename = f"{name}.{fmt}".replace(' ', '_').replace('/', '_')
    filepath = output_dir / filename

    if filepath.exists():
        logger.info(f"  {filename} exists, skipping")
        return filepath

    logger.info(f"  Downloading {filename}...")

    try:
        resp = requests.get(url, timeout=120, stream=True)
        resp.raise_for_status()

        with open(filepath, 'wb') as f:
            for chunk in resp.iter_content(chunk_size=8192):
                f.write(chunk)

        return filepath

    except Exception as e:
        logger.error(f"Download error: {e}")
        return None


def parse_company_row(row: dict) -> Optional[Company]:
    """Parse Colombia company CSV row."""
    # NIT (Numero de Identificacion Tributaria) - format: XXX.XXX.XXX-X
    nit = row.get('nit', '').strip() or row.get('NIT', '').strip()
    name = row.get('razon_social', '').strip() or row.get('nombre', '').strip() or row.get('nombre_empresa', '').strip()

    if not name:
        return None

    # Clean NIT
    if nit:
        nit = ''.join(c for c in nit if c.isdigit() or c == '-')
        # Remove check digit if present
        if '-' in nit:
            nit = nit.split('-')[0]

    # Address
    direccion = row.get('direccion', '').strip() or row.get('domicilio', '').strip()
    municipio = row.get('municipio', '').strip() or row.get('ciudad', '').strip()
    departamento = row.get('departamento', '').strip()

    # Activity (CIIU code)
    actividad = row.get('actividad_economica', '').strip() or row.get('actividad', '').strip()
    codigo_ciiu = row.get('codigo_ciiu', '').strip() or row.get('ciiu', '').strip()

    # Employees
    empleados = row.get('numero_empleados', '')
    if empleados:
        try:
            empleados = int(float(empleados))
        except:
            empleados = None
    else:
        empleados = None

    return Company(
        name=name,
        cui=nit if nit else None,
        country='CO',
        city=f"{municipio}, {departamento}" if municipio else departamento,
        address=direccion if direccion else None,
        phone=row.get('telefono', '').strip() or row.get('tel', '').strip() or None,
        email=row.get('email', '').strip() or row.get('correo', '').strip() or None,
        website=row.get('pagina_web', '').strip() or row.get('web', '').strip() or None,
        sector=codigo_ciiu if codigo_ciiu else None,
        sector_name=actividad if actividad else None,
        employees_count=empleados,
        revenue=None,
        source='CO_RUES',
        source_file=nit if nit else name[:50]
    )


def parse_secop_row(row: dict) -> Optional[ProcurementAward]:
    """Parse SECOP procurement row."""
    proceso = row.get('numero_del_proceso', '').strip() or row.get('id_proceso', '').strip()
    entidad = row.get('nombre_entidad', '').strip() or row.get('entidad', '').strip()
    proveedor = row.get('proveedor_adjudicado', '').strip() or row.get('contratista', '').strip()

    if not proveedor or not entidad:
        return None

    # Value
    valor = row.get('valor_del_contrato', '') or row.get('valor', '')
    valor = parse_float(valor)

    return ProcurementAward(
        source='CO_SECOP',
        source_id=proceso,
        country='CO',
        buyer_name=entidad,
        buyer_type=row.get('tipo_entidad', ''),
        winner_name=proveedor,
        winner_country='CO',
        winner_address=None,
        winner_id=row.get('nit_proveedor', '').strip(),
        title=row.get('objeto_del_contrato', '')[:500] if row.get('objeto_del_contrato') else None,
        description=row.get('descripcion', '')[:1000] if row.get('descripcion') else None,
        contract_value=valor,
        currency='COP',
        award_date=parse_date(row.get('fecha_de_firma', '')),
        start_date=parse_date(row.get('fecha_de_inicio', '')),
        end_date=parse_date(row.get('fecha_de_terminacion', '')),
        category=row.get('modalidad_de_contratacion', ''),
        sector_code=row.get('codigo_unspsc', ''),
        sector_name=row.get('grupo_unspsc', ''),
        url=row.get('urlproceso', ''),
        raw_data=None
    )


def iter_csv_file(filepath: Path) -> Iterator[dict]:
    """Iterate over CSV file rows."""
    encodings = ['utf-8', 'latin-1', 'cp1252']

    for encoding in encodings:
        try:
            with open(filepath, 'r', encoding=encoding, errors='ignore') as f:
                sample = f.read(4096)
                f.seek(0)

                delimiter = ','
                if sample.count(';') > sample.count(','):
                    delimiter = ';'
                elif sample.count('\t') > sample.count(','):
                    delimiter = '\t'

                reader = csv.DictReader(f, delimiter=delimiter)
                for row in reader:
                    yield row
                return
        except Exception as e:
            continue

    logger.error(f"Could not read {filepath}")


def download_colombia_data():
    """Download all available Colombia datasets."""
    logger.info("Searching for Colombia company datasets...")

    all_datasets = {}
    for key, config in DATASETS.items():
        results = search_datasets(config['search'])
        for ds in results:
            all_datasets[ds['id']] = ds
        logger.info(f"  {key}: found {len(results)} datasets")

    logger.info(f"Total unique datasets: {len(all_datasets)}")

    # Download resources
    downloaded = []
    for ds_id, ds in all_datasets.items():
        ds_dir = DATA_DIR / ds_id
        ds_dir.mkdir(exist_ok=True)

        resources = get_dataset_resources(ds_id)
        csv_resources = [r for r in resources if r.get('format', '').lower() in ['csv', 'xlsx', 'json']]

        logger.info(f"\n{ds.get('title', ds_id)}: {len(csv_resources)} files")

        for res in csv_resources[:3]:
            filepath = download_resource(res, ds_dir)
            if filepath:
                downloaded.append(filepath)

    return downloaded


def import_colombia(limit: int = 0, dry_run: bool = False):
    """Import Colombia data to database."""
    if not DATA_DIR.exists():
        logger.error(f"Data directory not found: {DATA_DIR}")
        logger.info("Run with --download first")
        return

    conn = None
    if not dry_run:
        conn = get_db()

    total_companies = 0
    total_procurement = 0

    # Find all CSV files
    csv_files = list(DATA_DIR.glob('**/*.csv'))
    logger.info(f"Found {len(csv_files)} CSV files")

    for csv_file in csv_files:
        logger.info(f"Processing {csv_file.name}...")
        company_batch = []
        procurement_batch = []

        is_secop = 'secop' in str(csv_file).lower() or 'contrat' in str(csv_file).lower()

        for row in iter_csv_file(csv_file):
            if is_secop:
                award = parse_secop_row(row)
                if award:
                    procurement_batch.append(award)
            else:
                company = parse_company_row(row)
                if company:
                    company_batch.append(company)

            if len(company_batch) >= BATCH_SIZE:
                if not dry_run:
                    total_companies += insert_companies(conn, company_batch)
                else:
                    total_companies += len(company_batch)
                company_batch = []

            if len(procurement_batch) >= BATCH_SIZE:
                if not dry_run:
                    total_procurement += insert_procurement_awards(conn, procurement_batch)
                else:
                    total_procurement += len(procurement_batch)
                procurement_batch = []

            if (total_companies + total_procurement) % 10000 == 0 and (total_companies + total_procurement) > 0:
                logger.info(f"  Processed {total_companies:,} companies, {total_procurement:,} procurement...")

            if limit > 0 and (total_companies + total_procurement) >= limit:
                break

        # Final batches
        if company_batch:
            if not dry_run:
                total_companies += insert_companies(conn, company_batch)
            else:
                total_companies += len(company_batch)

        if procurement_batch:
            if not dry_run:
                total_procurement += insert_procurement_awards(conn, procurement_batch)
            else:
                total_procurement += len(procurement_batch)

        if limit > 0 and (total_companies + total_procurement) >= limit:
            break

    if conn:
        conn.close()

    action = "Would import" if dry_run else "Imported"
    logger.info(f"{action} {total_companies:,} companies, {total_procurement:,} procurement")


def show_stats():
    """Show Colombia data stats."""
    print("\n" + "="*60)
    print("COLOMBIA DATA STATUS")
    print("="*60)

    # Available datasets
    print("\nSearching datos.gov.co...")
    for key, config in DATASETS.items():
        results = search_datasets(config['search'])
        print(f"  {key}: {len(results)} datasets")

    # Local data
    print(f"\nLocal data: {DATA_DIR}")
    if DATA_DIR.exists():
        for subdir in DATA_DIR.iterdir():
            if subdir.is_dir():
                files = list(subdir.glob('*'))
                print(f"  {subdir.name}: {len(files)} files")

    # Database
    print("\n" + "-"*60)
    print("DATABASE STATS")
    print("-"*60)

    try:
        conn = get_db()
        cur = conn.cursor()

        cur.execute("SELECT source, COUNT(*) FROM companies WHERE country = 'CO' GROUP BY source")
        by_source = cur.fetchall()

        cur.execute("SELECT COUNT(*) FROM companies WHERE country = 'CO'")
        total = cur.fetchone()[0]

        cur.execute("SELECT COUNT(*) FROM procurement_awards WHERE country = 'CO'")
        procurement = cur.fetchone()[0]

        conn.close()

        print(f"  Total CO companies: {total:,}")
        print(f"  Total CO procurement: {procurement:,}")
        for src, cnt in by_source:
            print(f"    {src}: {cnt:,}")

    except Exception as e:
        print(f"  Database error: {e}")


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Colombia RUES Import')
    parser.add_argument('--stats', '-s', action='store_true', help='Show stats')
    parser.add_argument('--download', '-d', action='store_true', help='Download data')
    parser.add_argument('--import', '-i', dest='do_import', action='store_true', help='Import to DB')
    parser.add_argument('--limit', '-l', type=int, default=0, help='Limit rows')
    parser.add_argument('--dry-run', '-n', action='store_true', help='Dry run')

    args = parser.parse_args()

    if args.stats:
        show_stats()
    elif args.download:
        download_colombia_data()
        if args.do_import:
            import_colombia(limit=args.limit, dry_run=args.dry_run)
    elif args.do_import:
        import_colombia(limit=args.limit, dry_run=args.dry_run)
    else:
        show_stats()
