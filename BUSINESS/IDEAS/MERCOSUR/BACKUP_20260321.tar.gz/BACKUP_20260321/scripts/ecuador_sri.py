#!/usr/bin/env python3
"""
Ecuador SRI/datos.gob.ec Company Import
Downloads and imports Ecuadorian company data.

Sources:
- datos.gob.ec - Open data portal (CKAN)
- SRI - Tax registry (Servicio de Rentas Internas)
- SERCOP - Procurement (Servicio Nacional de Contratacion Publica)

Usage:
    python3 ecuador_sri.py --stats           # Show stats
    python3 ecuador_sri.py --download        # Download data
    python3 ecuador_sri.py --import          # Import to DB
"""

import sys
import json
import csv
import requests
from pathlib import Path
from typing import Iterator, Optional
import logging

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from base import (
    Company, ProcurementAward, get_db, insert_companies,
    insert_procurement_awards, parse_date, parse_float,
    sanitize, log, BATCH_SIZE
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Directories
DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/ecuador')
DATA_DIR.mkdir(parents=True, exist_ok=True)

# datos.gob.ec CKAN API
CKAN_API = "https://www.datosabiertos.gob.ec/api/3/action/"

# SERCOP API (procurement)
SERCOP_API = "https://www.compraspublicas.gob.ec/ProcesosContratacion/api/"

# Key searches
DATASETS = {
    'empresas': {
        'search': 'empresas',
        'description': 'Registered companies',
    },
    'ruc': {
        'search': 'RUC contribuyentes',
        'description': 'Tax ID registry',
    },
    'sociedades': {
        'search': 'sociedades',
        'description': 'Registered societies',
    },
    'compras': {
        'search': 'compras publicas',
        'description': 'Public procurement',
    }
}


def search_datasets(query: str = "empresas") -> list:
    """Search for datasets on datos.gob.ec."""
    url = f"{CKAN_API}package_search"
    params = {'q': query, 'rows': 50}

    try:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()
        if data.get('success'):
            return data['result']['results']
    except Exception as e:
        logger.error(f"Search error: {e}")

    return []


def get_dataset_resources(dataset_id: str) -> list:
    """Get resources (files) for a dataset."""
    url = f"{CKAN_API}package_show"
    params = {'id': dataset_id}

    try:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()
        if data.get('success'):
            return data['result'].get('resources', [])
    except Exception as e:
        logger.error(f"Dataset error: {e}")

    return []


def download_resource(resource: dict, output_dir: Path) -> Optional[Path]:
    """Download a CKAN resource."""
    url = resource.get('url')
    name = resource.get('name', 'data')
    fmt = resource.get('format', 'csv').lower()

    if not url:
        return None

    filename = f"{name}.{fmt}".replace(' ', '_').replace('/', '_')
    filepath = output_dir / filename

    if filepath.exists():
        logger.info(f"  {filename} exists, skipping")
        return filepath

    logger.info(f"  Downloading {filename}...")

    try:
        resp = requests.get(url, timeout=120, stream=True)
        resp.raise_for_status()

        with open(filepath, 'wb') as f:
            for chunk in resp.iter_content(chunk_size=8192):
                f.write(chunk)

        return filepath

    except Exception as e:
        logger.error(f"Download error: {e}")
        return None


def parse_company_row(row: dict) -> Optional[Company]:
    """Parse Ecuador company CSV row."""
    # RUC (Registro Unico de Contribuyentes) - 13 digits
    ruc = row.get('ruc', '').strip() or row.get('RUC', '').strip()
    name = row.get('razon_social', '').strip() or row.get('nombre', '').strip() or row.get('nombre_comercial', '').strip()

    if not name:
        return None

    # Clean RUC
    if ruc:
        ruc = ''.join(c for c in ruc if c.isdigit())
        if len(ruc) != 13:
            ruc = None

    # Address
    direccion = row.get('direccion', '').strip() or row.get('domicilio', '').strip()
    parroquia = row.get('parroquia', '').strip()
    canton = row.get('canton', '').strip()
    provincia = row.get('provincia', '').strip()

    city = canton
    if parroquia and parroquia != canton:
        city = f"{parroquia}, {canton}" if canton else parroquia
    if provincia:
        city = f"{city}, {provincia}" if city else provincia

    # Activity (CIIU code)
    actividad = row.get('actividad_economica', '').strip() or row.get('actividad', '').strip()
    codigo_ciiu = row.get('ciiu', '').strip() or row.get('codigo_ciiu', '').strip()

    return Company(
        name=name,
        cui=ruc if ruc else None,
        country='EC',
        city=city if city else None,
        address=direccion if direccion else None,
        phone=row.get('telefono', '').strip() or None,
        email=row.get('correo', '').strip() or row.get('email', '').strip() or None,
        website=row.get('pagina_web', '').strip() or row.get('web', '').strip() or None,
        sector=codigo_ciiu if codigo_ciiu else None,
        sector_name=actividad if actividad else None,
        employees_count=None,
        revenue=None,
        source='EC_SRI',
        source_file=ruc if ruc else name[:50]
    )


def parse_sercop_row(row: dict) -> Optional[ProcurementAward]:
    """Parse SERCOP procurement row."""
    proceso = row.get('codigo_proceso', '').strip() or row.get('codigoProceso', '').strip()
    entidad = row.get('entidad_contratante', '').strip() or row.get('entidad', '').strip()
    proveedor = row.get('proveedor_adjudicado', '').strip() or row.get('proveedor', '').strip()

    if not proveedor or not entidad:
        return None

    # Value
    valor = row.get('monto_adjudicado', '') or row.get('valorAdjudicado', '')
    valor = parse_float(valor)

    return ProcurementAward(
        source='EC_SERCOP',
        source_id=proceso,
        country='EC',
        buyer_name=entidad,
        buyer_type=row.get('tipo_entidad', ''),
        winner_name=proveedor,
        winner_country='EC',
        winner_address=None,
        winner_id=row.get('ruc_proveedor', '').strip(),
        title=row.get('objeto_contratacion', '')[:500] if row.get('objeto_contratacion') else None,
        description=row.get('descripcion', '')[:1000] if row.get('descripcion') else None,
        contract_value=valor,
        currency='USD',  # Ecuador uses USD
        award_date=parse_date(row.get('fecha_adjudicacion', '')),
        start_date=parse_date(row.get('fecha_inicio', '')),
        end_date=parse_date(row.get('fecha_fin', '')),
        category=row.get('tipo_contratacion', '') or row.get('modalidad', ''),
        sector_code=row.get('codigoCPC', ''),
        sector_name=row.get('categoriaCPC', ''),
        url=row.get('enlace', ''),
        raw_data=None
    )


def iter_csv_file(filepath: Path) -> Iterator[dict]:
    """Iterate over CSV file rows."""
    encodings = ['utf-8', 'latin-1', 'cp1252']

    for encoding in encodings:
        try:
            with open(filepath, 'r', encoding=encoding, errors='ignore') as f:
                sample = f.read(4096)
                f.seek(0)

                delimiter = ','
                if sample.count(';') > sample.count(','):
                    delimiter = ';'
                elif sample.count('\t') > sample.count(','):
                    delimiter = '\t'

                reader = csv.DictReader(f, delimiter=delimiter)
                for row in reader:
                    yield row
                return
        except Exception as e:
            continue

    logger.error(f"Could not read {filepath}")


def download_ecuador_data():
    """Download all available Ecuador datasets."""
    logger.info("Searching for Ecuador company datasets...")

    all_datasets = {}
    for key, config in DATASETS.items():
        results = search_datasets(config['search'])
        for ds in results:
            all_datasets[ds['id']] = ds
        logger.info(f"  {key}: found {len(results)} datasets")

    logger.info(f"Total unique datasets: {len(all_datasets)}")

    # Download resources
    downloaded = []
    for ds_id, ds in all_datasets.items():
        ds_dir = DATA_DIR / ds_id
        ds_dir.mkdir(exist_ok=True)

        resources = get_dataset_resources(ds_id)
        csv_resources = [r for r in resources if r.get('format', '').lower() in ['csv', 'xlsx', 'json']]

        logger.info(f"\n{ds.get('title', ds_id)}: {len(csv_resources)} files")

        for res in csv_resources[:3]:
            filepath = download_resource(res, ds_dir)
            if filepath:
                downloaded.append(filepath)

    return downloaded


def import_ecuador(limit: int = 0, dry_run: bool = False):
    """Import Ecuador data to database."""
    if not DATA_DIR.exists():
        logger.error(f"Data directory not found: {DATA_DIR}")
        logger.info("Run with --download first")
        return

    conn = None
    if not dry_run:
        conn = get_db()

    total_companies = 0
    total_procurement = 0

    # Find all CSV files
    csv_files = list(DATA_DIR.glob('**/*.csv'))
    logger.info(f"Found {len(csv_files)} CSV files")

    for csv_file in csv_files:
        logger.info(f"Processing {csv_file.name}...")
        company_batch = []
        procurement_batch = []

        is_sercop = 'sercop' in str(csv_file).lower() or 'compras' in str(csv_file).lower() or 'contrat' in str(csv_file).lower()

        for row in iter_csv_file(csv_file):
            if is_sercop:
                award = parse_sercop_row(row)
                if award:
                    procurement_batch.append(award)
            else:
                company = parse_company_row(row)
                if company:
                    company_batch.append(company)

            if len(company_batch) >= BATCH_SIZE:
                if not dry_run:
                    total_companies += insert_companies(conn, company_batch)
                else:
                    total_companies += len(company_batch)
                company_batch = []

            if len(procurement_batch) >= BATCH_SIZE:
                if not dry_run:
                    total_procurement += insert_procurement_awards(conn, procurement_batch)
                else:
                    total_procurement += len(procurement_batch)
                procurement_batch = []

            if (total_companies + total_procurement) % 10000 == 0 and (total_companies + total_procurement) > 0:
                logger.info(f"  Processed {total_companies:,} companies, {total_procurement:,} procurement...")

            if limit > 0 and (total_companies + total_procurement) >= limit:
                break

        # Final batches
        if company_batch:
            if not dry_run:
                total_companies += insert_companies(conn, company_batch)
            else:
                total_companies += len(company_batch)

        if procurement_batch:
            if not dry_run:
                total_procurement += insert_procurement_awards(conn, procurement_batch)
            else:
                total_procurement += len(procurement_batch)

        if limit > 0 and (total_companies + total_procurement) >= limit:
            break

    if conn:
        conn.close()

    action = "Would import" if dry_run else "Imported"
    logger.info(f"{action} {total_companies:,} companies, {total_procurement:,} procurement")


def show_stats():
    """Show Ecuador data stats."""
    print("\n" + "="*60)
    print("ECUADOR DATA STATUS")
    print("="*60)

    # Available datasets
    print("\nSearching datos.gob.ec...")
    for key, config in DATASETS.items():
        results = search_datasets(config['search'])
        print(f"  {key}: {len(results)} datasets")

    # Local data
    print(f"\nLocal data: {DATA_DIR}")
    if DATA_DIR.exists():
        for subdir in DATA_DIR.iterdir():
            if subdir.is_dir():
                files = list(subdir.glob('*'))
                print(f"  {subdir.name}: {len(files)} files")

    # Database
    print("\n" + "-"*60)
    print("DATABASE STATS")
    print("-"*60)

    try:
        conn = get_db()
        cur = conn.cursor()

        cur.execute("SELECT source, COUNT(*) FROM companies WHERE country = 'EC' GROUP BY source")
        by_source = cur.fetchall()

        cur.execute("SELECT COUNT(*) FROM companies WHERE country = 'EC'")
        total = cur.fetchone()[0]

        cur.execute("SELECT COUNT(*) FROM procurement_awards WHERE country = 'EC'")
        procurement = cur.fetchone()[0]

        conn.close()

        print(f"  Total EC companies: {total:,}")
        print(f"  Total EC procurement: {procurement:,}")
        for src, cnt in by_source:
            print(f"    {src}: {cnt:,}")

    except Exception as e:
        print(f"  Database error: {e}")


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Ecuador SRI Import')
    parser.add_argument('--stats', '-s', action='store_true', help='Show stats')
    parser.add_argument('--download', '-d', action='store_true', help='Download data')
    parser.add_argument('--import', '-i', dest='do_import', action='store_true', help='Import to DB')
    parser.add_argument('--limit', '-l', type=int, default=0, help='Limit rows')
    parser.add_argument('--dry-run', '-n', action='store_true', help='Dry run')

    args = parser.parse_args()

    if args.stats:
        show_stats()
    elif args.download:
        download_ecuador_data()
        if args.do_import:
            import_ecuador(limit=args.limit, dry_run=args.dry_run)
    elif args.do_import:
        import_ecuador(limit=args.limit, dry_run=args.dry_run)
    else:
        show_stats()
