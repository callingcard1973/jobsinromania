#!/usr/bin/env python3
"""
Chile MercadoPublico.cl Procurement Scraper
Fetches procurement data from Chile's ChileCompra portal.

API: https://api.mercadopublico.cl/
Docs: https://desarrolladores.mercadopublico.cl/

Usage:
    python3 chile_mercadopublico.py --stats
    python3 chile_mercadopublico.py --fetch --limit 1000
    python3 chile_mercadopublico.py --winners
"""

import sys
import json
import csv
import requests
from pathlib import Path
from datetime import datetime, timedelta
from typing import List
import logging
import time

sys.path.insert(0, '/opt/ACTIVE/DB/GLOBAL')
from base import get_db, sanitize, BATCH_SIZE

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/chile_mercadopublico')
DATA_DIR.mkdir(parents=True, exist_ok=True)

# ChileCompra API
API_BASE = "https://api.mercadopublico.cl/servicios/v1/publico"
LICITACIONES_URL = f"{API_BASE}/licitaciones.json"
OC_URL = f"{API_BASE}/ordenesdecompra.json"
REQUEST_DELAY = 1.0


def fetch_licitaciones(fecha: str = None, estado: str = "adjudicada", limit: int = 100) -> dict:
    """Fetch tenders from ChileCompra API."""
    if not fecha:
        fecha = (datetime.now() - timedelta(days=30)).strftime('%d%m%Y')

    params = {
        'fecha': fecha,
        'estado': estado,
        'ticket': 'F8537A18-6766-4DEF-9E59-426B4FEE2844',  # Public demo ticket
    }
    try:
        resp = requests.get(LICITACIONES_URL, params=params, timeout=30)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        logger.error(f"API error: {e}")
        return {}


def fetch_ordenes_compra(fecha: str = None, limit: int = 100) -> dict:
    """Fetch purchase orders."""
    if not fecha:
        fecha = (datetime.now() - timedelta(days=7)).strftime('%d%m%Y')

    params = {
        'fecha': fecha,
        'ticket': 'F8537A18-6766-4DEF-9E59-426B4FEE2844',
    }
    try:
        resp = requests.get(OC_URL, params=params, timeout=30)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        logger.error(f"API error: {e}")
        return {}


def fetch_all_licitaciones(days: int = 30, max_records: int = 5000) -> List[dict]:
    """Fetch tenders for multiple days."""
    all_records = []
    base_date = datetime.now()

    for i in range(days):
        fecha = (base_date - timedelta(days=i)).strftime('%d%m%Y')
        logger.info(f"Fetching {fecha}...")

        data = fetch_licitaciones(fecha)
        licitaciones = data.get('Listado', [])

        if licitaciones:
            all_records.extend(licitaciones)
            logger.info(f"  Found {len(licitaciones)} tenders")

        time.sleep(REQUEST_DELAY)

        if len(all_records) >= max_records:
            break

    return all_records[:max_records]


def extract_winners(records: List[dict]) -> List[dict]:
    """Extract winning companies from tenders."""
    winners = []
    for r in records:
        # ChileCompra structure
        adjudicacion = r.get('Adjudicacion', {})
        items = r.get('Items', {}).get('Listado', [])

        for item in items:
            adjudicado = item.get('Adjudicacion', {})
            proveedor = adjudicado.get('NombreProveedor', '')
            rut = adjudicado.get('RutProveedor', '')

            if proveedor:
                winners.append({
                    'name': sanitize(proveedor),
                    'rut': rut,
                    'country': 'CL',
                    'contract_value': adjudicado.get('MontoUnitario', 0) * adjudicado.get('CantidadAdjudicada', 1),
                    'tender_code': r.get('CodigoExterno', ''),
                    'buyer': r.get('Comprador', {}).get('NombreOrganismo', ''),
                    'description': sanitize(r.get('Nombre', ''))[:500],
                })
    return winners


def save_winners(winners: List[dict]):
    """Save winners to CSV."""
    output_file = DATA_DIR / f'chile_winners_{datetime.now():%Y%m%d}.csv'
    if winners:
        # Dedupe
        seen = set()
        unique = []
        for w in winners:
            key = (w['name'], w['rut'])
            if key not in seen:
                seen.add(key)
                unique.append(w)

        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=unique[0].keys())
            writer.writeheader()
            writer.writerows(unique)
        logger.info(f"Saved {len(unique)} unique winners to {output_file}")


def show_stats():
    """Show stats."""
    print("\n" + "="*60)
    print("CHILE MERCADOPUBLICO.CL STATUS")
    print("="*60)

    # Test API
    print("\nAPI Test (last 7 days):")
    data = fetch_licitaciones()
    if data:
        count = data.get('Cantidad', 0)
        print(f"  Tenders found: {count}")
        if data.get('Listado'):
            sample = data['Listado'][0]
            print(f"  Sample: {sample.get('Nombre', '')[:50]}...")
    else:
        print("  API not responding or requires valid ticket")

    # Purchase orders
    print("\nPurchase Orders (last 7 days):")
    oc_data = fetch_ordenes_compra()
    if oc_data:
        print(f"  Orders found: {oc_data.get('Cantidad', 0)}")

    # Local data
    print(f"\nLocal data: {DATA_DIR}")
    csvs = list(DATA_DIR.glob('*.csv'))
    for f in csvs[-3:]:
        lines = sum(1 for _ in open(f)) - 1
        print(f"  {f.name}: {lines:,} records")

    # DB stats
    print("\nDatabase:")
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM companies WHERE source = 'CL_MercadoPublico'")
        print(f"  CL_MercadoPublico companies: {cur.fetchone()[0]:,}")
        conn.close()
    except Exception as e:
        print(f"  DB error: {e}")


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Chile MercadoPublico Scraper')
    parser.add_argument('--stats', '-s', action='store_true')
    parser.add_argument('--fetch', '-f', action='store_true')
    parser.add_argument('--winners', '-w', action='store_true')
    parser.add_argument('--days', '-d', type=int, default=30)
    parser.add_argument('--limit', '-l', type=int, default=1000)

    args = parser.parse_args()

    if args.fetch or args.winners:
        records = fetch_all_licitaciones(args.days, args.limit)
        logger.info(f"Fetched {len(records)} tenders")

        with open(DATA_DIR / f'licitaciones_{datetime.now():%Y%m%d}.json', 'w') as f:
            json.dump(records, f, indent=2, default=str)

        if args.winners:
            winners = extract_winners(records)
            save_winners(winners)
    else:
        show_stats()
