#!/usr/bin/env python3
"""
MERCOSUR-EU Commodity Matcher
Matches MERCOSUR suppliers with EU buyers using domain/fuzzy matching.

Usage:
    python3 mercosur_eu_matcher.py --commodity lithium --dry-run
    python3 mercosur_eu_matcher.py --commodity beef --save
    python3 mercosur_eu_matcher.py --all --save
"""

import sys
import json
import argparse
from pathlib import Path
from typing import List, Tuple
import logging
from datetime import datetime

sys.path.insert(0, '/opt/ACTIVE/DB/GLOBAL')
sys.path.insert(0, '/opt/ACTIVE/SCRAPERS/EUROPE/SCRIPTS/SHARED')

from base import get_db

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS')
OUTPUT_DIR = DATA_DIR / 'mercosur_matches'
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

COMMODITY_SOURCES = {
    'lithium': 'mercosur_lithium/lithium_suppliers.json',
    'niobium': 'mercosur_niobium/niobium_suppliers.json',
    'beef': 'mercosur_beef/beef_exporters.json',
    'honey': 'mercosur_honey/honey_exporters.json',
}

# Import fuzzy matcher if available
try:
    from fuzzy_matcher import normalize_company_name, FuzzyMatcher
    HAS_FUZZY = True
except ImportError:
    HAS_FUZZY = False
    logger.warning("Fuzzy matcher not available, using basic matching")


def load_suppliers(commodity: str) -> List[dict]:
    """Load MERCOSUR suppliers for a commodity."""
    source_file = DATA_DIR / COMMODITY_SOURCES.get(commodity, '')
    if not source_file.exists():
        logger.error(f"Source file not found: {source_file}")
        return []
    with open(source_file, 'r') as f:
        return json.load(f)


def load_eu_buyers(commodity: str, limit: int = 5000) -> List[dict]:
    """Load EU buyers from TED winners filtered by commodity."""
    from eu_buyer_profiles import get_sector_buyers
    return get_sector_buyers(commodity, limit)


def extract_domain(url: str) -> str:
    """Extract domain from URL or website field."""
    if not url:
        return ''
    url = url.lower().replace('https://', '').replace('http://', '').replace('www.', '')
    return url.split('/')[0].split('?')[0]


def match_by_domain(suppliers: List[dict], buyers: List[dict]) -> List[dict]:
    """Match suppliers to buyers by domain."""
    matches = []
    buyer_domains = {}

    for b in buyers:
        if b.get('website'):
            domain = extract_domain(b['website'])
            if domain:
                buyer_domains[domain] = b
        if b.get('email'):
            email_domain = b['email'].split('@')[-1] if '@' in b['email'] else ''
            if email_domain:
                buyer_domains[email_domain] = b

    for s in suppliers:
        if s.get('website'):
            domain = extract_domain(s['website'])
            if domain in buyer_domains:
                matches.append({
                    'supplier': s,
                    'buyer': buyer_domains[domain],
                    'match_type': 'domain',
                    'confidence': 0.95,
                })
    return matches


def match_by_name(suppliers: List[dict], buyers: List[dict], threshold: float = 0.85) -> List[dict]:
    """Match suppliers to buyers by fuzzy company name."""
    if not HAS_FUZZY:
        return []

    matches = []
    buyer_names = {normalize_company_name(b.get('authority_name', '')): b for b in buyers}

    for s in suppliers:
        s_name = normalize_company_name(s.get('name', ''))
        for b_name, buyer in buyer_names.items():
            # Simple token overlap
            s_tokens = set(s_name.lower().split())
            b_tokens = set(b_name.lower().split())
            if len(s_tokens & b_tokens) >= 2:
                matches.append({
                    'supplier': s,
                    'buyer': buyer,
                    'match_type': 'fuzzy_name',
                    'confidence': 0.70,
                })
    return matches


def save_matches(matches: List[dict], commodity: str):
    """Save matches to database and JSON."""
    conn = get_db()
    cur = conn.cursor()

    # Create table if not exists
    cur.execute("""
        CREATE TABLE IF NOT EXISTS commodity_matches (
            id SERIAL PRIMARY KEY,
            commodity VARCHAR(50),
            supplier_name VARCHAR(500),
            supplier_country CHAR(2),
            supplier_email VARCHAR(200),
            supplier_website VARCHAR(500),
            buyer_name VARCHAR(500),
            buyer_country CHAR(2),
            buyer_email VARCHAR(200),
            match_type VARCHAR(20),
            confidence DECIMAL(3,2),
            created_at TIMESTAMP DEFAULT NOW()
        )
    """)

    inserted = 0
    for m in matches:
        try:
            cur.execute("""
                INSERT INTO commodity_matches
                (commodity, supplier_name, supplier_country, supplier_email, supplier_website,
                 buyer_name, buyer_country, buyer_email, match_type, confidence)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                commodity,
                m['supplier'].get('name', '')[:500],
                m['supplier'].get('country', ''),
                m['supplier'].get('email', ''),
                m['supplier'].get('website', ''),
                m['buyer'].get('authority_name', '')[:500],
                m['buyer'].get('country', ''),
                m['buyer'].get('email', ''),
                m['match_type'],
                m['confidence'],
            ))
            inserted += 1
        except Exception as e:
            logger.warning(f"Insert error: {e}")

    conn.commit()
    conn.close()
    logger.info(f"Inserted {inserted} matches to database")

    # Also save JSON
    output_file = OUTPUT_DIR / f'{commodity}_matches_{datetime.now():%Y%m%d}.json'
    with open(output_file, 'w') as f:
        json.dump([{
            'supplier': m['supplier'].get('name'),
            'supplier_country': m['supplier'].get('country'),
            'buyer': m['buyer'].get('authority_name'),
            'buyer_country': m['buyer'].get('country'),
            'buyer_email': m['buyer'].get('email'),
            'match_type': m['match_type'],
            'confidence': m['confidence'],
        } for m in matches], f, indent=2)
    logger.info(f"Saved to {output_file}")


def run_matching(commodity: str, save: bool = False):
    """Run matching pipeline for a commodity."""
    logger.info(f"=== Matching {commodity.upper()} ===")

    suppliers = load_suppliers(commodity)
    logger.info(f"Loaded {len(suppliers)} suppliers")

    buyers = load_eu_buyers(commodity)
    logger.info(f"Loaded {len(buyers)} EU buyers")

    if not suppliers or not buyers:
        return []

    # Run matchers
    domain_matches = match_by_domain(suppliers, buyers)
    logger.info(f"Domain matches: {len(domain_matches)}")

    name_matches = match_by_name(suppliers, buyers)
    logger.info(f"Name matches: {len(name_matches)}")

    all_matches = domain_matches + name_matches
    logger.info(f"Total matches: {len(all_matches)}")

    if save and all_matches:
        save_matches(all_matches, commodity)

    return all_matches


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='MERCOSUR-EU Matcher')
    parser.add_argument('--commodity', '-c', choices=['lithium', 'niobium', 'beef', 'honey', 'all'])
    parser.add_argument('--save', '-s', action='store_true', help='Save matches to DB')
    parser.add_argument('--dry-run', '-n', action='store_true', help='Dry run')

    args = parser.parse_args()

    commodities = list(COMMODITY_SOURCES.keys()) if args.commodity == 'all' else [args.commodity]

    for comm in commodities:
        if comm:
            run_matching(comm, save=args.save and not args.dry_run)
