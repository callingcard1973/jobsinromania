#!/usr/bin/env python3
"""
Paraguay DNCP Procurement Data (OCDS)
Fetches procurement data from Paraguay's open contracting portal.

Source: https://contrataciones.gov.py/
API: https://datos.contrataciones.gov.py/api/v3/

Usage:
    python3 paraguay_dncp.py --stats          # Show stats
    python3 paraguay_dncp.py --fetch          # Fetch latest data
    python3 paraguay_dncp.py --import         # Import to DB
    python3 paraguay_dncp.py --winners        # Extract winning companies
"""

import sys
import json
import requests
from pathlib import Path
from datetime import datetime, timedelta
from typing import Iterator, Optional
import logging
import time

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from base import (
    Company, ProcurementAward, get_db, insert_companies,
    insert_procurement_awards, parse_date, parse_float,
    sanitize, log, BATCH_SIZE
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Directories
DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/paraguay_dncp')
DATA_DIR.mkdir(parents=True, exist_ok=True)

# OCDS API
API_BASE = "https://datos.contrataciones.gov.py/api/v3"
RELEASES_URL = f"{API_BASE}/doc/ocds/releases"
RECORDS_URL = f"{API_BASE}/doc/ocds/records"


def fetch_releases(offset: int = 0, limit: int = 100) -> dict:
    """Fetch releases from OCDS API."""
    params = {
        'offset': offset,
        'limit': limit,
    }

    try:
        resp = requests.get(RELEASES_URL, params=params, timeout=60)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        logger.error(f"API error: {e}")
        return {}


def fetch_all_releases(max_records: int = 10000) -> list:
    """Fetch all releases up to max_records."""
    all_releases = []
    offset = 0
    limit = 100

    while len(all_releases) < max_records:
        logger.info(f"Fetching releases {offset} to {offset + limit}...")
        data = fetch_releases(offset, limit)

        releases = data.get('releases', [])
        if not releases:
            break

        all_releases.extend(releases)
        offset += limit

        # Rate limiting
        time.sleep(0.5)

        if len(releases) < limit:
            break

    logger.info(f"Fetched {len(all_releases)} releases")
    return all_releases


def parse_release_to_award(release: dict) -> Optional[ProcurementAward]:
    """Parse OCDS release to ProcurementAward."""
    # Get award data
    awards = release.get('awards', [])
    if not awards:
        return None

    award = awards[0]  # Take first award

    # Winner (supplier)
    suppliers = award.get('suppliers', [])
    if not suppliers:
        return None

    supplier = suppliers[0]
    winner_name = supplier.get('name', '').strip()
    if not winner_name:
        return None

    # Winner ID (RUC)
    winner_id = supplier.get('id', '').strip()
    if winner_id.startswith('PY-'):
        winner_id = winner_id[3:]

    # Buyer
    buyer = release.get('buyer', {})
    buyer_name = buyer.get('name', '').strip()

    # Tender details
    tender = release.get('tender', {})
    title = tender.get('title', '').strip()
    description = tender.get('description', '').strip()

    # Value
    value = award.get('value', {})
    amount = parse_float(value.get('amount'))
    currency = value.get('currency', 'PYG')

    # Dates
    award_date = parse_date(award.get('date'))
    start_date = parse_date(tender.get('tenderPeriod', {}).get('startDate'))
    end_date = parse_date(tender.get('tenderPeriod', {}).get('endDate'))

    # Category
    category = tender.get('procurementMethod', '').strip()
    main_item = tender.get('items', [{}])[0] if tender.get('items') else {}
    sector_code = main_item.get('classification', {}).get('id', '')
    sector_name = main_item.get('classification', {}).get('description', '')

    return ProcurementAward(
        source='PY_DNCP',
        source_id=release.get('ocid', ''),
        country='PY',
        buyer_name=buyer_name,
        buyer_type=buyer.get('id', ''),
        winner_name=winner_name,
        winner_country='PY',
        winner_address=supplier.get('address', {}).get('streetAddress'),
        winner_id=winner_id,
        title=title[:500] if title else None,
        description=description[:1000] if description else None,
        contract_value=amount,
        currency=currency,
        award_date=award_date,
        start_date=start_date,
        end_date=end_date,
        category=category,
        sector_code=sector_code[:20] if sector_code else None,
        sector_name=sector_name[:200] if sector_name else None,
        url=f"https://contrataciones.gov.py/licitaciones/{release.get('ocid', '')}",
        raw_data=None
    )


def parse_supplier_to_company(release: dict) -> Optional[Company]:
    """Extract winning company from release."""
    awards = release.get('awards', [])
    if not awards:
        return None

    for award in awards:
        suppliers = award.get('suppliers', [])
        for supplier in suppliers:
            name = supplier.get('name', '').strip()
            if not name:
                continue

            supplier_id = supplier.get('id', '').strip()
            if supplier_id.startswith('PY-'):
                supplier_id = supplier_id[3:]

            address = supplier.get('address', {})

            return Company(
                name=name,
                cui=supplier_id,
                country='PY',
                city=address.get('locality', ''),
                address=address.get('streetAddress'),
                phone=supplier.get('contactPoint', {}).get('telephone'),
                email=supplier.get('contactPoint', {}).get('email'),
                website=supplier.get('contactPoint', {}).get('url'),
                sector=None,
                sector_name=None,
                employees_count=None,
                revenue=None,
                source='PY_DNCP_Winner',
                source_file=supplier_id
            )

    return None


def fetch_and_save(max_records: int = 10000):
    """Fetch releases and save to file."""
    releases = fetch_all_releases(max_records)

    if not releases:
        logger.error("No releases fetched")
        return

    # Save to file
    output_file = DATA_DIR / f"releases_{datetime.now().strftime('%Y%m%d')}.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump({'releases': releases}, f, indent=2, ensure_ascii=False)

    logger.info(f"Saved {len(releases)} releases to {output_file}")
    return output_file


def import_dncp(limit: int = 0, dry_run: bool = False):
    """Import DNCP data from saved files."""
    json_files = sorted(DATA_DIR.glob('releases_*.json'), reverse=True)

    if not json_files:
        logger.error("No releases files found. Run with --fetch first")
        return

    latest = json_files[0]
    logger.info(f"Importing from {latest.name}...")

    with open(latest, 'r', encoding='utf-8') as f:
        data = json.load(f)

    releases = data.get('releases', [])
    logger.info(f"Found {len(releases)} releases")

    conn = None
    if not dry_run:
        conn = get_db()

    total_awards = 0
    total_companies = 0
    awards_batch = []
    companies_batch = []

    for release in releases:
        # Parse award
        award = parse_release_to_award(release)
        if award:
            awards_batch.append(award)

        # Extract company
        company = parse_supplier_to_company(release)
        if company:
            companies_batch.append(company)

        # Batch insert
        if len(awards_batch) >= BATCH_SIZE:
            if not dry_run:
                total_awards += insert_procurement_awards(conn, awards_batch)
                total_companies += insert_companies(conn, companies_batch)
            else:
                total_awards += len(awards_batch)
                total_companies += len(companies_batch)

            awards_batch = []
            companies_batch = []

            if (total_awards + total_companies) % 10000 == 0:
                logger.info(f"  Processed {total_awards:,} awards, {total_companies:,} companies...")

        if limit > 0 and total_awards >= limit:
            break

    # Final batch
    if awards_batch:
        if not dry_run:
            total_awards += insert_procurement_awards(conn, awards_batch)
            total_companies += insert_companies(conn, companies_batch)
        else:
            total_awards += len(awards_batch)
            total_companies += len(companies_batch)

    if conn:
        conn.close()

    action = "Would import" if dry_run else "Imported"
    logger.info(f"{action} {total_awards:,} awards, {total_companies:,} companies")


def show_stats():
    """Show DNCP stats."""
    print("\n" + "="*60)
    print("PARAGUAY DNCP (CONTRATACIONES) STATUS")
    print("="*60)

    # Test API
    print("\nAPI Status:")
    try:
        data = fetch_releases(0, 1)
        if data.get('releases'):
            print("  API: ONLINE")
            print(f"  Sample release: {data['releases'][0].get('ocid', 'N/A')}")
        else:
            print("  API: NO DATA")
    except Exception as e:
        print(f"  API: ERROR - {e}")

    # Local data
    print(f"\nLocal data: {DATA_DIR}")
    if DATA_DIR.exists():
        json_files = list(DATA_DIR.glob('releases_*.json'))
        for jf in json_files[-5:]:
            size_mb = jf.stat().st_size / 1048576
            print(f"  {jf.name}: {size_mb:.1f} MB")

    # Database
    print("\n" + "-"*60)
    print("DATABASE STATS")
    print("-"*60)

    try:
        conn = get_db()
        cur = conn.cursor()

        cur.execute("SELECT COUNT(*) FROM procurement_awards WHERE source = 'PY_DNCP'")
        awards = cur.fetchone()[0]

        cur.execute("SELECT COUNT(*) FROM companies WHERE source = 'PY_DNCP_Winner'")
        companies = cur.fetchone()[0]

        cur.execute("""
            SELECT buyer_name, COUNT(*), SUM(contract_value)
            FROM procurement_awards
            WHERE source = 'PY_DNCP'
            GROUP BY buyer_name
            ORDER BY SUM(contract_value) DESC NULLS LAST
            LIMIT 10
        """)
        top_buyers = cur.fetchall()

        conn.close()

        print(f"  PY_DNCP awards: {awards:,}")
        print(f"  PY_DNCP winners: {companies:,}")

        if top_buyers:
            print("\n  Top buyers:")
            for buyer, cnt, val in top_buyers:
                val_str = f"{val/1e9:.1f}B PYG" if val else "N/A"
                print(f"    {buyer[:40]}: {cnt:,} awards, {val_str}")

    except Exception as e:
        print(f"  Database error: {e}")


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Paraguay DNCP Import')
    parser.add_argument('--stats', '-s', action='store_true', help='Show stats')
    parser.add_argument('--fetch', '-f', action='store_true', help='Fetch from API')
    parser.add_argument('--import', '-i', dest='do_import', action='store_true', help='Import to DB')
    parser.add_argument('--max-records', '-m', type=int, default=10000, help='Max records to fetch')
    parser.add_argument('--limit', '-l', type=int, default=0, help='Limit import rows')
    parser.add_argument('--dry-run', '-n', action='store_true', help='Dry run')

    args = parser.parse_args()

    if args.stats:
        show_stats()
    elif args.fetch:
        fetch_and_save(args.max_records)
        if args.do_import:
            import_dncp(limit=args.limit, dry_run=args.dry_run)
    elif args.do_import:
        import_dncp(limit=args.limit, dry_run=args.dry_run)
    else:
        show_stats()
