#!/usr/bin/env python3
"""
MERCOSUR-EU Sector Matcher

Matches MERCOSUR suppliers to EU buyers BY SECTOR (not company name).
Creates outreach-ready lists pairing suppliers with relevant buyers.

Usage:
    python3 sector_matcher.py --stats                    # Show all stats
    python3 sector_matcher.py --commodity lithium        # Match lithium
    python3 sector_matcher.py --commodity all            # Match all commodities
    python3 sector_matcher.py --commodity beef --export  # Export to CSV
    python3 sector_matcher.py --campaign lithium         # Generate campaign CSV

Output: /mnt/hdd/GLOBAL_DOWNLOADS/mercosur_matches/
"""

import sys
import os
import csv
import json
import argparse
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Tuple
import logging

sys.path.insert(0, '/opt/ACTIVE/DB/GLOBAL')
sys.path.insert(0, '/opt/ACTIVE/SCRAPERS/EUROPE/SCRIPTS/SHARED')

from base import get_db

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Directories
DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS')
OUTPUT_DIR = DATA_DIR / 'mercosur_matches'
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Supplier data files
SUPPLIER_FILES = {
    'lithium': DATA_DIR / 'mercosur_lithium/lithium_suppliers.json',
    'niobium': DATA_DIR / 'mercosur_niobium/niobium_suppliers.json',
    'beef': DATA_DIR / 'mercosur_beef/beef_exporters.json',
    'honey': DATA_DIR / 'mercosur_honey/honey_exporters.json',
}

# Sector definitions with CPV codes, NACE codes, and keywords
# CPV = Common Procurement Vocabulary (EU procurement)
# NACE = EU industry classification
SECTOR_CONFIG = {
    'lithium': {
        'name': 'Critical Minerals - Lithium',
        'description': 'Lithium carbonate, hydroxide for batteries',
        'supplier_count': 24,
        'cpv_codes': [
            '314',      # Batteries and accumulators
            '3143',     # Lithium batteries
            '271',      # Electrical machinery
            '341',      # Motor vehicles
            '502',      # Repair services for vehicles
        ],
        'nace_codes': ['27.2', '29.1', '27.9'],  # Batteries, vehicles, electrical
        'keywords': [
            'battery', 'batteries', 'lithium', 'accumulator', 'electric vehicle',
            'EV', 'automotive', 'energy storage', 'power storage', 'cell'
        ],
        'buyer_types': ['Battery Manufacturer', 'Automotive', 'Energy Storage', 'Electronics'],
        'eu_target_countries': ['DE', 'FR', 'PL', 'HU', 'SE', 'IT', 'ES', 'AT'],
    },
    'niobium': {
        'name': 'Critical Minerals - Niobium',
        'description': 'Ferroniobium for HSLA steel, superalloys',
        'supplier_count': 8,
        'cpv_codes': [
            '146',      # Metal ores
            '142',      # Non-ferrous metals
            '270',      # Iron/steel products
            '441',      # Metal structures
            '351',      # Aerospace equipment
            '345',      # Railway equipment
        ],
        'nace_codes': ['24.1', '24.4', '30.3', '25.1'],  # Steel, metals, aerospace
        'keywords': [
            'steel', 'alloy', 'niobium', 'ferroniobium', 'pipeline', 'aerospace',
            'turbine', 'superalloy', 'HSLA', 'high strength', 'structural steel'
        ],
        'buyer_types': ['Steel Mill', 'Aerospace', 'Automotive', 'Construction'],
        'eu_target_countries': ['DE', 'FR', 'IT', 'ES', 'PL', 'AT', 'SE', 'BE'],
    },
    'beef': {
        'name': 'Food - Beef',
        'description': 'Fresh/frozen beef for EU market',
        'supplier_count': 22,
        'cpv_codes': [
            '151',      # Meat and meat products
            '153',      # Processed meat
            '554',      # Restaurant/catering
            '555',      # Canteen services
        ],
        'nace_codes': ['10.1', '46.3', '56.2'],  # Meat processing, wholesale, catering
        'keywords': [
            'meat', 'beef', 'bovine', 'food', 'catering', 'restaurant', 'canteen',
            'hospital', 'school', 'prison', 'military', 'frozen', 'fresh'
        ],
        'buyer_types': ['Food Processor', 'Catering', 'Retail', 'Wholesaler', 'Institution'],
        'eu_target_countries': ['DE', 'IT', 'NL', 'FR', 'ES', 'BE', 'PL', 'UK'],
    },
    'honey': {
        'name': 'Food - Honey',
        'description': 'Natural honey and bee products',
        'supplier_count': 20,
        'cpv_codes': [
            '158',      # Various food products
            '153',      # Processed food
            '033',      # Agricultural products
        ],
        'nace_codes': ['10.8', '46.3', '47.2'],  # Food mfg, wholesale, retail
        'keywords': [
            'honey', 'food', 'organic', 'natural', 'sweetener', 'confectionery',
            'bakery', 'cereal', 'breakfast', 'retail', 'supermarket'
        ],
        'buyer_types': ['Food Manufacturer', 'Confectionery', 'Retail', 'Organic'],
        'eu_target_countries': ['DE', 'FR', 'IT', 'ES', 'PL', 'NL', 'BE', 'UK'],
    },
}


def load_suppliers(commodity: str) -> List[Dict]:
    """Load suppliers from JSON file."""
    filepath = SUPPLIER_FILES.get(commodity)
    if not filepath or not filepath.exists():
        logger.error(f"Supplier file not found: {filepath}")
        return []

    with open(filepath) as f:
        suppliers = json.load(f)

    # Filter to operating/active suppliers
    active = [s for s in suppliers if s.get('status', '').lower() in
              ['operating', 'active', 'construction', 'development', '']]

    logger.info(f"Loaded {len(active)} active {commodity} suppliers")
    return active


def query_eu_buyers(commodity: str, limit: int = 2000) -> List[Dict]:
    """Query TED winners for buyers in this sector."""
    config = SECTOR_CONFIG.get(commodity)
    if not config:
        logger.error(f"Unknown commodity: {commodity}")
        return []

    conn = get_db()
    cur = conn.cursor()

    # Build CPV filter
    cpv_conditions = []
    for cpv in config['cpv_codes']:
        cpv_conditions.append(f"cpv LIKE '{cpv}%'")
    cpv_filter = ' OR '.join(cpv_conditions)

    # Build keyword filter on contractor name
    keyword_conditions = []
    for kw in config['keywords'][:10]:  # Limit keywords
        keyword_conditions.append(f"LOWER(contractor) LIKE '%{kw.lower()}%'")
    keyword_filter = ' OR '.join(keyword_conditions)

    # Build country filter (focus on target countries)
    country_list = "', '".join(config['eu_target_countries'])

    query = f"""
        SELECT DISTINCT ON (contractor_email)
            contractor,
            contractor_country,
            contractor_email,
            contractor_website,
            contractor_city,
            cpv,
            COALESCE(SUM(NULLIF(contract_value, '')::numeric), 0) as total_value,
            COUNT(*) as contract_count
        FROM ted_winners
        WHERE contractor_email IS NOT NULL
          AND contractor_email != ''
          AND LENGTH(contractor_email) > 5
          AND contractor_email !~ '^[0-9]+@'
          AND contractor_email !~ '^(test|example|noreply|no-reply|info@example)'
          AND contractor_email LIKE '%@%.%'
          AND (
              ({cpv_filter})
              OR ({keyword_filter})
          )
        GROUP BY contractor, contractor_country, contractor_email,
                 contractor_website, contractor_city, cpv
        ORDER BY contractor_email, total_value DESC NULLS LAST
        LIMIT {limit}
    """

    try:
        cur.execute(query)
        rows = cur.fetchall()

        buyers = []
        seen_emails = set()

        for row in rows:
            email = row[2]
            if email and email.lower() not in seen_emails:
                seen_emails.add(email.lower())
                buyers.append({
                    'company': row[0],
                    'country': row[1],
                    'email': email,
                    'website': row[3],
                    'city': row[4],
                    'cpv': row[5],
                    'total_contract_value': float(row[6]) if row[6] else 0,
                    'contract_count': row[7],
                })

        logger.info(f"Found {len(buyers)} unique EU buyers for {commodity}")
        return buyers

    except Exception as e:
        logger.error(f"Query error: {e}")
        import traceback
        traceback.print_exc()
        return []
    finally:
        conn.close()


def create_matches(commodity: str, buyer_limit: int = 2000) -> List[Dict]:
    """
    Create supplier-buyer matches for a commodity.
    Each supplier gets paired with relevant buyers by sector.
    """
    config = SECTOR_CONFIG.get(commodity)
    if not config:
        return []

    suppliers = load_suppliers(commodity)
    buyers = query_eu_buyers(commodity, buyer_limit)

    if not suppliers or not buyers:
        logger.warning(f"No suppliers or buyers for {commodity}")
        return []

    matches = []

    # Each supplier matches to all relevant buyers
    # (sector-based, not company-specific)
    for supplier in suppliers:
        for buyer in buyers:
            match = {
                # Supplier info
                'supplier_name': supplier.get('name', ''),
                'supplier_country': supplier.get('country', ''),
                'supplier_city': supplier.get('city', ''),
                'supplier_website': supplier.get('website', ''),
                'supplier_sector': supplier.get('sector', ''),
                'supplier_product': supplier.get('product', supplier.get('products', '')),
                'supplier_status': supplier.get('status', ''),
                'supplier_capacity': supplier.get('capacity_tonnes', supplier.get('volume_tonnes', '')),

                # Buyer info
                'buyer_name': buyer.get('company', ''),
                'buyer_country': buyer.get('country', ''),
                'buyer_city': buyer.get('city', ''),
                'buyer_email': buyer.get('email', ''),
                'buyer_website': buyer.get('website', ''),
                'buyer_cpv': buyer.get('cpv', ''),
                'buyer_contract_value': buyer.get('total_contract_value', 0),

                # Match metadata
                'commodity': commodity,
                'match_type': 'sector',
                'match_date': datetime.now().isoformat(),
            }
            matches.append(match)

    logger.info(f"Created {len(matches)} matches for {commodity}")
    return matches


def export_matches(matches: List[Dict], output_file: Path):
    """Export matches to CSV."""
    if not matches:
        logger.warning("No matches to export")
        return

    fieldnames = list(matches[0].keys())

    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(matches)

    logger.info(f"Exported {len(matches)} matches to {output_file}")


def export_campaign_csv(commodity: str, output_file: Path = None, buyer_limit: int = 500):
    """
    Export campaign-ready CSV with unique buyers and supplier summary.
    Format optimized for email campaigns.
    """
    suppliers = load_suppliers(commodity)
    buyers = query_eu_buyers(commodity, buyer_limit)

    if not buyers:
        logger.warning(f"No buyers for {commodity} campaign")
        return

    if not output_file:
        output_file = OUTPUT_DIR / f"campaign_{commodity}_{datetime.now():%Y%m%d}.csv"

    # Build supplier summary for email template
    supplier_count = len(suppliers)
    supplier_countries = list(set(s.get('country', '') for s in suppliers))
    top_suppliers = [s.get('name', '') for s in suppliers[:5]]

    config = SECTOR_CONFIG[commodity]

    # Prepare campaign rows (one per buyer)
    campaign_rows = []
    for buyer in buyers:
        row = {
            'email': buyer['email'],
            'company': buyer['company'],
            'country': buyer['country'],
            'city': buyer.get('city', ''),
            'website': buyer.get('website', ''),
            'contract_value_eur': int(buyer.get('total_contract_value', 0)),

            # Template variables
            'commodity': config['name'],
            'commodity_short': commodity,
            'supplier_count': supplier_count,
            'supplier_countries': ', '.join(supplier_countries),
            'top_suppliers': ', '.join(top_suppliers[:3]),
        }
        campaign_rows.append(row)

    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=campaign_rows[0].keys())
        writer.writeheader()
        writer.writerows(campaign_rows)

    logger.info(f"Campaign CSV: {len(campaign_rows)} contacts -> {output_file}")
    return output_file


def show_stats(commodity: str = None):
    """Show matching statistics."""
    print("\n" + "="*70)
    print("MERCOSUR-EU SECTOR MATCHER STATISTICS")
    print("="*70)

    commodities = [commodity] if commodity and commodity != 'all' else SECTOR_CONFIG.keys()

    total_suppliers = 0
    total_buyers = 0
    total_matches = 0

    for comm in commodities:
        config = SECTOR_CONFIG[comm]
        suppliers = load_suppliers(comm)
        buyers = query_eu_buyers(comm, limit=5000)

        supplier_count = len(suppliers)
        buyer_count = len(buyers)
        match_count = supplier_count * buyer_count

        total_suppliers += supplier_count
        total_buyers += buyer_count
        total_matches += match_count

        print(f"\n{config['name'].upper()}")
        print("-" * 40)
        print(f"  Suppliers:     {supplier_count:,}")
        print(f"  EU Buyers:     {buyer_count:,}")
        print(f"  Total Matches: {match_count:,}")

        # Top buyer countries
        country_counts = {}
        for b in buyers:
            c = b.get('country', 'N/A')
            country_counts[c] = country_counts.get(c, 0) + 1
        top_countries = sorted(country_counts.items(), key=lambda x: -x[1])[:5]
        print(f"  Top Countries: {', '.join(f'{c}:{n}' for c,n in top_countries)}")

        # Value stats
        total_value = sum(b.get('total_contract_value', 0) for b in buyers)
        if total_value:
            print(f"  Buyer Value:   EUR {total_value/1e9:.2f}B")

    print("\n" + "="*70)
    print(f"TOTALS: {total_suppliers} suppliers x {total_buyers} buyers = {total_matches:,} matches")
    print("="*70 + "\n")


def main():
    parser = argparse.ArgumentParser(description='MERCOSUR-EU Sector Matcher')
    parser.add_argument('--commodity', '-c',
                        choices=['lithium', 'niobium', 'beef', 'honey', 'all'],
                        help='Commodity to match')
    parser.add_argument('--stats', '-s', action='store_true', help='Show statistics')
    parser.add_argument('--export', '-e', action='store_true', help='Export full matches')
    parser.add_argument('--campaign', action='store_true', help='Export campaign CSV')
    parser.add_argument('--limit', '-l', type=int, default=500, help='Buyer limit')
    parser.add_argument('--output', '-o', type=str, help='Output file path')

    args = parser.parse_args()

    if args.stats:
        show_stats(args.commodity)
        return

    if not args.commodity:
        parser.print_help()
        print("\n\nExamples:")
        print("  python3 sector_matcher.py --stats")
        print("  python3 sector_matcher.py --commodity lithium --campaign")
        print("  python3 sector_matcher.py --commodity all --export")
        return

    commodities = list(SECTOR_CONFIG.keys()) if args.commodity == 'all' else [args.commodity]

    for commodity in commodities:
        if args.campaign:
            output = Path(args.output) if args.output else None
            export_campaign_csv(commodity, output, args.limit)

        elif args.export:
            matches = create_matches(commodity, args.limit)
            output_file = Path(args.output) if args.output else \
                          OUTPUT_DIR / f"matches_{commodity}_{datetime.now():%Y%m%d}.csv"
            export_matches(matches, output_file)

        else:
            # Just show match count
            suppliers = load_suppliers(commodity)
            buyers = query_eu_buyers(commodity, args.limit)
            print(f"\n{commodity.upper()}: {len(suppliers)} suppliers x {len(buyers)} buyers")


if __name__ == '__main__':
    main()
