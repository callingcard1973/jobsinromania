#!/usr/bin/env python3
"""
MERCOSUR Lithium Suppliers (The Lithium Triangle)
Fetches lithium producers from Argentina, Chile, and Bolivia.

Sources:
- AR: Secretaria de Mineria, INDEC
- CL: Cochilco, SERNAGEOMIN
- BO: COMIBOL, ANB

Usage:
    python3 lithium_suppliers.py --stats           # Show stats
    python3 lithium_suppliers.py --download AR    # Download Argentina data
    python3 lithium_suppliers.py --download ALL   # Download all countries
    python3 lithium_suppliers.py --import         # Import to DB
"""

import sys
import json
import requests
from pathlib import Path
from typing import List
import logging
from bs4 import BeautifulSoup
import re

sys.path.insert(0, '/opt/ACTIVE/DB/GLOBAL')

from base import (
    Company, get_db, insert_companies,
    sanitize, log, BATCH_SIZE
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Directories
DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/mercosur_lithium')
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Country-specific sources
SOURCES = {
    'AR': {
        'name': 'Argentina',
        'registry': 'Secretaria de Mineria',
        'url': 'https://www.argentina.gob.ar/economia/mineria',
        'api': 'https://datos.gob.ar/api/3/action/package_search?q=mineria+litio',
        'region': 'Jujuy, Salta, Catamarca',
    },
    'CL': {
        'name': 'Chile',
        'registry': 'Cochilco',
        'url': 'https://www.cochilco.cl/',
        'sernageomin': 'https://www.sernageomin.cl/',
        'region': 'Atacama (Salar de Atacama)',
    },
    'BO': {
        'name': 'Bolivia',
        'registry': 'COMIBOL/YLB',
        'url': 'https://www.ylb.gob.bo/',
        'region': 'Potosi (Salar de Uyuni)',
    }
}

# Known lithium producers (verified data)
LITHIUM_PRODUCERS = [
    # Argentina - Active Projects
    {
        'name': 'Livent Corporation (Argentina)',
        'country': 'AR',
        'city': 'Catamarca',
        'region': 'Salar del Hombre Muerto',
        'sector': 'Lithium Carbonate',
        'website': 'livent.com',
        'capacity_tonnes': 20000,
        'status': 'Operating',
        'product': 'Lithium Carbonate, Lithium Chloride',
    },
    {
        'name': 'Allkem Limited (Olaroz)',
        'country': 'AR',
        'city': 'Jujuy',
        'region': 'Salar de Olaroz',
        'sector': 'Lithium Carbonate',
        'website': 'allkem.co',
        'capacity_tonnes': 42500,
        'status': 'Operating',
        'product': 'Lithium Carbonate',
    },
    {
        'name': 'Arcadium Lithium (Fenix)',
        'country': 'AR',
        'city': 'Catamarca',
        'region': 'Salar del Hombre Muerto',
        'sector': 'Lithium',
        'website': 'arcadiumlithium.com',
        'capacity_tonnes': 40000,
        'status': 'Expanding',
        'product': 'Lithium Carbonate',
    },
    {
        'name': 'Posco Pilbara (Sal de Vida)',
        'country': 'AR',
        'city': 'Catamarca',
        'region': 'Salar del Hombre Muerto',
        'sector': 'Lithium',
        'website': 'poscopilbara.com',
        'capacity_tonnes': 15000,
        'status': 'Construction',
        'product': 'Lithium Hydroxide',
    },
    {
        'name': 'Eramet (Centenario-Ratones)',
        'country': 'AR',
        'city': 'Salta',
        'region': 'Salar de Centenario',
        'sector': 'Lithium Carbonate',
        'website': 'eramet.com',
        'capacity_tonnes': 24000,
        'status': 'Construction',
        'product': 'Lithium Carbonate',
    },
    {
        'name': 'Rio Tinto (Rincon)',
        'country': 'AR',
        'city': 'Salta',
        'region': 'Salar del Rincon',
        'sector': 'Lithium',
        'website': 'riotinto.com',
        'capacity_tonnes': 50000,
        'status': 'Development',
        'product': 'Lithium Carbonate',
    },
    {
        'name': 'Ganfeng Lithium (Mariana)',
        'country': 'AR',
        'city': 'Salta',
        'region': 'Salar de Llullaillaco',
        'sector': 'Lithium',
        'website': 'ganfenglithium.com',
        'capacity_tonnes': 20000,
        'status': 'Development',
        'product': 'Lithium Carbonate',
    },
    {
        'name': 'Lithium Americas (Cauchari-Olaroz)',
        'country': 'AR',
        'city': 'Jujuy',
        'region': 'Salar de Cauchari',
        'sector': 'Lithium',
        'website': 'lithiumamericas.com',
        'capacity_tonnes': 40000,
        'status': 'Operating',
        'product': 'Lithium Carbonate',
    },
    {
        'name': 'JEMSE S.A.',
        'country': 'AR',
        'city': 'Jujuy',
        'region': 'Jujuy',
        'sector': 'State Mining Company',
        'website': 'jemse.gob.ar',
        'status': 'JV Partner',
        'product': 'Lithium (State Partner)',
    },

    # Chile - Atacama
    {
        'name': 'SQM (Sociedad Quimica y Minera)',
        'country': 'CL',
        'city': 'Santiago',
        'region': 'Salar de Atacama',
        'sector': 'Lithium, Potassium, Iodine',
        'website': 'sqm.com',
        'capacity_tonnes': 180000,
        'status': 'Operating',
        'product': 'Lithium Carbonate, Lithium Hydroxide',
        'employees': 7000,
    },
    {
        'name': 'Albemarle Chile',
        'country': 'CL',
        'city': 'Santiago',
        'region': 'Salar de Atacama',
        'sector': 'Lithium',
        'website': 'albemarle.com',
        'capacity_tonnes': 85000,
        'status': 'Operating',
        'product': 'Lithium Carbonate, Lithium Hydroxide',
        'employees': 1500,
    },
    {
        'name': 'CODELCO (Maricunga)',
        'country': 'CL',
        'city': 'Copiapo',
        'region': 'Salar de Maricunga',
        'sector': 'Copper, Lithium',
        'website': 'codelco.com',
        'status': 'Development',
        'product': 'Lithium (future)',
    },
    {
        'name': 'BYD Chile',
        'country': 'CL',
        'city': 'Antofagasta',
        'region': 'Atacama',
        'sector': 'Battery, Lithium Processing',
        'website': 'byd.com',
        'status': 'Development',
        'product': 'Lithium Processing',
    },

    # Bolivia - Uyuni
    {
        'name': 'Yacimientos de Litio Bolivianos (YLB)',
        'country': 'BO',
        'city': 'La Paz',
        'region': 'Salar de Uyuni',
        'sector': 'State Lithium Company',
        'website': 'ylb.gob.bo',
        'capacity_tonnes': 15000,
        'status': 'Operating (Pilot)',
        'product': 'Lithium Carbonate',
    },
    {
        'name': 'COMIBOL (Lithium Division)',
        'country': 'BO',
        'city': 'La Paz',
        'region': 'Potosi',
        'sector': 'State Mining',
        'website': 'comibol.gob.bo',
        'status': 'Exploration',
        'product': 'Lithium Resources',
    },
    {
        'name': 'CBC-YLB (CATL JV)',
        'country': 'BO',
        'city': 'Potosi',
        'region': 'Salar de Uyuni',
        'sector': 'Lithium',
        'website': None,
        'capacity_tonnes': 25000,
        'status': 'Construction',
        'product': 'Lithium Carbonate',
    },
    {
        'name': 'Uranium One-YLB',
        'country': 'BO',
        'city': 'Potosi',
        'region': 'Salar de Pastos Grandes',
        'sector': 'Lithium',
        'status': 'Development',
        'product': 'Lithium Carbonate',
    },
]

# Additional junior/exploration companies
JUNIOR_EXPLORERS = [
    {'name': 'Lake Resources (Kachi)', 'country': 'AR', 'city': 'Catamarca', 'status': 'Development', 'website': 'lakeresources.com.au'},
    {'name': 'Argosy Minerals (Rincon)', 'country': 'AR', 'city': 'Salta', 'status': 'Development', 'website': 'argosyminerals.com.au'},
    {'name': 'ioneer Ltd (Cinti)', 'country': 'AR', 'city': 'Salta', 'status': 'Exploration', 'website': 'ioneer.com'},
    {'name': 'Orocobre (merged Allkem)', 'country': 'AR', 'city': 'Jujuy', 'status': 'Operating', 'website': 'allkem.co'},
    {'name': 'Neo Lithium (Tres Quebradas)', 'country': 'AR', 'city': 'Catamarca', 'status': 'Development', 'website': 'neolithium.ca'},
    {'name': 'Lithium Chile Inc', 'country': 'CL', 'city': 'Copiapo', 'status': 'Exploration', 'website': 'lithiumchile.ca'},
    {'name': 'Wealth Minerals (Atacama)', 'country': 'CL', 'city': 'Antofagasta', 'status': 'Exploration', 'website': 'wealthminerals.com'},
]


def fetch_argentina_mining_data() -> List[dict]:
    """Fetch data from Argentina mining portal."""
    producers = []

    try:
        # Try datos.gob.ar API
        url = SOURCES['AR']['api']
        resp = requests.get(url, timeout=30)
        data = resp.json()

        if 'result' in data and 'results' in data['result']:
            for dataset in data['result']['results']:
                if 'litio' in dataset.get('title', '').lower():
                    producers.append({
                        'name': dataset.get('title'),
                        'country': 'AR',
                        'source': 'datos.gob.ar',
                        'dataset_id': dataset.get('id'),
                    })
    except Exception as e:
        logger.warning(f"Argentina API error: {e}")

    return producers


def fetch_chile_cochilco_data() -> List[dict]:
    """Fetch data from Chile Cochilco."""
    producers = []

    try:
        # Cochilco statistics page
        url = 'https://www.cochilco.cl/Paginas/Estadisticas/Bases%20de%20Datos/Bases-de-Datos.aspx'
        resp = requests.get(url, timeout=30, headers={'User-Agent': 'Mozilla/5.0'})
        soup = BeautifulSoup(resp.text, 'html.parser')

        # Look for lithium data links
        for link in soup.select('a[href*="litio"], a[href*="lithium"]'):
            producers.append({
                'name': link.get_text(strip=True),
                'country': 'CL',
                'source': 'Cochilco',
                'url': link.get('href'),
            })
    except Exception as e:
        logger.warning(f"Cochilco fetch error: {e}")

    return producers


def parse_producer_to_company(data: dict) -> Company:
    """Convert producer data to Company object."""
    return Company(
        name=data.get('name', ''),
        cui=data.get('tax_id', ''),
        country=data.get('country', ''),
        city=data.get('city', ''),
        address=data.get('address'),
        phone=data.get('phone'),
        email=data.get('email'),
        website=data.get('website'),
        sector='0729',  # Mining of other non-ferrous metal ores
        sector_name=f"Lithium - {data.get('sector', 'Mining')}",
        employees_count=data.get('employees'),
        revenue=None,
        source=f"MERCOSUR_LITHIUM_{data.get('country', 'XX')}",
        source_file=data.get('source', 'MANUAL')
    )


def download_lithium_suppliers(country: str = 'ALL'):
    """Download lithium supplier data."""
    all_producers = []

    countries = [country.upper()] if country.upper() != 'ALL' else ['AR', 'CL', 'BO']

    for cc in countries:
        logger.info(f"Fetching {SOURCES[cc]['name']} lithium producers...")

        # Start with known producers
        known = [p for p in LITHIUM_PRODUCERS if p['country'] == cc]
        all_producers.extend(known)
        logger.info(f"  {len(known)} major producers for {cc}")

        # Add junior explorers
        juniors = [p for p in JUNIOR_EXPLORERS if p['country'] == cc]
        for j in juniors:
            j['sector'] = 'Lithium Exploration'
            j['region'] = j.get('city', '')
        all_producers.extend(juniors)
        logger.info(f"  {len(juniors)} junior explorers for {cc}")

        # Try to fetch additional data
        if cc == 'AR':
            api_data = fetch_argentina_mining_data()
            logger.info(f"  {len(api_data)} datasets from API")

        elif cc == 'CL':
            cochilco_data = fetch_chile_cochilco_data()
            logger.info(f"  {len(cochilco_data)} items from Cochilco")

    # Save to file
    output_file = DATA_DIR / 'lithium_suppliers.json'
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(all_producers, f, indent=2, ensure_ascii=False)

    logger.info(f"Saved {len(all_producers)} lithium producers to {output_file}")
    return all_producers


def import_lithium_suppliers(limit: int = 0, dry_run: bool = False):
    """Import lithium suppliers to database."""
    data_file = DATA_DIR / 'lithium_suppliers.json'

    if not data_file.exists():
        logger.info("No data file found, downloading...")
        download_lithium_suppliers('ALL')

    with open(data_file, 'r', encoding='utf-8') as f:
        producers = json.load(f)

    logger.info(f"Importing {len(producers)} lithium producers...")

    conn = None
    if not dry_run:
        conn = get_db()

    batch = []
    total = 0

    for prod in producers:
        company = parse_producer_to_company(prod)
        batch.append(company)

        if len(batch) >= BATCH_SIZE:
            if not dry_run:
                total += insert_companies(conn, batch)
            else:
                total += len(batch)
            batch = []

        if limit > 0 and total >= limit:
            break

    if batch:
        if not dry_run:
            total += insert_companies(conn, batch)
        else:
            total += len(batch)

    if conn:
        conn.close()

    action = "Would import" if dry_run else "Imported"
    logger.info(f"{action} {total} lithium producers")


def show_stats():
    """Show lithium supplier stats."""
    print("\n" + "="*60)
    print("MERCOSUR LITHIUM SUPPLIERS STATUS")
    print("="*60)

    # Show sources
    print("\nData Sources (The Lithium Triangle):")
    for cc, config in SOURCES.items():
        print(f"  {cc} - {config['name']}: {config['registry']}")
        print(f"       Region: {config['region']}")

    # Local data
    data_file = DATA_DIR / 'lithium_suppliers.json'
    if data_file.exists():
        with open(data_file, 'r') as f:
            data = json.load(f)

        print(f"\nLocal data: {len(data)} producers")
        by_country = {}
        by_status = {}
        total_capacity = 0

        for prod in data:
            cc = prod.get('country', 'XX')
            by_country[cc] = by_country.get(cc, 0) + 1

            status = prod.get('status', 'Unknown')
            by_status[status] = by_status.get(status, 0) + 1

            cap = prod.get('capacity_tonnes', 0) or 0
            total_capacity += cap

        print("\n  By country:")
        for cc, cnt in sorted(by_country.items()):
            print(f"    {cc}: {cnt}")

        print("\n  By status:")
        for status, cnt in sorted(by_status.items()):
            print(f"    {status}: {cnt}")

        print(f"\n  Total capacity: {total_capacity:,} tonnes/year")
    else:
        print("\nNo local data. Run --download first.")

    # Database stats
    print("\n" + "-"*60)
    print("DATABASE STATS")
    print("-"*60)

    try:
        conn = get_db()
        cur = conn.cursor()

        cur.execute("""
            SELECT country, COUNT(*)
            FROM companies
            WHERE source LIKE 'MERCOSUR_LITHIUM_%'
            GROUP BY country
        """)
        by_country = cur.fetchall()

        cur.execute("SELECT COUNT(*) FROM companies WHERE source LIKE 'MERCOSUR_LITHIUM_%'")
        total = cur.fetchone()[0]

        conn.close()

        print(f"  Total lithium producers: {total:,}")
        for cc, cnt in by_country:
            print(f"    {cc}: {cnt:,}")

    except Exception as e:
        print(f"  Database error: {e}")

    # Market info
    print("\n" + "-"*60)
    print("LITHIUM TRIANGLE OVERVIEW")
    print("-"*60)
    print("  World reserves: ~67% in AR/CL/BO")
    print("  Argentina: 21% world reserves, expanding rapidly")
    print("  Chile: 36% world production (SQM, Albemarle)")
    print("  Bolivia: Largest reserve (Uyuni), state-controlled")
    print("\n  Products:")
    print("    - Lithium Carbonate (Li2CO3): Battery-grade, 99.5%+")
    print("    - Lithium Hydroxide (LiOH): NMC batteries, EV premium")
    print("\n  EU Battery Demand: Growing 30%/year (EV transition)")


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='MERCOSUR Lithium Suppliers')
    parser.add_argument('--stats', '-s', action='store_true', help='Show stats')
    parser.add_argument('--download', '-d', nargs='?', const='ALL', help='Download data (AR/CL/BO/ALL)')
    parser.add_argument('--import', '-i', dest='do_import', action='store_true', help='Import to DB')
    parser.add_argument('--limit', '-l', type=int, default=0, help='Limit rows')
    parser.add_argument('--dry-run', '-n', action='store_true', help='Dry run')

    args = parser.parse_args()

    if args.download:
        download_lithium_suppliers(args.download)
    elif args.do_import:
        import_lithium_suppliers(limit=args.limit, dry_run=args.dry_run)
    else:
        show_stats()
