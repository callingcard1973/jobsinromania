#!/usr/bin/env python3
"""
MERCOSUR All Countries Data Collector
Collects company/exporter data from all 12 MERCOSUR countries
"""

import sys
sys.path.insert(0, '/opt/ACTIVE/SCRAPERS/EUROPE/SCRIPTS/SHARED')

import argparse
import json
import logging
from pathlib import Path
from datetime import datetime
from skills_common import to_ascii

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s [%(name)s] %(message)s')
logger = logging.getLogger(__name__)

OUTPUT_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/mercosur_all_countries')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def get_paraguay_companies():
    """Paraguay major companies and exporters"""
    return [
        # Beef/Meat
        {'name': 'Frigorifico Concepcion', 'country': 'PY', 'city': 'Concepcion', 'sector': 'Beef', 'website': 'frigorificoconcepcion.com'},
        {'name': 'JBS Paraguay', 'country': 'PY', 'city': 'Asuncion', 'sector': 'Beef'},
        {'name': 'Frigomerc', 'country': 'PY', 'city': 'Asuncion', 'sector': 'Beef', 'website': 'frigomerc.com.py'},
        {'name': 'Frigorifico San Pedro', 'country': 'PY', 'city': 'San Pedro', 'sector': 'Beef'},
        {'name': 'Frigorifico Neuland', 'country': 'PY', 'city': 'Filadelfia', 'sector': 'Beef', 'website': 'neuland.com.py'},
        {'name': 'Frigorifico Guarani', 'country': 'PY', 'city': 'Itaugua', 'sector': 'Beef', 'website': 'frigorificoguarani.com.py'},
        {'name': 'Frigorifico Norte', 'country': 'PY', 'city': 'Concepcion', 'sector': 'Beef'},
        {'name': 'Athena Foods Paraguay', 'country': 'PY', 'city': 'Asuncion', 'sector': 'Beef', 'website': 'athenafoods.com'},
        # Soy/Grains
        {'name': 'Cargill Paraguay', 'country': 'PY', 'city': 'Asuncion', 'sector': 'Grains', 'website': 'cargill.com.py'},
        {'name': 'ADM Paraguay', 'country': 'PY', 'city': 'Asuncion', 'sector': 'Grains'},
        {'name': 'Bunge Paraguay', 'country': 'PY', 'city': 'Asuncion', 'sector': 'Grains'},
        {'name': 'Louis Dreyfus Paraguay', 'country': 'PY', 'city': 'Asuncion', 'sector': 'Grains'},
        {'name': 'COFCO Paraguay', 'country': 'PY', 'city': 'Asuncion', 'sector': 'Grains'},
        {'name': 'Desarrollo Agricola del Paraguay (DAP)', 'country': 'PY', 'city': 'Asuncion', 'sector': 'Grains'},
        {'name': 'Agro Silo Santa Catalina', 'country': 'PY', 'city': 'Ciudad del Este', 'sector': 'Grains'},
        # Sugar
        {'name': 'Azucarera Paraguaya (AZPA)', 'country': 'PY', 'city': 'Asuncion', 'sector': 'Sugar', 'website': 'azpa.com.py'},
        {'name': 'Ingenio La Felsina', 'country': 'PY', 'city': 'Guaira', 'sector': 'Sugar'},
        {'name': 'CAPASA', 'country': 'PY', 'city': 'Asuncion', 'sector': 'Sugar'},
        # Industry
        {'name': 'Grupo Cartes', 'country': 'PY', 'city': 'Asuncion', 'sector': 'Conglomerate', 'website': 'grupocartes.com.py'},
        {'name': 'Tabacalera del Este (TABESA)', 'country': 'PY', 'city': 'Asuncion', 'sector': 'Tobacco', 'website': 'tabesa.com.py'},
        {'name': 'Manufactura de Pilar', 'country': 'PY', 'city': 'Pilar', 'sector': 'Textiles'},
        {'name': 'PETROPAR', 'country': 'PY', 'city': 'Asuncion', 'sector': 'Oil/Gas', 'website': 'petropar.gov.py'},
        {'name': 'Itaipu Binacional', 'country': 'PY', 'city': 'Hernandarias', 'sector': 'Energy', 'website': 'itaipu.gov.py'},
        # Yerba Mate
        {'name': 'Selecta', 'country': 'PY', 'city': 'Asuncion', 'sector': 'Yerba Mate', 'website': 'selecta.com.py'},
        {'name': 'Pajarito', 'country': 'PY', 'city': 'Asuncion', 'sector': 'Yerba Mate', 'website': 'pajarito.com.py'},
        {'name': 'Kurupi', 'country': 'PY', 'city': 'Asuncion', 'sector': 'Yerba Mate'},
    ]

def get_bolivia_companies():
    """Bolivia major companies and exporters"""
    return [
        # Mining/Lithium
        {'name': 'Yacimientos de Litio Bolivianos (YLB)', 'country': 'BO', 'city': 'La Paz', 'sector': 'Lithium', 'website': 'ylb.gob.bo'},
        {'name': 'COMIBOL', 'country': 'BO', 'city': 'La Paz', 'sector': 'Mining', 'website': 'comibol.gob.bo'},
        {'name': 'Empresa Minera Huanuni', 'country': 'BO', 'city': 'Oruro', 'sector': 'Tin/Mining'},
        {'name': 'Sinchi Wayra (Glencore)', 'country': 'BO', 'city': 'La Paz', 'sector': 'Zinc/Silver'},
        {'name': 'Minera San Cristobal', 'country': 'BO', 'city': 'Potosi', 'sector': 'Zinc/Silver', 'website': 'minerasancristobal.com'},
        {'name': 'Empresa Siderurgica del Mutun (ESM)', 'country': 'BO', 'city': 'Puerto Suarez', 'sector': 'Iron Ore'},
        # Gas/Oil
        {'name': 'YPFB', 'country': 'BO', 'city': 'La Paz', 'sector': 'Oil/Gas', 'website': 'ypfb.gob.bo'},
        {'name': 'Repsol Bolivia', 'country': 'BO', 'city': 'Santa Cruz', 'sector': 'Oil/Gas'},
        {'name': 'Petrobras Bolivia', 'country': 'BO', 'city': 'Santa Cruz', 'sector': 'Oil/Gas'},
        {'name': 'TotalEnergies Bolivia', 'country': 'BO', 'city': 'Santa Cruz', 'sector': 'Oil/Gas'},
        # Soy/Agriculture
        {'name': 'ADM Bolivia', 'country': 'BO', 'city': 'Santa Cruz', 'sector': 'Grains'},
        {'name': 'Cargill Bolivia', 'country': 'BO', 'city': 'Santa Cruz', 'sector': 'Grains'},
        {'name': 'Gravetal Bolivia', 'country': 'BO', 'city': 'Santa Cruz', 'sector': 'Soy/Oils'},
        {'name': 'Industrias de Aceite (FINO)', 'country': 'BO', 'city': 'Santa Cruz', 'sector': 'Soy/Oils', 'website': 'fino.com.bo'},
        {'name': 'IOL S.A.', 'country': 'BO', 'city': 'Santa Cruz', 'sector': 'Soy/Oils'},
        # Brazil Nuts
        {'name': 'URKUPIÑA', 'country': 'BO', 'city': 'Riberalta', 'sector': 'Brazil Nuts'},
        {'name': 'Tahuamanu', 'country': 'BO', 'city': 'Cobija', 'sector': 'Brazil Nuts', 'website': 'tahuamanu.com'},
        {'name': 'Amazonas Trading', 'country': 'BO', 'city': 'Riberalta', 'sector': 'Brazil Nuts'},
        # Quinoa
        {'name': 'Andean Valley', 'country': 'BO', 'city': 'La Paz', 'sector': 'Quinoa', 'website': 'andeanvalley.com'},
        {'name': 'Coronilla', 'country': 'BO', 'city': 'La Paz', 'sector': 'Quinoa'},
        {'name': 'Jatary', 'country': 'BO', 'city': 'Oruro', 'sector': 'Quinoa'},
        # Food/Beverages
        {'name': 'Cerveceria Boliviana Nacional (CBN)', 'country': 'BO', 'city': 'La Paz', 'sector': 'Beverages', 'website': 'cfrn.com.bo'},
        {'name': 'PIL Andina', 'country': 'BO', 'city': 'Cochabamba', 'sector': 'Dairy', 'website': 'pilandina.com'},
        {'name': 'Delizia', 'country': 'BO', 'city': 'La Paz', 'sector': 'Dairy'},
    ]

def get_peru_companies():
    """Peru major companies and exporters"""
    return [
        # Mining
        {'name': 'Southern Copper Corporation', 'country': 'PE', 'city': 'Lima', 'sector': 'Copper', 'website': 'southerncoppercorp.com'},
        {'name': 'Antamina', 'country': 'PE', 'city': 'Lima', 'sector': 'Copper/Zinc', 'website': 'antamina.com'},
        {'name': 'Cerro Verde (Freeport)', 'country': 'PE', 'city': 'Arequipa', 'sector': 'Copper'},
        {'name': 'Las Bambas (MMG)', 'country': 'PE', 'city': 'Apurimac', 'sector': 'Copper'},
        {'name': 'Minsur', 'country': 'PE', 'city': 'Lima', 'sector': 'Tin', 'website': 'minsur.com'},
        {'name': 'Buenaventura', 'country': 'PE', 'city': 'Lima', 'sector': 'Gold/Silver', 'website': 'buenaventura.com'},
        {'name': 'Volcan Compania Minera', 'country': 'PE', 'city': 'Lima', 'sector': 'Zinc/Silver', 'website': 'volcan.com.pe'},
        {'name': 'Nexa Resources Peru', 'country': 'PE', 'city': 'Lima', 'sector': 'Zinc', 'website': 'nexaresources.com'},
        {'name': 'Hochschild Mining', 'country': 'PE', 'city': 'Lima', 'sector': 'Gold/Silver', 'website': 'hochschildmining.com'},
        {'name': 'Gold Fields La Cima', 'country': 'PE', 'city': 'Cajamarca', 'sector': 'Gold'},
        # Oil/Gas
        {'name': 'Pluspetrol', 'country': 'PE', 'city': 'Lima', 'sector': 'Oil/Gas', 'website': 'pluspetrol.net'},
        {'name': 'CNPC Peru', 'country': 'PE', 'city': 'Lima', 'sector': 'Oil/Gas'},
        {'name': 'Hunt Oil Peru', 'country': 'PE', 'city': 'Lima', 'sector': 'Oil/Gas'},
        {'name': 'Petroperu', 'country': 'PE', 'city': 'Lima', 'sector': 'Oil/Gas', 'website': 'petroperu.com.pe'},
        # Fishing
        {'name': 'TASA (Tecnologica de Alimentos)', 'country': 'PE', 'city': 'Lima', 'sector': 'Fishing/Fishmeal', 'website': 'tasa.com.pe'},
        {'name': 'Austral Group', 'country': 'PE', 'city': 'Lima', 'sector': 'Fishing/Fishmeal', 'website': 'austral.com.pe'},
        {'name': 'Exalmar', 'country': 'PE', 'city': 'Lima', 'sector': 'Fishing/Fishmeal', 'website': 'exalmar.com.pe'},
        {'name': 'Copeinca', 'country': 'PE', 'city': 'Lima', 'sector': 'Fishing/Fishmeal'},
        {'name': 'CFG Investment', 'country': 'PE', 'city': 'Lima', 'sector': 'Fishing/Fishmeal'},
        # Agriculture
        {'name': 'Camposol', 'country': 'PE', 'city': 'Lima', 'sector': 'Agriculture/Fruits', 'website': 'camposol.com.pe'},
        {'name': 'Danper', 'country': 'PE', 'city': 'Trujillo', 'sector': 'Agriculture', 'website': 'danper.com'},
        {'name': 'Viru S.A.', 'country': 'PE', 'city': 'La Libertad', 'sector': 'Agriculture', 'website': 'viru.com.pe'},
        {'name': 'Gandules', 'country': 'PE', 'city': 'Chiclayo', 'sector': 'Agriculture'},
        {'name': 'Sociedad Agricola Drokasa (AGROKASA)', 'country': 'PE', 'city': 'Ica', 'sector': 'Grapes/Asparagus'},
        {'name': 'Complejo Agroindustrial Beta', 'country': 'PE', 'city': 'Chincha', 'sector': 'Agriculture'},
        # Coffee
        {'name': 'COCLA', 'country': 'PE', 'city': 'Cusco', 'sector': 'Coffee', 'website': 'cocla.com.pe'},
        {'name': 'Perhusa (Altomayo)', 'country': 'PE', 'city': 'Lima', 'sector': 'Coffee'},
        # Textiles
        {'name': 'Creditex', 'country': 'PE', 'city': 'Lima', 'sector': 'Textiles', 'website': 'creditex.com.pe'},
        {'name': 'Michell y Cia', 'country': 'PE', 'city': 'Arequipa', 'sector': 'Alpaca/Textiles', 'website': 'michell.com.pe'},
        {'name': 'Inca Tops', 'country': 'PE', 'city': 'Arequipa', 'sector': 'Alpaca/Textiles', 'website': 'incatops.com'},
    ]

def get_ecuador_companies():
    """Ecuador major companies and exporters"""
    return [
        # Oil
        {'name': 'Petroecuador', 'country': 'EC', 'city': 'Quito', 'sector': 'Oil/Gas', 'website': 'eppetroecuador.ec'},
        {'name': 'Petroamazonas', 'country': 'EC', 'city': 'Quito', 'sector': 'Oil/Gas'},
        {'name': 'Repsol Ecuador', 'country': 'EC', 'city': 'Quito', 'sector': 'Oil/Gas'},
        {'name': 'ENAP Sipec (Chile)', 'country': 'EC', 'city': 'Quito', 'sector': 'Oil/Gas'},
        # Bananas
        {'name': 'Reybanpac (Favorita)', 'country': 'EC', 'city': 'Guayaquil', 'sector': 'Bananas', 'website': 'rfrsa.com'},
        {'name': 'Ubesa', 'country': 'EC', 'city': 'Guayaquil', 'sector': 'Bananas', 'website': 'ubesa.com.ec'},
        {'name': 'Truisfruit', 'country': 'EC', 'city': 'Guayaquil', 'sector': 'Bananas'},
        {'name': 'Palmar', 'country': 'EC', 'city': 'Machala', 'sector': 'Bananas'},
        {'name': 'Noboa Corporation', 'country': 'EC', 'city': 'Guayaquil', 'sector': 'Bananas', 'website': 'gruponomoa.com'},
        {'name': 'Oro Banana', 'country': 'EC', 'city': 'Machala', 'sector': 'Bananas'},
        # Shrimp
        {'name': 'Industrial Pesquera Santa Priscila (IPSP)', 'country': 'EC', 'city': 'Guayaquil', 'sector': 'Shrimp', 'website': 'santapriscila.com'},
        {'name': 'Omarsa', 'country': 'EC', 'city': 'Guayaquil', 'sector': 'Shrimp', 'website': 'omarsa.com'},
        {'name': 'Promarisco', 'country': 'EC', 'city': 'Guayaquil', 'sector': 'Shrimp', 'website': 'promarisco.com'},
        {'name': 'Songa', 'country': 'EC', 'city': 'Guayaquil', 'sector': 'Shrimp'},
        {'name': 'Expalsa', 'country': 'EC', 'city': 'Guayaquil', 'sector': 'Shrimp', 'website': 'expalsa.com'},
        {'name': 'Grupo Alcon', 'country': 'EC', 'city': 'Guayaquil', 'sector': 'Shrimp'},
        # Cacao/Coffee
        {'name': 'Republica del Cacao', 'country': 'EC', 'city': 'Quito', 'sector': 'Cacao', 'website': 'republicadelcacao.com'},
        {'name': 'Pacari', 'country': 'EC', 'city': 'Quito', 'sector': 'Cacao', 'website': 'pacarichocolate.com'},
        {'name': 'Cofina', 'country': 'EC', 'city': 'Guayaquil', 'sector': 'Coffee'},
        # Flowers
        {'name': 'Florexpo (Rosaprima)', 'country': 'EC', 'city': 'Quito', 'sector': 'Flowers', 'website': 'rfrprima.com'},
        {'name': 'Falconfarms', 'country': 'EC', 'city': 'Cayambe', 'sector': 'Flowers', 'website': 'falconfarms.com'},
        {'name': 'Nevado Ecuador', 'country': 'EC', 'city': 'Quito', 'sector': 'Flowers', 'website': 'nevadoecuador.com'},
        {'name': 'Florecal', 'country': 'EC', 'city': 'Cayambe', 'sector': 'Flowers'},
        # Tuna
        {'name': 'NIRSA', 'country': 'EC', 'city': 'Guayaquil', 'sector': 'Tuna', 'website': 'nirsa.com'},
        {'name': 'Eurofish', 'country': 'EC', 'city': 'Manta', 'sector': 'Tuna'},
        {'name': 'Conservas Isabel', 'country': 'EC', 'city': 'Manta', 'sector': 'Tuna'},
        {'name': 'Tecopesca', 'country': 'EC', 'city': 'Manta', 'sector': 'Tuna'},
    ]

def get_venezuela_companies():
    """Venezuela major companies (limited due to sanctions)"""
    return [
        # Oil
        {'name': 'PDVSA', 'country': 'VE', 'city': 'Caracas', 'sector': 'Oil/Gas', 'website': 'pdvsa.com'},
        {'name': 'CITGO (PDVSA)', 'country': 'VE', 'city': 'Houston', 'sector': 'Oil/Gas'},
        # Aluminum
        {'name': 'CVG Venalum', 'country': 'VE', 'city': 'Puerto Ordaz', 'sector': 'Aluminum'},
        {'name': 'CVG Alcasa', 'country': 'VE', 'city': 'Puerto Ordaz', 'sector': 'Aluminum'},
        {'name': 'CVG Bauxilum', 'country': 'VE', 'city': 'Puerto Ordaz', 'sector': 'Bauxite'},
        # Steel
        {'name': 'Sidor', 'country': 'VE', 'city': 'Puerto Ordaz', 'sector': 'Steel'},
        # Mining
        {'name': 'CVG Minerven', 'country': 'VE', 'city': 'El Callao', 'sector': 'Gold'},
        {'name': 'CVG Ferrominera Orinoco', 'country': 'VE', 'city': 'Puerto Ordaz', 'sector': 'Iron Ore'},
        # Food/Agriculture (private sector)
        {'name': 'Empresas Polar', 'country': 'VE', 'city': 'Caracas', 'sector': 'Food/Beverages', 'website': 'empresaspolar.com'},
        {'name': 'Cargill Venezuela', 'country': 'VE', 'city': 'Caracas', 'sector': 'Grains'},
        {'name': 'Ron Santa Teresa', 'country': 'VE', 'city': 'Aragua', 'sector': 'Beverages', 'website': 'rfrnsantateresa.com'},
        {'name': 'Savoy (Nestle)', 'country': 'VE', 'city': 'Caracas', 'sector': 'Food'},
    ]

def get_guyana_companies():
    """Guyana major companies and exporters"""
    return [
        # Oil (new major player)
        {'name': 'ExxonMobil Guyana', 'country': 'GY', 'city': 'Georgetown', 'sector': 'Oil/Gas', 'website': 'exxonmobil.com'},
        {'name': 'Hess Guyana', 'country': 'GY', 'city': 'Georgetown', 'sector': 'Oil/Gas'},
        {'name': 'CNOOC Guyana', 'country': 'GY', 'city': 'Georgetown', 'sector': 'Oil/Gas'},
        # Gold/Mining
        {'name': 'Guyana Goldfields', 'country': 'GY', 'city': 'Georgetown', 'sector': 'Gold'},
        {'name': 'Troy Resources Guyana', 'country': 'GY', 'city': 'Georgetown', 'sector': 'Gold'},
        {'name': 'Omai Gold Mines', 'country': 'GY', 'city': 'Georgetown', 'sector': 'Gold'},
        # Bauxite
        {'name': 'Bosai Minerals (China)', 'country': 'GY', 'city': 'Linden', 'sector': 'Bauxite'},
        {'name': 'First Bauxite Corporation', 'country': 'GY', 'city': 'Georgetown', 'sector': 'Bauxite'},
        # Sugar/Agriculture
        {'name': 'Guyana Sugar Corporation (GuySuCo)', 'country': 'GY', 'city': 'Georgetown', 'sector': 'Sugar', 'website': 'guysuco.com'},
        {'name': 'Demerara Distillers (DDL)', 'country': 'GY', 'city': 'Georgetown', 'sector': 'Rum/Beverages', 'website': 'demrum.com'},
        # Rice
        {'name': 'Guyana Rice Development Board (GRDB)', 'country': 'GY', 'city': 'Georgetown', 'sector': 'Rice', 'website': 'grdb.gy'},
        {'name': 'Nand Persaud & Company', 'country': 'GY', 'city': 'Georgetown', 'sector': 'Rice'},
        # Timber
        {'name': 'Barama Company', 'country': 'GY', 'city': 'Georgetown', 'sector': 'Timber'},
    ]

def get_suriname_companies():
    """Suriname major companies and exporters"""
    return [
        # Oil/Gas
        {'name': 'Staatsolie', 'country': 'SR', 'city': 'Paramaribo', 'sector': 'Oil/Gas', 'website': 'staatsolie.com'},
        {'name': 'Apache Suriname', 'country': 'SR', 'city': 'Paramaribo', 'sector': 'Oil/Gas'},
        {'name': 'TotalEnergies Suriname', 'country': 'SR', 'city': 'Paramaribo', 'sector': 'Oil/Gas'},
        # Gold/Mining
        {'name': 'Newmont Suriname', 'country': 'SR', 'city': 'Paramaribo', 'sector': 'Gold'},
        {'name': 'IAMGOLD Rosebel', 'country': 'SR', 'city': 'Paramaribo', 'sector': 'Gold'},
        {'name': 'Grassalco', 'country': 'SR', 'city': 'Paramaribo', 'sector': 'Mining', 'website': 'grassalco.com'},
        # Bauxite/Aluminum
        {'name': 'Suralco (Alcoa)', 'country': 'SR', 'city': 'Paranam', 'sector': 'Bauxite'},
        # Agriculture
        {'name': 'Surland', 'country': 'SR', 'city': 'Paramaribo', 'sector': 'Rice'},
        {'name': 'NV SPBA (Bananas)', 'country': 'SR', 'city': 'Paramaribo', 'sector': 'Bananas'},
        # Timber
        {'name': 'SBB (Stichting Bosbeheer)', 'country': 'SR', 'city': 'Paramaribo', 'sector': 'Timber', 'website': 'sfrb.sr'},
        # Fishing
        {'name': 'SAIL (Suriname American Industries)', 'country': 'SR', 'city': 'Paramaribo', 'sector': 'Fishing/Shrimp'},
    ]

def download_all():
    """Download all MERCOSUR countries data"""
    all_data = {
        'PY': get_paraguay_companies(),
        'BO': get_bolivia_companies(),
        'PE': get_peru_companies(),
        'EC': get_ecuador_companies(),
        'VE': get_venezuela_companies(),
        'GY': get_guyana_companies(),
        'SR': get_suriname_companies(),
    }
    
    total = 0
    for country, data in all_data.items():
        output_file = OUTPUT_DIR / f'{country.lower()}_companies_{datetime.now():%Y%m%d}.json'
        with open(output_file, 'w') as f:
            json.dump(data, f, indent=2)
        logger.info(f"Saved {len(data)} {country} companies")
        total += len(data)
    
    # Combined file
    combined = []
    for data in all_data.values():
        combined.extend(data)
    
    with open(OUTPUT_DIR / f'mercosur_missing_countries_{datetime.now():%Y%m%d}.json', 'w') as f:
        json.dump(combined, f, indent=2)
    
    logger.info(f"Total: {total} companies from {len(all_data)} countries")
    return combined

def show_stats():
    """Show statistics"""
    files = list(OUTPUT_DIR.glob('*_companies_*.json'))
    if not files:
        logger.info("No data. Run --download first.")
        return
    
    print(f"\n{'='*60}")
    print("MERCOSUR MISSING COUNTRIES DATA")
    print(f"{'='*60}\n")
    
    total = 0
    for f in sorted(files):
        if 'mercosur_missing' in f.name:
            continue
        with open(f) as fp:
            data = json.load(fp)
        country = f.stem.split('_')[0].upper()
        sectors = {}
        for e in data:
            s = e.get('sector', 'Unknown')
            sectors[s] = sectors.get(s, 0) + 1
        print(f"{country}: {len(data)} companies")
        for s, c in sorted(sectors.items(), key=lambda x: -x[1])[:5]:
            print(f"  - {s}: {c}")
        total += len(data)
        print()
    
    print(f"TOTAL: {total} companies")

def import_to_db():
    """Import to database"""
    import psycopg2
    
    files = list(OUTPUT_DIR.glob('*_companies_*.json'))
    if not files:
        logger.error("No data files")
        return
    
    conn = psycopg2.connect(dbname='interjob_master', user='tudor')
    cur = conn.cursor()
    total = 0
    
    for f in files:
        if 'mercosur_missing' in f.name:
            continue
        with open(f) as fp:
            data = json.load(fp)
        
        country = f.stem.split('_')[0].upper()
        source = f'MERCOSUR_{country}_Companies'
        
        for e in data:
            try:
                cur.execute("""
                    INSERT INTO companies (name, country, city, sector, website, source, created_at)
                    VALUES (%s, %s, %s, %s, %s, %s, NOW())
                    ON CONFLICT DO NOTHING
                """, (
                    e.get('name'),
                    e.get('country', country),
                    e.get('city'),
                    e.get('sector'),
                    e.get('website'),
                    source
                ))
                if cur.rowcount > 0:
                    total += 1
            except Exception as ex:
                logger.warning(f"Error: {ex}")
    
    conn.commit()
    cur.close()
    conn.close()
    logger.info(f"Imported {total} companies from missing MERCOSUR countries")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='MERCOSUR All Countries Data')
    parser.add_argument('--stats', action='store_true')
    parser.add_argument('--download', action='store_true')
    parser.add_argument('--import', dest='do_import', action='store_true')
    args = parser.parse_args()
    
    if args.stats:
        show_stats()
    elif args.download:
        download_all()
    elif args.do_import:
        import_to_db()
    else:
        download_all()
