#!/usr/bin/env python3
"""
MERCOSUR Data Orchestrator
Manages all MERCOSUR country data imports.

Usage:
    python3 mercosur_all.py --status          # Show all country status
    python3 mercosur_all.py --download BR     # Download Brazil data
    python3 mercosur_all.py --download ALL    # Download all countries
    python3 mercosur_all.py --import BR       # Import Brazil
    python3 mercosur_all.py --import ALL      # Import all countries
    python3 mercosur_all.py --report          # Generate MERCOSUR report
"""

import sys
import json
import subprocess
from pathlib import Path
from datetime import datetime
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

SCRIPTS_DIR = Path(__file__).parent
MERCOSUR_DIR = SCRIPTS_DIR.parent

sys.path.insert(0, str(MERCOSUR_DIR.parent))
from base import get_db

# Country configurations
COUNTRIES = {
    'BR': {
        'name': 'Brazil',
        'script': 'brazil_cnpj.py',
        'sources': ['CNPJ (50M companies)', 'Compras.gov.br (procurement)'],
        'estimated': 50000000
    },
    'AR': {
        'name': 'Argentina',
        'script': 'argentina_afip.py',
        'sources': ['AFIP (5M taxpayers)', 'datos.gob.ar (open data)'],
        'estimated': 5000000
    },
    'PY': {
        'name': 'Paraguay',
        'script': 'paraguay_dncp.py',
        'sources': ['DNCP (500K+ tenders)', 'datos.gov.py'],
        'estimated': 500000
    },
    'UY': {
        'name': 'Uruguay',
        'script': 'uruguay_dgi.py',
        'sources': ['DGI (300K companies)', 'datos.gub.uy'],
        'estimated': 300000
    },
    'CL': {
        'name': 'Chile',
        'script': 'chile_sii.py',
        'sources': ['SII (1M+ companies)', 'ChileCompra (procurement)'],
        'estimated': 1000000
    },
    'CO': {
        'name': 'Colombia',
        'script': 'colombia_rues.py',
        'sources': ['RUES (2M companies)', 'SECOP (procurement)'],
        'estimated': 2000000
    },
    'PE': {
        'name': 'Peru',
        'script': 'peru_sunat.py',
        'sources': ['SUNAT (2M companies)', 'OSCE (procurement)'],
        'estimated': 2000000
    },
    'EC': {
        'name': 'Ecuador',
        'script': 'ecuador_sri.py',
        'sources': ['SRI (500K companies)', 'SERCOP (procurement)'],
        'estimated': 500000
    },
    'BO': {
        'name': 'Bolivia',
        'script': 'bolivia_seprec.py',
        'sources': ['SEPREC (200K companies)', 'SICOES (procurement)'],
        'estimated': 200000
    }
}


def run_script(country: str, action: str, extra_args: list = None):
    """Run a country-specific script."""
    config = COUNTRIES.get(country)
    if not config:
        logger.error(f"Unknown country: {country}")
        return False

    script_path = SCRIPTS_DIR / config['script']
    if not script_path.exists():
        logger.warning(f"Script not found: {script_path}")
        return False

    cmd = ['python3', str(script_path), f'--{action}']
    if extra_args:
        cmd.extend(extra_args)

    logger.info(f"Running: {' '.join(cmd)}")

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
        print(result.stdout)
        if result.stderr:
            print(result.stderr)
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        logger.error(f"Script timed out: {config['script']}")
        return False
    except Exception as e:
        logger.error(f"Script error: {e}")
        return False


def get_database_stats() -> dict:
    """Get current database statistics by country."""
    stats = {}

    try:
        conn = get_db()
        cur = conn.cursor()

        # Companies by country
        cur.execute("""
            SELECT country, source, COUNT(*)
            FROM companies
            WHERE country IN ('BR', 'AR', 'PY', 'UY', 'CL', 'CO', 'PE', 'EC', 'BO')
            GROUP BY country, source
            ORDER BY country, COUNT(*) DESC
        """)

        for country, source, count in cur.fetchall():
            if country not in stats:
                stats[country] = {'companies': 0, 'by_source': {}}
            stats[country]['companies'] += count
            stats[country]['by_source'][source] = count

        # Procurement by country
        cur.execute("""
            SELECT country, source, COUNT(*)
            FROM procurement_awards
            WHERE country IN ('BR', 'AR', 'PY', 'UY', 'CL', 'CO', 'PE', 'EC', 'BO')
            GROUP BY country, source
        """)

        for country, source, count in cur.fetchall():
            if country not in stats:
                stats[country] = {'companies': 0, 'by_source': {}}
            stats[country]['procurement'] = stats[country].get('procurement', 0) + count

        conn.close()

    except Exception as e:
        logger.error(f"Database error: {e}")

    return stats


def show_status():
    """Show status of all MERCOSUR countries."""
    print("\n" + "="*80)
    print("MERCOSUR DATA STATUS")
    print("="*80)
    print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")

    # Get database stats
    db_stats = get_database_stats()

    print("\n" + "-"*80)
    print(f"{'Country':<12} {'Name':<15} {'Est. Records':<15} {'In DB':<15} {'Status'}")
    print("-"*80)

    total_est = 0
    total_db = 0

    for code, config in COUNTRIES.items():
        country_stats = db_stats.get(code, {})
        in_db = country_stats.get('companies', 0)
        est = config['estimated']
        total_est += est
        total_db += in_db

        if in_db == 0:
            status = "NOT IMPORTED"
        elif in_db < est * 0.5:
            status = "PARTIAL"
        else:
            status = "OK"

        script_exists = (SCRIPTS_DIR / config['script']).exists()
        script_status = "[READY]" if script_exists else "[MISSING]"

        print(f"{code:<12} {config['name']:<15} {est:>12,}   {in_db:>12,}   {status} {script_status}")

    print("-"*80)
    print(f"{'TOTAL':<12} {'':<15} {total_est:>12,}   {total_db:>12,}")

    # Show sources detail
    print("\n" + "-"*80)
    print("DATA SOURCES BY COUNTRY")
    print("-"*80)

    for code, config in COUNTRIES.items():
        print(f"\n{code} - {config['name']}:")
        for src in config['sources']:
            print(f"    - {src}")

        if code in db_stats and db_stats[code].get('by_source'):
            print("  Imported:")
            for src, cnt in db_stats[code]['by_source'].items():
                print(f"    {src}: {cnt:,}")


def download_country(country: str):
    """Download data for a country."""
    if country.upper() == 'ALL':
        for code in COUNTRIES:
            logger.info(f"\n{'='*40}")
            logger.info(f"Downloading {COUNTRIES[code]['name']}...")
            logger.info('='*40)
            run_script(code, 'download')
    else:
        run_script(country.upper(), 'download')


def import_country(country: str, limit: int = 0):
    """Import data for a country."""
    extra_args = []
    if limit > 0:
        extra_args = ['--limit', str(limit)]

    if country.upper() == 'ALL':
        for code in COUNTRIES:
            logger.info(f"\n{'='*40}")
            logger.info(f"Importing {COUNTRIES[code]['name']}...")
            logger.info('='*40)
            run_script(code, 'import', extra_args)
    else:
        run_script(country.upper(), 'import', extra_args)


def generate_report():
    """Generate MERCOSUR data report."""
    db_stats = get_database_stats()

    report = {
        'generated': datetime.now().isoformat(),
        'region': 'MERCOSUR',
        'countries': {},
        'totals': {
            'companies': 0,
            'procurement': 0
        }
    }

    for code, config in COUNTRIES.items():
        country_stats = db_stats.get(code, {})

        report['countries'][code] = {
            'name': config['name'],
            'estimated': config['estimated'],
            'companies': country_stats.get('companies', 0),
            'procurement': country_stats.get('procurement', 0),
            'sources': config['sources'],
            'coverage': round(country_stats.get('companies', 0) / config['estimated'] * 100, 1) if config['estimated'] else 0
        }

        report['totals']['companies'] += country_stats.get('companies', 0)
        report['totals']['procurement'] += country_stats.get('procurement', 0)

    # Save report
    report_path = MERCOSUR_DIR / 'mercosur_report.json'
    with open(report_path, 'w') as f:
        json.dump(report, f, indent=2)

    print(f"\nReport saved to: {report_path}")

    # Print summary
    print("\n" + "="*60)
    print("MERCOSUR DATA REPORT")
    print("="*60)
    print(f"\nTotal Companies: {report['totals']['companies']:,}")
    print(f"Total Procurement: {report['totals']['procurement']:,}")

    print("\nBy Country:")
    for code, data in report['countries'].items():
        print(f"  {code} {data['name']}: {data['companies']:,} companies ({data['coverage']}% coverage)")


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='MERCOSUR Data Orchestrator')
    parser.add_argument('--status', '-s', action='store_true', help='Show status')
    parser.add_argument('--download', '-d', help='Download country (BR/AR/PY/UY/CL/CO/PE/EC/BO or ALL)')
    parser.add_argument('--import', '-i', dest='do_import', help='Import country')
    parser.add_argument('--report', '-r', action='store_true', help='Generate report')
    parser.add_argument('--limit', '-l', type=int, default=0, help='Limit import rows')

    args = parser.parse_args()

    if args.download:
        download_country(args.download)
    elif args.do_import:
        import_country(args.do_import, args.limit)
    elif args.report:
        generate_report()
    else:
        show_status()
