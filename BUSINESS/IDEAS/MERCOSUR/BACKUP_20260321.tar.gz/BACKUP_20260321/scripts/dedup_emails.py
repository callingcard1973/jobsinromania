#!/usr/bin/env python3
"""
Email Deduplication Script
Removes duplicate emails from companies table in batches
"""

import psycopg2
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')
logger = logging.getLogger(__name__)

BATCH_SIZE = 50000

def dedup_emails():
    conn = psycopg2.connect(dbname='interjob_master', user='tudor')
    conn.autocommit = True
    cur = conn.cursor()
    
    # Get stats before
    cur.execute("""
        SELECT COUNT(*), COUNT(DISTINCT LOWER(email))
        FROM companies WHERE email IS NOT NULL AND email != ''
    """)
    total, unique = cur.fetchone()
    duplicates = total - unique
    
    logger.info(f"Total emails: {total:,}")
    logger.info(f"Unique emails: {unique:,}")
    logger.info(f"Duplicates to remove: {duplicates:,}")
    
    if duplicates == 0:
        logger.info("No duplicates found!")
        return
    
    # Process in batches
    total_removed = 0
    batch = 0
    
    while True:
        batch += 1
        cur.execute("""
            WITH ranked AS (
                SELECT id, email,
                    ROW_NUMBER() OVER (
                        PARTITION BY LOWER(email)
                        ORDER BY 
                            CASE WHEN source LIKE 'MERCOSUR%%' THEN 0 ELSE 1 END,
                            created_at DESC NULLS LAST,
                            id DESC
                    ) as rn
                FROM companies
                WHERE email IS NOT NULL AND email != ''
            ),
            to_clear AS (
                SELECT id FROM ranked WHERE rn > 1 LIMIT %s
            )
            UPDATE companies SET email = NULL 
            WHERE id IN (SELECT id FROM to_clear)
            RETURNING id
        """, (BATCH_SIZE,))
        
        removed = cur.rowcount
        total_removed += removed
        
        if removed == 0:
            break
        
        logger.info(f"Batch {batch}: removed {removed:,} duplicates (total: {total_removed:,})")
    
    logger.info(f"DONE! Removed {total_removed:,} duplicate emails")
    
    # Final stats
    cur.execute("""
        SELECT COUNT(*) FROM companies WHERE email IS NOT NULL AND email != ''
    """)
    final = cur.fetchone()[0]
    logger.info(f"Final unique emails: {final:,}")
    
    cur.close()
    conn.close()

if __name__ == '__main__':
    dedup_emails()
