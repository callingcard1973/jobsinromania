#!/usr/bin/env python3
"""
MERCOSUR Aluminum/Bauxite Suppliers Scraper
Fetches aluminum producers and bauxite miners from Brazil, Argentina, Venezuela.

Data Sources:
- BR: IBRAM, ABAL (Brazilian Aluminum Association)
- AR: Aluar (main producer)
- VE: CVG Venalum, Alcasa

Usage:
    python3 aluminum_suppliers.py --stats
    python3 aluminum_suppliers.py --download
    python3 aluminum_suppliers.py --import
"""

import sys
import json
import csv
import requests
from pathlib import Path
from datetime import datetime
from typing import List
import logging
import time

sys.path.insert(0, '/opt/ACTIVE/DB/GLOBAL')
from base import get_db, sanitize, BATCH_SIZE

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s [%(name)s] %(message)s')
logger = logging.getLogger(__name__)

DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/mercosur_aluminum')
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Known major aluminum producers in MERCOSUR region
ALUMINUM_PRODUCERS = [
    # Brazil - World's 3rd largest bauxite producer, 11th aluminum
    {'name': 'Alcoa Brasil', 'country': 'BR', 'type': 'integrated',
     'products': ['alumina', 'primary aluminum', 'bauxite'],
     'location': 'Sao Luis, Maranhao', 'capacity_kt': 450},
    {'name': 'Companhia Brasileira de Aluminio (CBA)', 'country': 'BR', 'type': 'integrated',
     'products': ['primary aluminum', 'rolled products'],
     'location': 'Aluminio, Sao Paulo', 'capacity_kt': 475},
    {'name': 'Albras - Aluminio Brasileiro S.A.', 'country': 'BR', 'type': 'smelter',
     'products': ['primary aluminum', 'ingots', 'billets'],
     'location': 'Barcarena, Para', 'capacity_kt': 460},
    {'name': 'Novelis Brasil', 'country': 'BR', 'type': 'rolling',
     'products': ['aluminum sheets', 'can stock', 'automotive'],
     'location': 'Pindamonhangaba, SP', 'capacity_kt': 600},
    {'name': 'Mineracao Rio do Norte (MRN)', 'country': 'BR', 'type': 'bauxite',
     'products': ['bauxite ore'],
     'location': 'Porto Trombetas, Para', 'capacity_kt': 18000},
    {'name': 'Hydro Alunorte', 'country': 'BR', 'type': 'refinery',
     'products': ['alumina'],
     'location': 'Barcarena, Para', 'capacity_kt': 6300},
    {'name': 'Votorantim Metais', 'country': 'BR', 'type': 'integrated',
     'products': ['primary aluminum', 'alloys'],
     'location': 'Multiple sites', 'capacity_kt': 200},

    # Argentina - Aluar is the sole primary producer
    {'name': 'Aluar Aluminio Argentino S.A.I.C.', 'country': 'AR', 'type': 'integrated',
     'products': ['primary aluminum', 'billets', 'sheets', 'extrusions'],
     'location': 'Puerto Madryn, Chubut', 'capacity_kt': 460,
     'website': 'www.aluar.com.ar', 'notes': 'Sole AR primary producer'},

    # Venezuela - Major producer (though reduced capacity)
    {'name': 'CVG Venalum', 'country': 'VE', 'type': 'smelter',
     'products': ['primary aluminum', 'ingots'],
     'location': 'Ciudad Guayana', 'capacity_kt': 430},
    {'name': 'CVG Alcasa', 'country': 'VE', 'type': 'smelter',
     'products': ['primary aluminum'],
     'location': 'Ciudad Guayana', 'capacity_kt': 210},
    {'name': 'CVG Bauxilum', 'country': 'VE', 'type': 'bauxite',
     'products': ['bauxite', 'alumina'],
     'location': 'Ciudad Guayana', 'capacity_kt': 6000},
]

# Brazilian Aluminum Association (ABAL) members
ABAL_MEMBERS = [
    'Alcoa', 'Albras', 'CBA', 'Novelis', 'Hydro', 'Votorantim',
    'Ball Corporation', 'Crown Holdings', 'Arconic', 'Constellium',
    'Aleris', 'Hindalco', 'Kaiser Aluminum', 'Norsk Hydro',
]


def fetch_brazil_mining_data() -> List[dict]:
    """Fetch data from Brazil mining agency (ANM)."""
    records = []
    # ANM SIGMINE system
    url = "https://sistemas.anm.gov.br/sigmine/ConsultaMineralAPI"
    try:
        # Search for bauxite/aluminum
        params = {'substancia': 'BAUXITA', 'limit': 100}
        resp = requests.get(url, params=params, timeout=60)
        if resp.status_code == 200:
            data = resp.json()
            records.extend(data.get('results', []))
    except Exception as e:
        logger.warning(f"ANM API not available: {e}")
    return records


def get_known_producers() -> List[dict]:
    """Return list of known aluminum producers."""
    return ALUMINUM_PRODUCERS


def extract_suppliers(records: List[dict]) -> List[dict]:
    """Extract supplier info for database."""
    suppliers = []
    for r in records:
        suppliers.append({
            'name': sanitize(r.get('name', '')),
            'country': r.get('country', ''),
            'type': r.get('type', ''),
            'products': ', '.join(r.get('products', [])),
            'location': r.get('location', ''),
            'capacity_kt': r.get('capacity_kt', 0),
            'website': r.get('website', ''),
        })
    return suppliers


def save_suppliers(suppliers: List[dict]):
    """Save suppliers to CSV."""
    output_file = DATA_DIR / f'aluminum_suppliers_{datetime.now():%Y%m%d}.csv'
    if suppliers:
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=suppliers[0].keys())
            writer.writeheader()
            writer.writerows(suppliers)
        logger.info(f"Saved {len(suppliers)} suppliers to {output_file}")


def import_to_db(suppliers: List[dict], dry_run: bool = False):
    """Import suppliers to database."""
    if dry_run:
        logger.info(f"Would import {len(suppliers)} aluminum suppliers")
        return

    conn = get_db()
    cur = conn.cursor()
    inserted = 0

    for s in suppliers:
        try:
            cur.execute("""
                INSERT INTO companies (name, country, source, source_file, city)
                VALUES (%s, %s, %s, %s, %s)
                ON CONFLICT DO NOTHING
            """, (s['name'], s['country'], 'MERCOSUR_Aluminum',
                  'aluminum_suppliers.py', s.get('location', '')))
            inserted += 1
        except Exception as e:
            logger.warning(f"Insert error: {e}")

    conn.commit()
    conn.close()
    logger.info(f"Imported {inserted} aluminum suppliers")


def show_stats():
    """Show aluminum market stats."""
    print("\n" + "="*60)
    print("MERCOSUR ALUMINUM SUPPLIERS STATUS")
    print("="*60)

    print("\nKnown Major Producers:")
    producers = get_known_producers()
    for country in ['BR', 'AR', 'VE']:
        country_prods = [p for p in producers if p['country'] == country]
        if country_prods:
            names = {'BR': 'Brazil', 'AR': 'Argentina', 'VE': 'Venezuela'}
            print(f"\n  {names[country]}:")
            for p in country_prods:
                cap = f"{p['capacity_kt']}kt" if p.get('capacity_kt') else ''
                print(f"    - {p['name']} ({p['type']}) {cap}")

    # Local data
    print(f"\nLocal data: {DATA_DIR}")
    csvs = list(DATA_DIR.glob('*.csv'))
    if csvs:
        for f in csvs[-3:]:
            lines = sum(1 for _ in open(f)) - 1
            print(f"  {f.name}: {lines} records")
    else:
        print("  No local data. Run --download first.")

    # DB stats
    print("\n" + "-"*60)
    print("DATABASE STATS")
    print("-"*60)
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM companies WHERE source = 'MERCOSUR_Aluminum'")
        print(f"  Total aluminum suppliers: {cur.fetchone()[0]}")
        conn.close()
    except Exception as e:
        print(f"  DB error: {e}")

    print("\n" + "-"*60)
    print("ALUMINUM MARKET OVERVIEW")
    print("-"*60)
    print("  Brazil: 3rd world bauxite producer, 11th aluminum")
    print("  Argentina: Aluar sole producer (460kt/year)")
    print("  Venezuela: Major capacity (reduced output)")
    print("")
    print("  Products:")
    print("    - Primary aluminum: Ingots, billets, slabs")
    print("    - Rolled products: Sheets, foil, can stock")
    print("    - Extrusions: Profiles, automotive")
    print("")
    print("  EU Import: ~4M tonnes primary aluminum/year")


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='MERCOSUR Aluminum Suppliers')
    parser.add_argument('--stats', '-s', action='store_true')
    parser.add_argument('--download', '-d', action='store_true')
    parser.add_argument('--import', '-i', dest='do_import', action='store_true')
    parser.add_argument('--dry-run', '-n', action='store_true')

    args = parser.parse_args()

    if args.download:
        # Get known producers + any API data
        producers = get_known_producers()
        api_data = fetch_brazil_mining_data()

        all_records = producers + api_data
        logger.info(f"Got {len(all_records)} aluminum suppliers")

        # Save raw
        with open(DATA_DIR / f'aluminum_raw_{datetime.now():%Y%m%d}.json', 'w') as f:
            json.dump(all_records, f, indent=2, default=str)

        suppliers = extract_suppliers(all_records)
        save_suppliers(suppliers)

        if args.do_import:
            import_to_db(suppliers, args.dry_run)

    else:
        show_stats()
