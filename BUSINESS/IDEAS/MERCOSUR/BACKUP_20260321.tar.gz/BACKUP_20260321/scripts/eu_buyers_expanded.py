#!/usr/bin/env python3
"""
EU Buyers Expanded - Match TED winners to MERCOSUR commodities
"""

import psycopg2
import csv
from pathlib import Path
from datetime import datetime

OUTPUT_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/mercosur_matches')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Expanded MERCOSUR sectors with CPV codes
SECTORS = {
    'sugar': {
        'cpv': ['158%', '0111%'],  # Sugar, sugarcane
        'keywords': ['sugar', 'sucre', 'zucker', 'azucar', 'ethanol'],
        'suppliers': 'Brazil, Argentina (Raizen, Copersucar)'
    },
    'soy': {
        'cpv': ['1541%', '1542%', '0111%'],  # Oils, vegetable fats
        'keywords': ['soy', 'soja', 'vegetable oil', 'oleaginous'],
        'suppliers': 'Brazil, Argentina, Paraguay (Cargill, Bunge, ADM)'
    },
    'copper': {
        'cpv': ['14%', '4461%'],  # Mining, copper products
        'keywords': ['copper', 'cuivre', 'kupfer', 'cobre'],
        'suppliers': 'Chile, Peru (Codelco, Antamina, Southern Copper)'
    },
    'aluminum': {
        'cpv': ['14%', '4453%'],  # Bauxite, aluminum
        'keywords': ['aluminum', 'aluminium', 'bauxite'],
        'suppliers': 'Brazil, Venezuela (Alcoa, CBA, Aluar)'
    },
    'coffee': {
        'cpv': ['0126%', '1586%'],  # Coffee
        'keywords': ['coffee', 'cafe', 'kaffee'],
        'suppliers': 'Brazil, Colombia (Cooxupe, JDE)'
    },
    'poultry': {
        'cpv': ['152%', '0314%'],  # Poultry meat
        'keywords': ['poultry', 'chicken', 'poulet', 'huhn', 'turkey'],
        'suppliers': 'Brazil (BRF, JBS, Aurora)'
    },
    'fruits': {
        'cpv': ['032%', '1533%'],  # Fruits
        'keywords': ['fruit', 'banana', 'orange', 'citrus', 'grape'],
        'suppliers': 'Ecuador, Chile, Brazil (Dole, Citrosuco)'
    },
    'wine': {
        'cpv': ['1593%'],  # Wine
        'keywords': ['wine', 'vin', 'wein', 'vino'],
        'suppliers': 'Argentina, Chile (Concha y Toro, Catena)'
    },
    'steel': {
        'cpv': ['27%', '4431%'],  # Steel
        'keywords': ['steel', 'acier', 'stahl', 'iron'],
        'suppliers': 'Brazil (Gerdau, CSN, Usiminas)'
    },
    'pulp_paper': {
        'cpv': ['211%', '301%'],  # Pulp, paper
        'keywords': ['pulp', 'paper', 'cellulose'],
        'suppliers': 'Brazil, Chile, Uruguay (Suzano, CMPC, UPM)'
    },
    'shrimp': {
        'cpv': ['0312%', '152%'],  # Crustaceans
        'keywords': ['shrimp', 'crevette', 'garnele', 'prawn'],
        'suppliers': 'Ecuador (Santa Priscila, Omarsa)'
    },
    'salmon': {
        'cpv': ['0311%', '152%'],  # Fish
        'keywords': ['salmon', 'saumon', 'lachs'],
        'suppliers': 'Chile (AquaChile, Multiexport)'
    },
}

def fetch_buyers(sector_name, sector_config, limit=1000):
    """Fetch EU buyers for a sector"""
    conn = psycopg2.connect(dbname='interjob_master', user='tudor')
    cur = conn.cursor()
    
    # Build CPV conditions
    cpv_conditions = ' OR '.join([f"cpv LIKE '{cpv}'" for cpv in sector_config['cpv']])
    
    # Build keyword conditions
    kw_conditions = ' OR '.join([f"authority ILIKE '%{kw}%'" for kw in sector_config['keywords']])
    
    query = f"""
        SELECT DISTINCT ON (contractor_email)
            contractor_email as email,
            contractor as company,
            contractor_country as country,
            contractor_city as city,
            contractor_website as website,
            contract_value
        FROM ted_winners
        WHERE contractor_email IS NOT NULL
          AND contractor_email LIKE '%@%'
          AND ({cpv_conditions} OR {kw_conditions})
        ORDER BY contractor_email, contract_value::numeric DESC NULLS LAST
        LIMIT {limit}
    """
    
    try:
        cur.execute(query)
        rows = cur.fetchall()
    except Exception as e:
        print(f"  Error: {e}")
        rows = []
    
    cur.close()
    conn.close()
    return rows

def main():
    print("=" * 60)
    print("EU BUYERS EXPANDED - MERCOSUR SECTORS")
    print("=" * 60)
    print()
    
    total = 0
    
    for sector, config in SECTORS.items():
        print(f"Fetching {sector}...", end=" ", flush=True)
        
        rows = fetch_buyers(sector, config, limit=1000)
        
        if rows:
            output_file = OUTPUT_DIR / f'campaign_{sector}_{datetime.now():%Y%m%d}.csv'
            with open(output_file, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['email', 'company', 'country', 'city', 'website', 'contract_value', 'sector', 'suppliers'])
                for row in rows:
                    writer.writerow(list(row) + [sector, config['suppliers']])
            
            print(f"{len(rows)} buyers -> {output_file.name}")
            total += len(rows)
        else:
            print("0 buyers (query failed or empty)")
    
    print()
    print("=" * 60)
    print(f"TOTAL: {total} EU buyers across {len(SECTORS)} sectors")
    print("=" * 60)

if __name__ == '__main__':
    main()
