#!/usr/bin/env python3
"""
Uruguay ARCE Procurement & RUPE Supplier Scraper
Fetches procurement data and RUPE supplier registry.

API: https://www.comprasestatales.gub.uy/
Data: https://catalogodatos.gub.uy/

Usage:
    python3 uruguay_arce.py --stats
    python3 uruguay_arce.py --rupe              # Fetch RUPE supplier registry
    python3 uruguay_arce.py --fetch --limit 1000
    python3 uruguay_arce.py --import
"""

import sys
import json
import csv
import requests
from pathlib import Path
from datetime import datetime
from typing import List
import logging
import time

sys.path.insert(0, '/opt/ACTIVE/DB/GLOBAL')
from base import get_db, sanitize, BATCH_SIZE

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/uruguay_arce')
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Uruguay CKAN API
CKAN_API = "https://catalogodatos.gub.uy/api/3/action"
COMPRAS_DATASET = "compras-estatales"
REQUEST_DELAY = 1.0

# RUPE datasets by year
RUPE_DATASETS = {
    2025: "arce-registro-unico-de-proveedores-del-estado-rupe-2025",
    2024: "arce-registro-unico-de-proveedores-del-estado-rupe-2024",
}


def search_datasets(query: str = "compras") -> List[dict]:
    """Search CKAN for procurement datasets."""
    url = f"{CKAN_API}/package_search"
    params = {'q': query, 'rows': 20}
    try:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()
        return data.get('result', {}).get('results', [])
    except Exception as e:
        logger.error(f"Search error: {e}")
        return []


def get_dataset_resources(dataset_id: str) -> List[dict]:
    """Get resources for a dataset."""
    url = f"{CKAN_API}/package_show"
    params = {'id': dataset_id}
    try:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()
        return data.get('result', {}).get('resources', [])
    except Exception as e:
        logger.error(f"Dataset error: {e}")
        return []


def fetch_resource_data(resource_url: str, limit: int = 1000) -> List[dict]:
    """Fetch data from a resource URL."""
    try:
        resp = requests.get(resource_url, timeout=120)
        content_type = resp.headers.get('content-type', '')

        if 'json' in content_type:
            data = resp.json()
            return data if isinstance(data, list) else data.get('results', data.get('data', []))
        elif 'csv' in content_type or resource_url.endswith('.csv'):
            # Parse CSV
            import io
            reader = csv.DictReader(io.StringIO(resp.text))
            return list(reader)[:limit]
    except Exception as e:
        logger.error(f"Resource fetch error: {e}")
    return []


def fetch_all_contracts(max_records: int = 5000) -> List[dict]:
    """Fetch all procurement records."""
    all_records = []

    # Search for procurement datasets
    datasets = search_datasets("compras estatales adjudicaciones")

    for ds in datasets:
        if len(all_records) >= max_records:
            break

        resources = ds.get('resources', [])
        for res in resources:
            fmt = res.get('format', '').upper()
            if fmt in ['JSON', 'CSV', 'XLSX']:
                url = res.get('url')
                logger.info(f"Fetching {res.get('name', '')[:40]}...")

                records = fetch_resource_data(url, max_records - len(all_records))
                if records:
                    all_records.extend(records)
                    logger.info(f"  Got {len(records)} records")

                time.sleep(REQUEST_DELAY)

                if len(all_records) >= max_records:
                    break

    return all_records[:max_records]


def fetch_rupe_suppliers(year: int = 2025) -> List[dict]:
    """Fetch RUPE (Registro Unico de Proveedores del Estado) supplier registry."""
    all_suppliers = []

    # Search for RUPE dataset
    datasets = search_datasets(f"RUPE proveedores {year}")

    for ds in datasets:
        if 'rupe' not in ds.get('name', '').lower():
            continue
        if str(year) not in ds.get('title', ''):
            continue

        logger.info(f"Found: {ds.get('title')}")
        resources = ds.get('resources', [])

        for res in resources:
            if res.get('format', '').upper() != 'CSV':
                continue
            if 'diccionario' in res.get('name', '').lower():
                continue

            url = res.get('url')
            name = res.get('name', '')[:40]
            logger.info(f"  Fetching {name}...")

            try:
                resp = requests.get(url, timeout=120)
                resp.encoding = 'utf-8'
                import io
                reader = csv.DictReader(io.StringIO(resp.text), delimiter=';')
                records = list(reader)
                all_suppliers.extend(records)
                logger.info(f"    Got {len(records)} suppliers")
            except Exception as e:
                logger.error(f"    Error: {e}")

            time.sleep(REQUEST_DELAY)
        break  # Only process first matching dataset

    return all_suppliers


def extract_rupe_winners(records: List[dict]) -> List[dict]:
    """Extract supplier info from RUPE registry."""
    winners = []
    for r in records:
        name = r.get('denominacion_social_prov', '')
        rut = r.get('identificacion_prov', '')

        if name:
            winners.append({
                'name': sanitize(str(name)),
                'rut': str(rut) if rut else '',
                'country': 'UY',
                'address': r.get('domicilio_fiscal', ''),
                'city': r.get('localidad_prov', ''),
                'department': r.get('departamento_prov', ''),
                'status': r.get('estado_prov', ''),
            })
    return winners


def extract_winners(records: List[dict]) -> List[dict]:
    """Extract winning companies."""
    winners = []
    for r in records:
        # Adapt to actual Uruguay field names
        name = r.get('proveedor', r.get('adjudicatario', r.get('nombre_empresa', '')))
        rut = r.get('rut', r.get('rut_proveedor', ''))

        if name:
            winners.append({
                'name': sanitize(str(name)),
                'rut': str(rut) if rut else '',
                'country': 'UY',
                'contract_value': r.get('monto', r.get('importe', '')),
                'buyer': r.get('organismo', r.get('entidad', '')),
                'description': sanitize(str(r.get('objeto', r.get('descripcion', ''))))[:500],
            })
    return winners


def save_winners(winners: List[dict]):
    """Save winners to CSV."""
    output_file = DATA_DIR / f'uruguay_winners_{datetime.now():%Y%m%d}.csv'
    if winners:
        seen = set()
        unique = []
        for w in winners:
            key = (w['name'], w.get('rut', ''))
            if key not in seen:
                seen.add(key)
                unique.append(w)

        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=unique[0].keys())
            writer.writeheader()
            writer.writerows(unique)
        logger.info(f"Saved {len(unique)} unique winners to {output_file}")


def import_to_db(winners: List[dict], dry_run: bool = False):
    """Import suppliers to database."""
    if dry_run:
        logger.info(f"Would import {len(winners)} suppliers")
        return

    conn = get_db()
    cur = conn.cursor()

    inserted = 0
    for w in winners:
        try:
            cur.execute("""
                INSERT INTO companies (name, cui, country, source, source_file, city)
                VALUES (%s, %s, %s, %s, %s, %s)
                ON CONFLICT DO NOTHING
            """, (w['name'], w.get('rut', ''), 'UY', 'UY_RUPE', 'uruguay_arce.py',
                  w.get('city', '')))
            inserted += 1
        except Exception as e:
            logger.warning(f"Insert error: {e}")

    conn.commit()
    conn.close()
    logger.info(f"Imported {inserted} companies")


def show_stats():
    """Show stats."""
    print("\n" + "="*60)
    print("URUGUAY ARCE / COMPRAS ESTATALES STATUS")
    print("="*60)

    # Search datasets
    print("\nProcurement datasets on catalogodatos.gub.uy:")
    datasets = search_datasets("compras")
    for ds in datasets[:5]:
        title = ds.get('title', '')[:50]
        resources = len(ds.get('resources', []))
        print(f"  - {title}... ({resources} resources)")

    # Local data
    print(f"\nLocal data: {DATA_DIR}")
    csvs = list(DATA_DIR.glob('*.csv'))
    for f in csvs[-3:]:
        lines = sum(1 for _ in open(f)) - 1
        print(f"  {f.name}: {lines:,} records")

    # DB stats
    print("\nDatabase:")
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM companies WHERE source = 'UY_ARCE'")
        print(f"  UY_ARCE companies: {cur.fetchone()[0]:,}")
        conn.close()
    except Exception as e:
        print(f"  DB error: {e}")


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Uruguay ARCE/RUPE Scraper')
    parser.add_argument('--stats', '-s', action='store_true')
    parser.add_argument('--rupe', '-r', action='store_true', help='Fetch RUPE supplier registry')
    parser.add_argument('--fetch', '-f', action='store_true')
    parser.add_argument('--import', '-i', dest='do_import', action='store_true')
    parser.add_argument('--year', '-y', type=int, default=2025)
    parser.add_argument('--limit', '-l', type=int, default=1000)
    parser.add_argument('--dry-run', '-n', action='store_true')

    args = parser.parse_args()

    if args.rupe:
        records = fetch_rupe_suppliers(args.year)
        logger.info(f"Fetched {len(records)} RUPE suppliers")

        with open(DATA_DIR / f'rupe_{args.year}.json', 'w') as f:
            json.dump(records, f, indent=2, default=str, ensure_ascii=False)

        winners = extract_rupe_winners(records)
        save_winners(winners)

        if args.do_import:
            import_to_db(winners, args.dry_run)

    elif args.fetch:
        records = fetch_all_contracts(args.limit)
        logger.info(f"Fetched {len(records)} contracts")

        with open(DATA_DIR / f'contracts_{datetime.now():%Y%m%d}.json', 'w') as f:
            json.dump(records, f, indent=2, default=str)
    else:
        show_stats()
