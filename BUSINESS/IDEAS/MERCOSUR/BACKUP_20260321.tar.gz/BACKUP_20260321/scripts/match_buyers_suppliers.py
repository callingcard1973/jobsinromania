#!/usr/bin/env python3
"""
Match EU Buyers cu Producători MERCOSUR
Creează fișiere de match pentru campanii
"""

import json
import csv
from pathlib import Path
from datetime import datetime

BUYERS_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/mercosur_matches')
SUPPLIERS_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS')
OUTPUT_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/mercosur_final_matches')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Mapare sectoare -> fișiere producători
SECTOR_MAP = {
    'beef': {
        'buyers': 'eu_beef_meat_buyers.csv',
        'suppliers': 'mercosur_beef/beef_exporters.json',
        'sector_name': 'Carne de vită'
    },
    'honey': {
        'buyers': 'campaign_honey_20260321.csv',
        'suppliers': 'mercosur_honey/honey_exporters.json',
        'sector_name': 'Miere'
    },
    'lithium': {
        'buyers': 'campaign_lithium_20260321.csv',
        'suppliers': 'mercosur_lithium/lithium_suppliers.json',
        'sector_name': 'Litiu'
    },
    'niobium': {
        'buyers': 'campaign_niobium_20260321.csv',
        'suppliers': 'mercosur_niobium/niobium_suppliers.json',
        'sector_name': 'Niobiu'
    },
    'aluminum': {
        'buyers': 'campaign_aluminum_20260321.csv',
        'suppliers': 'mercosur_aluminum/aluminum_raw_20260321.json',
        'sector_name': 'Aluminiu'
    },
    'sugar': {
        'buyers': 'campaign_sugar_20260321.csv',
        'suppliers': 'mercosur_exporters/brazil_exporters_20260321.json',
        'filter_sector': 'Sugar',
        'sector_name': 'Zahăr'
    },
    'coffee': {
        'buyers': 'campaign_coffee_20260321.csv',
        'suppliers': 'mercosur_exporters/brazil_exporters_20260321.json',
        'filter_sector': 'Coffee',
        'sector_name': 'Cafea'
    },
    'wine': {
        'buyers': 'campaign_wine_20260321.csv',
        'suppliers': 'mercosur_exporters/argentina_exporters_20260321.json',
        'filter_sector': 'Wine',
        'sector_name': 'Vin'
    },
    'copper': {
        'buyers': 'campaign_copper_20260321.csv',
        'suppliers': 'mercosur_exporters/chile_exporters_20260321.json',
        'filter_sector': 'Copper',
        'sector_name': 'Cupru'
    },
    'salmon': {
        'buyers': 'campaign_salmon_20260321.csv',
        'suppliers': 'mercosur_exporters/chile_exporters_20260321.json',
        'filter_sector': 'Salmon',
        'sector_name': 'Somon'
    },
    'poultry': {
        'buyers': 'campaign_poultry_20260321.csv',
        'suppliers': 'mercosur_exporters/brazil_exporters_20260321.json',
        'filter_sector': 'Poultry',
        'sector_name': 'Păsări'
    },
    'fruits': {
        'buyers': 'campaign_fruits_20260321.csv',
        'suppliers': 'mercosur_all_countries/ec_companies_20260321.json',
        'filter_sector': 'Bananas',
        'sector_name': 'Fructe'
    },
    'steel': {
        'buyers': 'campaign_steel_20260321.csv',
        'suppliers': 'mercosur_exporters/brazil_exporters_20260321.json',
        'filter_sector': 'Steel',
        'sector_name': 'Oțel'
    },
    'shrimp': {
        'buyers': 'campaign_shrimp_20260321.csv',
        'suppliers': 'mercosur_all_countries/ec_companies_20260321.json',
        'filter_sector': 'Shrimp',
        'sector_name': 'Creveți'
    },
}

def load_suppliers(supplier_file, filter_sector=None):
    """Încarcă producători din JSON"""
    path = SUPPLIERS_DIR / supplier_file
    if not path.exists():
        return []
    
    with open(path) as f:
        data = json.load(f)
    
    if filter_sector:
        data = [s for s in data if filter_sector.lower() in s.get('sector', '').lower()]
    
    return data

def load_buyers(buyer_file):
    """Încarcă cumpărători din CSV"""
    path = BUYERS_DIR / buyer_file
    if not path.exists():
        return []
    
    buyers = []
    with open(path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            buyers.append(row)
    return buyers

def create_match_file(sector, config):
    """Creează fișier de match pentru un sector"""
    buyers = load_buyers(config['buyers'])
    suppliers = load_suppliers(config['suppliers'], config.get('filter_sector'))
    
    if not buyers or not suppliers:
        return 0
    
    # Creează lista de producători ca text
    supplier_list = "; ".join([
        f"{s.get('name', 'N/A')} ({s.get('country', 'XX')})" 
        for s in suppliers[:10]
    ])
    
    if len(suppliers) > 10:
        supplier_list += f" ... și încă {len(suppliers)-10}"
    
    # Scrie fișierul de match
    output_file = OUTPUT_DIR / f"match_{sector}_{datetime.now():%Y%m%d}.csv"
    
    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow([
            'buyer_email', 'buyer_company', 'buyer_country', 'buyer_city',
            'sector', 'mercosur_suppliers', 'num_suppliers'
        ])
        
        for buyer in buyers:
            writer.writerow([
                buyer.get('email', ''),
                buyer.get('company', ''),
                buyer.get('country', ''),
                buyer.get('city', ''),
                config['sector_name'],
                supplier_list,
                len(suppliers)
            ])
    
    return len(buyers)

def main():
    print("=" * 60)
    print("MATCH: CUMPĂRĂTORI UE ↔ PRODUCĂTORI MERCOSUR")
    print("=" * 60)
    print()
    
    total = 0
    
    for sector, config in SECTOR_MAP.items():
        count = create_match_file(sector, config)
        if count > 0:
            print(f"✓ {config['sector_name']}: {count} match-uri")
            total += count
        else:
            print(f"✗ {config['sector_name']}: lipsesc date")
    
    print()
    print("=" * 60)
    print(f"TOTAL: {total} match-uri create")
    print(f"Fișiere: {OUTPUT_DIR}")
    print("=" * 60)

if __name__ == '__main__':
    main()
