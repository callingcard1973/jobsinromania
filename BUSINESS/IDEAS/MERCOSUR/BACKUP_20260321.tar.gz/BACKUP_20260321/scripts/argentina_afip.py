#!/usr/bin/env python3
"""
Argentina AFIP/datos.gob.ar Company Import
Downloads and imports Argentine company data.

Sources:
- datos.gob.ar - Open data portal (CKAN)
- AFIP padron - Tax registry

Usage:
    python3 argentina_afip.py --stats           # Show stats
    python3 argentina_afip.py --download        # Download data
    python3 argentina_afip.py --import          # Import to DB
"""

import sys
import json
import csv
import requests
from pathlib import Path
from typing import Iterator, Optional
import logging
import zipfile
import io

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from base import (
    Company, get_db, insert_companies, download_file,
    sanitize, log, BATCH_SIZE
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Directories
DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/argentina')
DATA_DIR.mkdir(parents=True, exist_ok=True)

# datos.gob.ar CKAN API
CKAN_API = "https://datos.gob.ar/api/3/action/"

# Key datasets
DATASETS = {
    'padron_contribuyentes': {
        'id': 'contribuyentes-padron-alcanzados-monotributo',
        'description': 'Monotributo taxpayers',
        'estimated_records': 3000000
    },
    'empleadores': {
        'id': 'empleadores-afip',
        'description': 'Employers registry',
        'estimated_records': 500000
    },
    'sociedades': {
        'id': 'igj-sociedades',
        'description': 'Registered companies (IGJ)',
        'estimated_records': 200000
    }
}


def search_datasets(query: str = "empresas") -> list:
    """Search for datasets on datos.gob.ar."""
    url = f"{CKAN_API}package_search"
    params = {'q': query, 'rows': 50}

    try:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()
        if data.get('success'):
            return data['result']['results']
    except Exception as e:
        logger.error(f"Search error: {e}")

    return []


def get_dataset_resources(dataset_id: str) -> list:
    """Get resources (files) for a dataset."""
    url = f"{CKAN_API}package_show"
    params = {'id': dataset_id}

    try:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()
        if data.get('success'):
            return data['result'].get('resources', [])
    except Exception as e:
        logger.error(f"Dataset error: {e}")

    return []


def download_resource(resource: dict, output_dir: Path) -> Optional[Path]:
    """Download a CKAN resource."""
    url = resource.get('url')
    name = resource.get('name', 'data')
    fmt = resource.get('format', 'csv').lower()

    if not url:
        return None

    filename = f"{name}.{fmt}".replace(' ', '_').replace('/', '_')
    filepath = output_dir / filename

    if filepath.exists():
        logger.info(f"  {filename} exists, skipping")
        return filepath

    logger.info(f"  Downloading {filename}...")

    try:
        resp = requests.get(url, timeout=120, stream=True)
        resp.raise_for_status()

        with open(filepath, 'wb') as f:
            for chunk in resp.iter_content(chunk_size=8192):
                f.write(chunk)

        return filepath

    except Exception as e:
        logger.error(f"Download error: {e}")
        return None


def parse_monotributo_row(row: dict) -> Optional[Company]:
    """Parse monotributo CSV row."""
    cuit = row.get('cuit', '').strip()
    name = row.get('denominacion', '').strip() or row.get('nombre', '').strip()

    if not cuit or not name:
        return None

    # Format CUIT: XX-XXXXXXXX-X
    if len(cuit) == 11:
        cuit_formatted = f"{cuit[:2]}-{cuit[2:10]}-{cuit[10]}"
    else:
        cuit_formatted = cuit

    # Address
    domicilio = row.get('domicilio_fiscal', '').strip()
    localidad = row.get('localidad', '').strip()
    provincia = row.get('provincia', '').strip()

    # Activity
    actividad = row.get('actividad_principal', '').strip()

    return Company(
        name=name,
        cui=cuit_formatted,
        country='AR',
        city=f"{localidad}, {provincia}" if localidad else provincia,
        address=domicilio if domicilio else None,
        phone=None,
        email=None,
        website=None,
        sector=row.get('codigo_actividad', '').strip() or None,
        sector_name=actividad if actividad else None,
        employees_count=None,
        revenue=None,
        source='AR_AFIP',
        source_file=cuit
    )


def parse_empleador_row(row: dict) -> Optional[Company]:
    """Parse empleadores CSV row."""
    cuit = row.get('cuit_empleador', '').strip() or row.get('cuit', '').strip()
    name = row.get('razon_social', '').strip() or row.get('denominacion', '').strip()

    if not cuit or not name:
        return None

    # Employee count range
    empleados = row.get('promedio_trabajadores', '')
    if empleados:
        try:
            empleados = int(float(empleados))
        except:
            empleados = None
    else:
        empleados = None

    return Company(
        name=name,
        cui=cuit,
        country='AR',
        city=row.get('provincia', '').strip() or None,
        address=None,
        phone=None,
        email=None,
        website=None,
        sector=row.get('actividad', '').strip() or None,
        sector_name=row.get('descripcion_actividad', '').strip() or None,
        employees_count=empleados,
        revenue=None,
        source='AR_AFIP_Empleadores',
        source_file=cuit
    )


def iter_csv_file(filepath: Path) -> Iterator[dict]:
    """Iterate over CSV file rows."""
    encodings = ['utf-8', 'latin-1', 'cp1252']

    for encoding in encodings:
        try:
            with open(filepath, 'r', encoding=encoding, errors='ignore') as f:
                # Try to detect delimiter
                sample = f.read(4096)
                f.seek(0)

                delimiter = ','
                if sample.count(';') > sample.count(','):
                    delimiter = ';'
                elif sample.count('\t') > sample.count(','):
                    delimiter = '\t'

                reader = csv.DictReader(f, delimiter=delimiter)
                for row in reader:
                    yield row
                return
        except Exception as e:
            continue

    logger.error(f"Could not read {filepath}")


def download_argentina_data():
    """Download all available Argentina datasets."""
    logger.info("Searching for Argentina company datasets...")

    # Search for relevant datasets
    queries = ['empresas', 'contribuyentes', 'empleadores', 'sociedades', 'comercio']

    all_datasets = {}
    for q in queries:
        results = search_datasets(q)
        for ds in results:
            all_datasets[ds['id']] = ds

    logger.info(f"Found {len(all_datasets)} datasets")

    # Download resources
    downloaded = []
    for ds_id, ds in all_datasets.items():
        ds_dir = DATA_DIR / ds_id
        ds_dir.mkdir(exist_ok=True)

        resources = get_dataset_resources(ds_id)
        csv_resources = [r for r in resources if r.get('format', '').lower() in ['csv', 'xlsx', 'json']]

        logger.info(f"\n{ds['title']}: {len(csv_resources)} files")

        for res in csv_resources[:3]:  # Limit to 3 files per dataset
            filepath = download_resource(res, ds_dir)
            if filepath:
                downloaded.append(filepath)

    return downloaded


def import_argentina(limit: int = 0, dry_run: bool = False):
    """Import Argentina data to database."""
    if not DATA_DIR.exists():
        logger.error(f"Data directory not found: {DATA_DIR}")
        logger.info("Run with --download first")
        return

    conn = None
    if not dry_run:
        conn = get_db()

    total = 0

    # Find all CSV files
    csv_files = list(DATA_DIR.glob('**/*.csv'))
    logger.info(f"Found {len(csv_files)} CSV files")

    for csv_file in csv_files:
        logger.info(f"Processing {csv_file.name}...")
        batch = []

        # Determine parser based on filename/path
        parser = parse_monotributo_row
        if 'empleador' in str(csv_file).lower():
            parser = parse_empleador_row

        for row in iter_csv_file(csv_file):
            company = parser(row)
            if company:
                batch.append(company)

            if len(batch) >= BATCH_SIZE:
                if not dry_run:
                    inserted = insert_companies(conn, batch)
                    total += inserted
                else:
                    total += len(batch)
                batch = []

                if total % 50000 == 0:
                    logger.info(f"  Processed {total:,}...")

                if limit > 0 and total >= limit:
                    break

        if batch:
            if not dry_run:
                total += insert_companies(conn, batch)
            else:
                total += len(batch)

        if limit > 0 and total >= limit:
            break

    if conn:
        conn.close()

    action = "Would import" if dry_run else "Imported"
    logger.info(f"{action} {total:,} Argentine companies")


def show_stats():
    """Show Argentina data stats."""
    print("\n" + "="*60)
    print("ARGENTINA DATA STATUS")
    print("="*60)

    # Available datasets
    print("\nSearching datos.gob.ar...")
    results = search_datasets('empresas')
    print(f"Found {len(results)} datasets matching 'empresas'")

    for ds in results[:10]:
        print(f"  - {ds['title'][:50]}")

    # Local data
    print(f"\nLocal data: {DATA_DIR}")
    if DATA_DIR.exists():
        for subdir in DATA_DIR.iterdir():
            if subdir.is_dir():
                files = list(subdir.glob('*'))
                print(f"  {subdir.name}: {len(files)} files")

    # Database
    print("\n" + "-"*60)
    print("DATABASE STATS")
    print("-"*60)

    try:
        conn = get_db()
        cur = conn.cursor()

        cur.execute("SELECT source, COUNT(*) FROM companies WHERE country = 'AR' GROUP BY source")
        by_source = cur.fetchall()

        cur.execute("SELECT COUNT(*) FROM companies WHERE country = 'AR'")
        total = cur.fetchone()[0]

        conn.close()

        print(f"  Total AR companies: {total:,}")
        for src, cnt in by_source:
            print(f"    {src}: {cnt:,}")

    except Exception as e:
        print(f"  Database error: {e}")


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Argentina AFIP Import')
    parser.add_argument('--stats', '-s', action='store_true', help='Show stats')
    parser.add_argument('--download', '-d', action='store_true', help='Download data')
    parser.add_argument('--import', '-i', dest='do_import', action='store_true', help='Import to DB')
    parser.add_argument('--limit', '-l', type=int, default=0, help='Limit rows')
    parser.add_argument('--dry-run', '-n', action='store_true', help='Dry run')

    args = parser.parse_args()

    if args.stats:
        show_stats()
    elif args.download:
        download_argentina_data()
        if args.do_import:
            import_argentina(limit=args.limit, dry_run=args.dry_run)
    elif args.do_import:
        import_argentina(limit=args.limit, dry_run=args.dry_run)
    else:
        show_stats()
