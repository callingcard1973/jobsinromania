#!/usr/bin/env python3
"""
Bolivia SEPREC/datos.gob.bo Company Import
Downloads and imports Bolivian company data.

Sources:
- datos.gob.bo - Open data portal (CKAN)
- SEPREC - Business registry (Servicio Plurinacional de Registro de Comercio)
- SICOES - Procurement (Sistema de Contrataciones Estatales)

Usage:
    python3 bolivia_seprec.py --stats           # Show stats
    python3 bolivia_seprec.py --download        # Download data
    python3 bolivia_seprec.py --import          # Import to DB
"""

import sys
import json
import csv
import requests
from pathlib import Path
from typing import Iterator, Optional
import logging

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from base import (
    Company, ProcurementAward, get_db, insert_companies,
    insert_procurement_awards, parse_date, parse_float,
    sanitize, log, BATCH_SIZE
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Directories
DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/bolivia')
DATA_DIR.mkdir(parents=True, exist_ok=True)

# datos.gob.bo CKAN API
CKAN_API = "https://datos.gob.bo/api/3/action/"

# SICOES API (procurement)
SICOES_URL = "https://www.sicoes.gob.bo"

# Key searches
DATASETS = {
    'empresas': {
        'search': 'empresas',
        'description': 'Registered companies',
    },
    'nit': {
        'search': 'NIT contribuyentes',
        'description': 'Tax ID registry',
    },
    'comercio': {
        'search': 'registro comercio',
        'description': 'Commercial registry',
    },
    'contrataciones': {
        'search': 'contrataciones',
        'description': 'Public procurement',
    }
}


def search_datasets(query: str = "empresas") -> list:
    """Search for datasets on datos.gob.bo."""
    url = f"{CKAN_API}package_search"
    params = {'q': query, 'rows': 50}

    try:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()
        if data.get('success'):
            return data['result']['results']
    except Exception as e:
        logger.error(f"Search error: {e}")

    return []


def get_dataset_resources(dataset_id: str) -> list:
    """Get resources (files) for a dataset."""
    url = f"{CKAN_API}package_show"
    params = {'id': dataset_id}

    try:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()
        if data.get('success'):
            return data['result'].get('resources', [])
    except Exception as e:
        logger.error(f"Dataset error: {e}")

    return []


def download_resource(resource: dict, output_dir: Path) -> Optional[Path]:
    """Download a CKAN resource."""
    url = resource.get('url')
    name = resource.get('name', 'data')
    fmt = resource.get('format', 'csv').lower()

    if not url:
        return None

    filename = f"{name}.{fmt}".replace(' ', '_').replace('/', '_')
    filepath = output_dir / filename

    if filepath.exists():
        logger.info(f"  {filename} exists, skipping")
        return filepath

    logger.info(f"  Downloading {filename}...")

    try:
        resp = requests.get(url, timeout=120, stream=True)
        resp.raise_for_status()

        with open(filepath, 'wb') as f:
            for chunk in resp.iter_content(chunk_size=8192):
                f.write(chunk)

        return filepath

    except Exception as e:
        logger.error(f"Download error: {e}")
        return None


def parse_company_row(row: dict) -> Optional[Company]:
    """Parse Bolivia company CSV row."""
    # NIT (Numero de Identificacion Tributaria)
    nit = row.get('nit', '').strip() or row.get('NIT', '').strip()
    name = row.get('razon_social', '').strip() or row.get('nombre', '').strip() or row.get('nombre_comercial', '').strip()

    if not name:
        return None

    # Clean NIT
    if nit:
        nit = ''.join(c for c in nit if c.isdigit())

    # Address
    direccion = row.get('direccion', '').strip() or row.get('domicilio', '').strip()
    localidad = row.get('localidad', '').strip() or row.get('ciudad', '').strip()
    departamento = row.get('departamento', '').strip()

    city = localidad
    if departamento:
        city = f"{localidad}, {departamento}" if localidad else departamento

    # Activity
    actividad = row.get('actividad_economica', '').strip() or row.get('actividad', '').strip()
    codigo_actividad = row.get('codigo_actividad', '').strip() or row.get('ciiu', '').strip()

    return Company(
        name=name,
        cui=nit if nit else None,
        country='BO',
        city=city if city else None,
        address=direccion if direccion else None,
        phone=row.get('telefono', '').strip() or None,
        email=row.get('correo', '').strip() or row.get('email', '').strip() or None,
        website=row.get('pagina_web', '').strip() or row.get('web', '').strip() or None,
        sector=codigo_actividad if codigo_actividad else None,
        sector_name=actividad if actividad else None,
        employees_count=None,
        revenue=None,
        source='BO_SEPREC',
        source_file=nit if nit else name[:50]
    )


def parse_sicoes_row(row: dict) -> Optional[ProcurementAward]:
    """Parse SICOES procurement row."""
    proceso = row.get('codigo_proceso', '').strip() or row.get('cuce', '').strip()
    entidad = row.get('entidad', '').strip() or row.get('entidad_convocante', '').strip()
    proveedor = row.get('proveedor', '').strip() or row.get('adjudicado', '').strip()

    if not proveedor or not entidad:
        return None

    # Value
    valor = row.get('monto_adjudicado', '') or row.get('precio_adjudicado', '')
    valor = parse_float(valor)

    return ProcurementAward(
        source='BO_SICOES',
        source_id=proceso,
        country='BO',
        buyer_name=entidad,
        buyer_type=row.get('tipo_entidad', ''),
        winner_name=proveedor,
        winner_country='BO',
        winner_address=None,
        winner_id=row.get('nit_proveedor', '').strip(),
        title=row.get('objeto', '')[:500] if row.get('objeto') else None,
        description=row.get('descripcion', '')[:1000] if row.get('descripcion') else None,
        contract_value=valor,
        currency='BOB',
        award_date=parse_date(row.get('fecha_adjudicacion', '')),
        start_date=parse_date(row.get('fecha_inicio', '')),
        end_date=parse_date(row.get('fecha_fin', '')),
        category=row.get('modalidad', '') or row.get('tipo_contratacion', ''),
        sector_code=None,
        sector_name=row.get('rubro', ''),
        url=row.get('url', ''),
        raw_data=None
    )


def iter_csv_file(filepath: Path) -> Iterator[dict]:
    """Iterate over CSV file rows."""
    encodings = ['utf-8', 'latin-1', 'cp1252']

    for encoding in encodings:
        try:
            with open(filepath, 'r', encoding=encoding, errors='ignore') as f:
                sample = f.read(4096)
                f.seek(0)

                delimiter = ','
                if sample.count(';') > sample.count(','):
                    delimiter = ';'
                elif sample.count('\t') > sample.count(','):
                    delimiter = '\t'

                reader = csv.DictReader(f, delimiter=delimiter)
                for row in reader:
                    yield row
                return
        except Exception as e:
            continue

    logger.error(f"Could not read {filepath}")


def download_bolivia_data():
    """Download all available Bolivia datasets."""
    logger.info("Searching for Bolivia company datasets...")

    all_datasets = {}
    for key, config in DATASETS.items():
        results = search_datasets(config['search'])
        for ds in results:
            all_datasets[ds['id']] = ds
        logger.info(f"  {key}: found {len(results)} datasets")

    logger.info(f"Total unique datasets: {len(all_datasets)}")

    # Download resources
    downloaded = []
    for ds_id, ds in all_datasets.items():
        ds_dir = DATA_DIR / ds_id
        ds_dir.mkdir(exist_ok=True)

        resources = get_dataset_resources(ds_id)
        csv_resources = [r for r in resources if r.get('format', '').lower() in ['csv', 'xlsx', 'json']]

        logger.info(f"\n{ds.get('title', ds_id)}: {len(csv_resources)} files")

        for res in csv_resources[:3]:
            filepath = download_resource(res, ds_dir)
            if filepath:
                downloaded.append(filepath)

    return downloaded


def import_bolivia(limit: int = 0, dry_run: bool = False):
    """Import Bolivia data to database."""
    if not DATA_DIR.exists():
        logger.error(f"Data directory not found: {DATA_DIR}")
        logger.info("Run with --download first")
        return

    conn = None
    if not dry_run:
        conn = get_db()

    total_companies = 0
    total_procurement = 0

    # Find all CSV files
    csv_files = list(DATA_DIR.glob('**/*.csv'))
    logger.info(f"Found {len(csv_files)} CSV files")

    for csv_file in csv_files:
        logger.info(f"Processing {csv_file.name}...")
        company_batch = []
        procurement_batch = []

        is_sicoes = 'sicoes' in str(csv_file).lower() or 'contrat' in str(csv_file).lower()

        for row in iter_csv_file(csv_file):
            if is_sicoes:
                award = parse_sicoes_row(row)
                if award:
                    procurement_batch.append(award)
            else:
                company = parse_company_row(row)
                if company:
                    company_batch.append(company)

            if len(company_batch) >= BATCH_SIZE:
                if not dry_run:
                    total_companies += insert_companies(conn, company_batch)
                else:
                    total_companies += len(company_batch)
                company_batch = []

            if len(procurement_batch) >= BATCH_SIZE:
                if not dry_run:
                    total_procurement += insert_procurement_awards(conn, procurement_batch)
                else:
                    total_procurement += len(procurement_batch)
                procurement_batch = []

            if (total_companies + total_procurement) % 10000 == 0 and (total_companies + total_procurement) > 0:
                logger.info(f"  Processed {total_companies:,} companies, {total_procurement:,} procurement...")

            if limit > 0 and (total_companies + total_procurement) >= limit:
                break

        # Final batches
        if company_batch:
            if not dry_run:
                total_companies += insert_companies(conn, company_batch)
            else:
                total_companies += len(company_batch)

        if procurement_batch:
            if not dry_run:
                total_procurement += insert_procurement_awards(conn, procurement_batch)
            else:
                total_procurement += len(procurement_batch)

        if limit > 0 and (total_companies + total_procurement) >= limit:
            break

    if conn:
        conn.close()

    action = "Would import" if dry_run else "Imported"
    logger.info(f"{action} {total_companies:,} companies, {total_procurement:,} procurement")


def show_stats():
    """Show Bolivia data stats."""
    print("\n" + "="*60)
    print("BOLIVIA DATA STATUS")
    print("="*60)

    # Available datasets
    print("\nSearching datos.gob.bo...")
    for key, config in DATASETS.items():
        results = search_datasets(config['search'])
        print(f"  {key}: {len(results)} datasets")

    # Local data
    print(f"\nLocal data: {DATA_DIR}")
    if DATA_DIR.exists():
        for subdir in DATA_DIR.iterdir():
            if subdir.is_dir():
                files = list(subdir.glob('*'))
                print(f"  {subdir.name}: {len(files)} files")

    # Database
    print("\n" + "-"*60)
    print("DATABASE STATS")
    print("-"*60)

    try:
        conn = get_db()
        cur = conn.cursor()

        cur.execute("SELECT source, COUNT(*) FROM companies WHERE country = 'BO' GROUP BY source")
        by_source = cur.fetchall()

        cur.execute("SELECT COUNT(*) FROM companies WHERE country = 'BO'")
        total = cur.fetchone()[0]

        cur.execute("SELECT COUNT(*) FROM procurement_awards WHERE country = 'BO'")
        procurement = cur.fetchone()[0]

        conn.close()

        print(f"  Total BO companies: {total:,}")
        print(f"  Total BO procurement: {procurement:,}")
        for src, cnt in by_source:
            print(f"    {src}: {cnt:,}")

    except Exception as e:
        print(f"  Database error: {e}")


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Bolivia SEPREC Import')
    parser.add_argument('--stats', '-s', action='store_true', help='Show stats')
    parser.add_argument('--download', '-d', action='store_true', help='Download data')
    parser.add_argument('--import', '-i', dest='do_import', action='store_true', help='Import to DB')
    parser.add_argument('--limit', '-l', type=int, default=0, help='Limit rows')
    parser.add_argument('--dry-run', '-n', action='store_true', help='Dry run')

    args = parser.parse_args()

    if args.stats:
        show_stats()
    elif args.download:
        download_bolivia_data()
        if args.do_import:
            import_bolivia(limit=args.limit, dry_run=args.dry_run)
    elif args.do_import:
        import_bolivia(limit=args.limit, dry_run=args.dry_run)
    else:
        show_stats()
