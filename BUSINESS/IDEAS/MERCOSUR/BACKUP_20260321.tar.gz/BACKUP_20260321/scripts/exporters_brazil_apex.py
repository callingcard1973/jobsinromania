#!/usr/bin/env python3
"""
Brazil APEX Exporter Directory Scraper
Downloads Brazilian exporters from APEX Brasil (export promotion agency)
"""

import sys
sys.path.insert(0, '/opt/ACTIVE/DB/GLOBAL')
sys.path.insert(0, '/opt/ACTIVE/SCRAPERS/EUROPE/SCRIPTS/SHARED')

import argparse
import json
import logging
import requests
from pathlib import Path
from datetime import datetime
from skills_common import to_ascii

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s [%(name)s] %(message)s')
logger = logging.getLogger(__name__)

OUTPUT_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/mercosur_exporters')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# APEX Brasil sectors
SECTORS = [
    'agribusiness', 'food-beverages', 'machinery-equipment', 
    'automotive', 'chemicals', 'construction', 'textiles',
    'technology', 'mining', 'oil-gas', 'renewable-energy'
]

def fetch_apex_directory():
    """Fetch exporters from APEX Brasil directory"""
    exporters = []
    
    # APEX Brasil API endpoint
    base_url = "https://portal.apexbrasil.com.br/api/v1"
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (compatible; DataCollector/1.0)',
        'Accept': 'application/json'
    }
    
    # Try directory API
    try:
        # Search exporters directory
        url = f"{base_url}/companies/search"
        params = {'limit': 1000, 'export': 'true'}
        resp = requests.get(url, headers=headers, params=params, timeout=30)
        
        if resp.status_code == 200:
            data = resp.json()
            if 'results' in data:
                for company in data['results']:
                    exporters.append({
                        'name': to_ascii(company.get('name', '')),
                        'country': 'BR',
                        'city': to_ascii(company.get('city', '')),
                        'state': company.get('state', ''),
                        'sector': company.get('sector', ''),
                        'website': company.get('website', ''),
                        'email': company.get('email', ''),
                        'phone': company.get('phone', ''),
                        'exports_to': company.get('export_destinations', []),
                        'source': 'APEX_Brasil'
                    })
    except Exception as e:
        logger.warning(f"APEX API not available: {e}")
    
    # Fallback: Known major Brazilian exporters by sector
    if not exporters:
        logger.info("Using curated Brazilian exporter list")
        exporters = get_curated_exporters()
    
    return exporters

def get_curated_exporters():
    """Curated list of major Brazilian exporters"""
    return [
        # Agribusiness/Food
        {'name': 'JBS S.A.', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Meat', 'website': 'jbs.com.br', 'employees': 150000},
        {'name': 'BRF S.A.', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Poultry/Pork', 'website': 'brf.com', 'employees': 90000},
        {'name': 'Marfrig Global Foods', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Beef', 'website': 'marfrig.com.br', 'employees': 30000},
        {'name': 'Minerva Foods', 'country': 'BR', 'city': 'Barretos', 'sector': 'Beef', 'website': 'minervafoods.com', 'employees': 20000},
        {'name': 'Cargill Brasil', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Grains/Food', 'website': 'cargill.com.br'},
        {'name': 'Bunge Brasil', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Grains/Food', 'website': 'bunge.com.br'},
        {'name': 'ADM do Brasil', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Grains', 'website': 'adm.com'},
        {'name': 'Louis Dreyfus Brasil', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Commodities', 'website': 'ldc.com'},
        {'name': 'Citrosuco', 'country': 'BR', 'city': 'Matao', 'sector': 'Orange Juice', 'website': 'citrosuco.com.br'},
        {'name': 'Cutrale', 'country': 'BR', 'city': 'Araraquara', 'sector': 'Orange Juice', 'website': 'cutrale.com.br'},
        # Sugar/Ethanol
        {'name': 'Raizen', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Sugar/Ethanol', 'website': 'raizen.com.br', 'employees': 40000},
        {'name': 'Copersucar', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Sugar/Ethanol', 'website': 'copersucar.com.br'},
        {'name': 'Sao Martinho', 'country': 'BR', 'city': 'Pradopolis', 'sector': 'Sugar/Ethanol', 'website': 'saomartinho.com.br'},
        {'name': 'Biosev', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Sugar/Ethanol', 'website': 'biosev.com'},
        {'name': 'Tereos Brasil', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Sugar', 'website': 'tereos.com'},
        # Mining
        {'name': 'Vale S.A.', 'country': 'BR', 'city': 'Rio de Janeiro', 'sector': 'Iron Ore/Mining', 'website': 'vale.com', 'employees': 70000},
        {'name': 'CSN Mineracao', 'country': 'BR', 'city': 'Congonhas', 'sector': 'Iron Ore', 'website': 'csn.com.br'},
        {'name': 'Anglo American Brasil', 'country': 'BR', 'city': 'Belo Horizonte', 'sector': 'Iron Ore/Nickel', 'website': 'angloamerican.com'},
        {'name': 'Samarco', 'country': 'BR', 'city': 'Mariana', 'sector': 'Iron Ore', 'website': 'samarco.com'},
        {'name': 'CBMM', 'country': 'BR', 'city': 'Araxa', 'sector': 'Niobium', 'website': 'cbmm.com', 'employees': 2000},
        # Pulp & Paper
        {'name': 'Suzano', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Pulp/Paper', 'website': 'suzano.com.br', 'employees': 35000},
        {'name': 'Klabin', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Pulp/Paper', 'website': 'klabin.com.br'},
        {'name': 'Eldorado Brasil', 'country': 'BR', 'city': 'Tres Lagoas', 'sector': 'Pulp', 'website': 'eldoradobrasil.com.br'},
        # Steel/Metals
        {'name': 'Gerdau', 'country': 'BR', 'city': 'Porto Alegre', 'sector': 'Steel', 'website': 'gerdau.com', 'employees': 30000},
        {'name': 'Usiminas', 'country': 'BR', 'city': 'Belo Horizonte', 'sector': 'Steel', 'website': 'usiminas.com'},
        {'name': 'CSN - Cia Siderurgica Nacional', 'country': 'BR', 'city': 'Volta Redonda', 'sector': 'Steel', 'website': 'csn.com.br'},
        {'name': 'ArcelorMittal Brasil', 'country': 'BR', 'city': 'Belo Horizonte', 'sector': 'Steel', 'website': 'arcelormittal.com.br'},
        {'name': 'CBA - Cia Brasileira de Aluminio', 'country': 'BR', 'city': 'Aluminio', 'sector': 'Aluminum', 'website': 'cba.com.br'},
        {'name': 'Alcoa Brasil', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Aluminum', 'website': 'alcoa.com'},
        # Aerospace/Defense
        {'name': 'Embraer', 'country': 'BR', 'city': 'Sao Jose dos Campos', 'sector': 'Aerospace', 'website': 'embraer.com', 'employees': 18000},
        {'name': 'Helibras', 'country': 'BR', 'city': 'Itajuba', 'sector': 'Aerospace', 'website': 'helibras.com.br'},
        # Automotive
        {'name': 'WEG S.A.', 'country': 'BR', 'city': 'Jaragua do Sul', 'sector': 'Electric Motors', 'website': 'weg.net', 'employees': 30000},
        {'name': 'Tupy S.A.', 'country': 'BR', 'city': 'Joinville', 'sector': 'Auto Parts', 'website': 'tupy.com.br'},
        {'name': 'Iochpe-Maxion', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Wheels/Chassis', 'website': 'iochpe.com.br'},
        {'name': 'Randon', 'country': 'BR', 'city': 'Caxias do Sul', 'sector': 'Trailers/Parts', 'website': 'randon.com.br'},
        # Chemicals/Petrochemicals
        {'name': 'Braskem', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Petrochemicals', 'website': 'braskem.com.br', 'employees': 8000},
        {'name': 'Unipar', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Chemicals', 'website': 'unipar.com'},
        # Coffee
        {'name': 'Cooxupe', 'country': 'BR', 'city': 'Guaxupe', 'sector': 'Coffee', 'website': 'cooxupe.com.br'},
        {'name': 'Cocapec', 'country': 'BR', 'city': 'Franca', 'sector': 'Coffee', 'website': 'cocapec.com.br'},
        # Soy/Grains
        {'name': 'Amaggi', 'country': 'BR', 'city': 'Cuiaba', 'sector': 'Soy/Grains', 'website': 'amaggi.com.br'},
        {'name': 'SLC Agricola', 'country': 'BR', 'city': 'Porto Alegre', 'sector': 'Soy/Cotton', 'website': 'slcagricola.com.br'},
        # Shoes/Leather
        {'name': 'Grendene', 'country': 'BR', 'city': 'Sobral', 'sector': 'Footwear', 'website': 'grendene.com.br'},
        {'name': 'Alpargatas', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Footwear', 'website': 'alpargatas.com.br'},
        {'name': 'JBS Couros', 'country': 'BR', 'city': 'Sao Paulo', 'sector': 'Leather', 'website': 'jbscouros.com.br'},
    ]

def download_exporters():
    """Download and save exporters"""
    logger.info("Fetching Brazilian exporters...")
    exporters = fetch_apex_directory()
    
    output_file = OUTPUT_DIR / f'brazil_exporters_{datetime.now():%Y%m%d}.json'
    with open(output_file, 'w') as f:
        json.dump(exporters, f, indent=2)
    
    logger.info(f"Saved {len(exporters)} exporters to {output_file}")
    return exporters

def show_stats():
    """Show exporter statistics"""
    files = list(OUTPUT_DIR.glob('brazil_exporters_*.json'))
    if not files:
        logger.info("No data files found. Run --download first.")
        return
    
    latest = max(files, key=lambda p: p.stat().st_mtime)
    with open(latest) as f:
        data = json.load(f)
    
    print(f"\n{'='*60}")
    print("BRAZIL EXPORTERS STATUS")
    print(f"{'='*60}\n")
    print(f"Total exporters: {len(data)}")
    
    # By sector
    sectors = {}
    for exp in data:
        sector = exp.get('sector', 'Unknown')
        sectors[sector] = sectors.get(sector, 0) + 1
    
    print("\nBy Sector:")
    for sector, count in sorted(sectors.items(), key=lambda x: -x[1]):
        print(f"  {sector}: {count}")

def import_to_db():
    """Import exporters to database"""
    import psycopg2
    
    files = list(OUTPUT_DIR.glob('brazil_exporters_*.json'))
    if not files:
        logger.error("No data files found")
        return
    
    latest = max(files, key=lambda p: p.stat().st_mtime)
    with open(latest) as f:
        data = json.load(f)
    
    conn = psycopg2.connect(dbname='interjob_master', user='tudor')
    cur = conn.cursor()
    
    imported = 0
    for exp in data:
        try:
            cur.execute("""
                INSERT INTO companies (name, country, city, sector, website, email, phone, source)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (name, country) DO UPDATE SET
                    sector = EXCLUDED.sector,
                    website = COALESCE(EXCLUDED.website, companies.website)
            """, (
                exp.get('name'),
                exp.get('country', 'BR'),
                exp.get('city'),
                exp.get('sector'),
                exp.get('website'),
                exp.get('email'),
                exp.get('phone'),
                'MERCOSUR_BR_Exporters'
            ))
            imported += 1
        except Exception as e:
            logger.warning(f"Error importing {exp.get('name')}: {e}")
    
    conn.commit()
    cur.close()
    conn.close()
    logger.info(f"Imported {imported} Brazilian exporters")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Brazil APEX Exporter Scraper')
    parser.add_argument('--stats', action='store_true', help='Show statistics')
    parser.add_argument('--download', action='store_true', help='Download exporters')
    parser.add_argument('--import', dest='do_import', action='store_true', help='Import to database')
    args = parser.parse_args()
    
    if args.stats:
        show_stats()
    elif args.download:
        download_exporters()
    elif args.do_import:
        import_to_db()
    else:
        download_exporters()
