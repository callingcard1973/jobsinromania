#!/usr/bin/env python3
"""
Uruguay DGI/datos.gub.uy Company Import
Downloads and imports Uruguayan company data.

Sources:
- datos.gub.uy - Open data portal (CKAN)
- DGI - Tax registry (limited public access)
- ARCE - Procurement portal

Usage:
    python3 uruguay_dgi.py --stats           # Show stats
    python3 uruguay_dgi.py --download        # Download data
    python3 uruguay_dgi.py --import          # Import to DB
"""

import sys
import json
import csv
import requests
from pathlib import Path
from typing import Iterator, Optional
import logging

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from base import (
    Company, ProcurementAward, get_db, insert_companies,
    insert_procurement_awards, sanitize, log, BATCH_SIZE
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Directories
DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/uruguay')
DATA_DIR.mkdir(parents=True, exist_ok=True)

# datos.gub.uy CKAN API
CKAN_API = "https://catalogodatos.gub.uy/api/3/action/"

# Key datasets
DATASETS = {
    'empresas': {
        'search': 'empresas',
        'description': 'Registered companies',
    },
    'proveedores': {
        'search': 'proveedores estado',
        'description': 'State suppliers',
    },
    'compras': {
        'search': 'compras publicas',
        'description': 'Public procurement',
    }
}


def search_datasets(query: str = "empresas") -> list:
    """Search for datasets on datos.gub.uy."""
    url = f"{CKAN_API}package_search"
    params = {'q': query, 'rows': 50}

    try:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()
        if data.get('success'):
            return data['result']['results']
    except Exception as e:
        logger.error(f"Search error: {e}")

    return []


def get_dataset_resources(dataset_id: str) -> list:
    """Get resources (files) for a dataset."""
    url = f"{CKAN_API}package_show"
    params = {'id': dataset_id}

    try:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()
        if data.get('success'):
            return data['result'].get('resources', [])
    except Exception as e:
        logger.error(f"Dataset error: {e}")

    return []


def download_resource(resource: dict, output_dir: Path) -> Optional[Path]:
    """Download a CKAN resource."""
    url = resource.get('url')
    name = resource.get('name', 'data')
    fmt = resource.get('format', 'csv').lower()

    if not url:
        return None

    filename = f"{name}.{fmt}".replace(' ', '_').replace('/', '_')
    filepath = output_dir / filename

    if filepath.exists():
        logger.info(f"  {filename} exists, skipping")
        return filepath

    logger.info(f"  Downloading {filename}...")

    try:
        resp = requests.get(url, timeout=120, stream=True)
        resp.raise_for_status()

        with open(filepath, 'wb') as f:
            for chunk in resp.iter_content(chunk_size=8192):
                f.write(chunk)

        return filepath

    except Exception as e:
        logger.error(f"Download error: {e}")
        return None


def parse_company_row(row: dict) -> Optional[Company]:
    """Parse Uruguay company CSV row."""
    # RUT (Registro Unico Tributario) - 12 digits
    rut = row.get('rut', '').strip() or row.get('RUT', '').strip()
    name = row.get('razon_social', '').strip() or row.get('nombre', '').strip() or row.get('denominacion', '').strip()

    if not name:
        return None

    # Clean RUT
    if rut:
        rut = ''.join(c for c in rut if c.isdigit())

    # Address
    direccion = row.get('direccion', '').strip() or row.get('domicilio', '').strip()
    localidad = row.get('localidad', '').strip()
    departamento = row.get('departamento', '').strip()

    # Activity
    actividad = row.get('actividad', '').strip() or row.get('giro', '').strip()

    return Company(
        name=name,
        cui=rut if rut else None,
        country='UY',
        city=f"{localidad}, {departamento}" if localidad else departamento,
        address=direccion if direccion else None,
        phone=row.get('telefono', '').strip() or None,
        email=row.get('email', '').strip() or row.get('correo', '').strip() or None,
        website=row.get('web', '').strip() or row.get('sitio_web', '').strip() or None,
        sector=row.get('codigo_actividad', '').strip() or None,
        sector_name=actividad if actividad else None,
        employees_count=None,
        revenue=None,
        source='UY_DGI',
        source_file=rut if rut else name[:50]
    )


def iter_csv_file(filepath: Path) -> Iterator[dict]:
    """Iterate over CSV file rows."""
    encodings = ['utf-8', 'latin-1', 'cp1252']

    for encoding in encodings:
        try:
            with open(filepath, 'r', encoding=encoding, errors='ignore') as f:
                sample = f.read(4096)
                f.seek(0)

                delimiter = ','
                if sample.count(';') > sample.count(','):
                    delimiter = ';'
                elif sample.count('\t') > sample.count(','):
                    delimiter = '\t'

                reader = csv.DictReader(f, delimiter=delimiter)
                for row in reader:
                    yield row
                return
        except Exception as e:
            continue

    logger.error(f"Could not read {filepath}")


def download_uruguay_data():
    """Download all available Uruguay datasets."""
    logger.info("Searching for Uruguay company datasets...")

    all_datasets = {}
    for key, config in DATASETS.items():
        results = search_datasets(config['search'])
        for ds in results:
            all_datasets[ds['id']] = ds
        logger.info(f"  {key}: found {len(results)} datasets")

    logger.info(f"Total unique datasets: {len(all_datasets)}")

    # Download resources
    downloaded = []
    for ds_id, ds in all_datasets.items():
        ds_dir = DATA_DIR / ds_id
        ds_dir.mkdir(exist_ok=True)

        resources = get_dataset_resources(ds_id)
        csv_resources = [r for r in resources if r.get('format', '').lower() in ['csv', 'xlsx', 'json']]

        logger.info(f"\n{ds.get('title', ds_id)}: {len(csv_resources)} files")

        for res in csv_resources[:3]:
            filepath = download_resource(res, ds_dir)
            if filepath:
                downloaded.append(filepath)

    return downloaded


def import_uruguay(limit: int = 0, dry_run: bool = False):
    """Import Uruguay data to database."""
    if not DATA_DIR.exists():
        logger.error(f"Data directory not found: {DATA_DIR}")
        logger.info("Run with --download first")
        return

    conn = None
    if not dry_run:
        conn = get_db()

    total = 0

    # Find all CSV files
    csv_files = list(DATA_DIR.glob('**/*.csv'))
    logger.info(f"Found {len(csv_files)} CSV files")

    for csv_file in csv_files:
        logger.info(f"Processing {csv_file.name}...")
        batch = []

        for row in iter_csv_file(csv_file):
            company = parse_company_row(row)
            if company:
                batch.append(company)

            if len(batch) >= BATCH_SIZE:
                if not dry_run:
                    inserted = insert_companies(conn, batch)
                    total += inserted
                else:
                    total += len(batch)
                batch = []

                if total % 10000 == 0:
                    logger.info(f"  Processed {total:,}...")

                if limit > 0 and total >= limit:
                    break

        if batch:
            if not dry_run:
                total += insert_companies(conn, batch)
            else:
                total += len(batch)

        if limit > 0 and total >= limit:
            break

    if conn:
        conn.close()

    action = "Would import" if dry_run else "Imported"
    logger.info(f"{action} {total:,} Uruguayan companies")


def show_stats():
    """Show Uruguay data stats."""
    print("\n" + "="*60)
    print("URUGUAY DATA STATUS")
    print("="*60)

    # Available datasets
    print("\nSearching datos.gub.uy...")
    for key, config in DATASETS.items():
        results = search_datasets(config['search'])
        print(f"  {key}: {len(results)} datasets")

    # Local data
    print(f"\nLocal data: {DATA_DIR}")
    if DATA_DIR.exists():
        for subdir in DATA_DIR.iterdir():
            if subdir.is_dir():
                files = list(subdir.glob('*'))
                print(f"  {subdir.name}: {len(files)} files")

    # Database
    print("\n" + "-"*60)
    print("DATABASE STATS")
    print("-"*60)

    try:
        conn = get_db()
        cur = conn.cursor()

        cur.execute("SELECT source, COUNT(*) FROM companies WHERE country = 'UY' GROUP BY source")
        by_source = cur.fetchall()

        cur.execute("SELECT COUNT(*) FROM companies WHERE country = 'UY'")
        total = cur.fetchone()[0]

        cur.execute("SELECT COUNT(*) FROM procurement_awards WHERE country = 'UY'")
        procurement = cur.fetchone()[0]

        conn.close()

        print(f"  Total UY companies: {total:,}")
        print(f"  Total UY procurement: {procurement:,}")
        for src, cnt in by_source:
            print(f"    {src}: {cnt:,}")

    except Exception as e:
        print(f"  Database error: {e}")


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Uruguay DGI Import')
    parser.add_argument('--stats', '-s', action='store_true', help='Show stats')
    parser.add_argument('--download', '-d', action='store_true', help='Download data')
    parser.add_argument('--import', '-i', dest='do_import', action='store_true', help='Import to DB')
    parser.add_argument('--limit', '-l', type=int, default=0, help='Limit rows')
    parser.add_argument('--dry-run', '-n', action='store_true', help='Dry run')

    args = parser.parse_args()

    if args.stats:
        show_stats()
    elif args.download:
        download_uruguay_data()
        if args.do_import:
            import_uruguay(limit=args.limit, dry_run=args.dry_run)
    elif args.do_import:
        import_uruguay(limit=args.limit, dry_run=args.dry_run)
    else:
        show_stats()
