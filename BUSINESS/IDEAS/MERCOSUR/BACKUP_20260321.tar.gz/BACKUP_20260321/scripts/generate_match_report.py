#!/usr/bin/env python3
"""
Generate Match Reports (HTML/CSV) from commodity_matches table.

Usage:
    python3 generate_match_report.py --commodity lithium --format html
    python3 generate_match_report.py --all --format csv
    python3 generate_match_report.py --stats
"""

import sys
import csv
import argparse
from pathlib import Path
from datetime import datetime
import logging

sys.path.insert(0, '/opt/ACTIVE/DB/GLOBAL')
from base import get_db

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

OUTPUT_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/mercosur_reports')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def get_matches(commodity: str = None, limit: int = 10000) -> list:
    """Fetch matches from database."""
    conn = get_db()
    cur = conn.cursor()

    query = """
        SELECT commodity, supplier_name, supplier_country, supplier_email, supplier_website,
               buyer_name, buyer_country, buyer_email, match_type, confidence, created_at
        FROM commodity_matches
    """
    params = []
    if commodity:
        query += " WHERE commodity = %s"
        params.append(commodity)
    query += " ORDER BY confidence DESC, created_at DESC LIMIT %s"
    params.append(limit)

    cur.execute(query, params)
    columns = [desc[0] for desc in cur.description]
    results = [dict(zip(columns, row)) for row in cur.fetchall()]
    conn.close()
    return results


def generate_csv(matches: list, output_file: Path):
    """Export matches to CSV."""
    if not matches:
        logger.warning("No matches to export")
        return

    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=matches[0].keys())
        writer.writeheader()
        for m in matches:
            # Convert datetime to string
            if m.get('created_at'):
                m['created_at'] = m['created_at'].strftime('%Y-%m-%d %H:%M')
            writer.writerow(m)

    logger.info(f"Exported {len(matches)} matches to {output_file}")


def generate_html(matches: list, commodity: str, output_file: Path):
    """Generate HTML report."""
    if not matches:
        logger.warning("No matches to export")
        return

    # Group by commodity
    by_commodity = {}
    for m in matches:
        c = m['commodity']
        if c not in by_commodity:
            by_commodity[c] = []
        by_commodity[c].append(m)

    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>MERCOSUR-EU Matches: {commodity or 'All'}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        h1 {{ color: #2c3e50; }}
        h2 {{ color: #34495e; border-bottom: 2px solid #3498db; }}
        table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #3498db; color: white; }}
        tr:nth-child(even) {{ background-color: #f2f2f2; }}
        .high {{ background-color: #d4edda; }}
        .medium {{ background-color: #fff3cd; }}
        .stats {{ background: #ecf0f1; padding: 15px; border-radius: 5px; }}
    </style>
</head>
<body>
    <h1>MERCOSUR-EU Commodity Matches</h1>
    <p>Generated: {datetime.now():%Y-%m-%d %H:%M}</p>

    <div class="stats">
        <strong>Summary:</strong> {len(matches)} total matches across {len(by_commodity)} commodities
    </div>
"""

    for comm, comm_matches in by_commodity.items():
        html += f"""
    <h2>{comm.upper()} ({len(comm_matches)} matches)</h2>
    <table>
        <tr>
            <th>Supplier</th>
            <th>Country</th>
            <th>Buyer</th>
            <th>Country</th>
            <th>Email</th>
            <th>Match</th>
            <th>Conf.</th>
        </tr>
"""
        for m in comm_matches[:100]:  # Limit per section
            conf_class = 'high' if m['confidence'] >= 0.9 else 'medium' if m['confidence'] >= 0.7 else ''
            html += f"""        <tr class="{conf_class}">
            <td>{m['supplier_name'][:50]}</td>
            <td>{m['supplier_country']}</td>
            <td>{m['buyer_name'][:50] if m['buyer_name'] else ''}</td>
            <td>{m['buyer_country']}</td>
            <td>{m['buyer_email'] or ''}</td>
            <td>{m['match_type']}</td>
            <td>{m['confidence']:.0%}</td>
        </tr>
"""
        html += "    </table>\n"

    html += "</body>\n</html>"

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html)
    logger.info(f"Generated HTML report: {output_file}")


def show_stats():
    """Show match statistics."""
    conn = get_db()
    cur = conn.cursor()

    print("\n" + "="*60)
    print("COMMODITY MATCH STATISTICS")
    print("="*60)

    cur.execute("""
        SELECT commodity, COUNT(*), AVG(confidence), COUNT(DISTINCT buyer_email)
        FROM commodity_matches
        GROUP BY commodity
    """)

    for comm, cnt, avg_conf, emails in cur.fetchall():
        print(f"\n{comm.upper()}:")
        print(f"  Total matches: {cnt:,}")
        print(f"  Avg confidence: {avg_conf:.0%}")
        print(f"  Unique emails: {emails:,}")

    cur.execute("SELECT COUNT(*) FROM commodity_matches")
    total = cur.fetchone()[0]
    print(f"\nGRAND TOTAL: {total:,} matches")
    conn.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Generate Match Reports')
    parser.add_argument('--commodity', '-c', choices=['lithium', 'niobium', 'beef', 'honey', 'all'])
    parser.add_argument('--format', '-f', choices=['html', 'csv'], default='html')
    parser.add_argument('--stats', '-s', action='store_true')
    parser.add_argument('--output', '-o', type=str)

    args = parser.parse_args()

    if args.stats:
        show_stats()
    elif args.commodity:
        comm = None if args.commodity == 'all' else args.commodity
        matches = get_matches(comm)

        if args.format == 'csv':
            out = Path(args.output) if args.output else OUTPUT_DIR / f'matches_{args.commodity}_{datetime.now():%Y%m%d}.csv'
            generate_csv(matches, out)
        else:
            out = Path(args.output) if args.output else OUTPUT_DIR / f'matches_{args.commodity}_{datetime.now():%Y%m%d}.html'
            generate_html(matches, args.commodity, out)
    else:
        show_stats()
