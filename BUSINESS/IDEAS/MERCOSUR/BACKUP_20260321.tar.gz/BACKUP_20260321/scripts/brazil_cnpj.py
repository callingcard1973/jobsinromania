#!/usr/bin/env python3
"""
Brazil CNPJ Company Registry Import
Downloads and imports Brazilian company data from Receita Federal.

Source: https://dados.rfb.gov.br/CNPJ/
Records: 50M+ companies
Format: ZIP containing CSV files

Usage:
    python3 brazil_cnpj.py --stats           # Show current stats
    python3 brazil_cnpj.py --download        # Download latest data
    python3 brazil_cnpj.py --import          # Import to database
    python3 brazil_cnpj.py --download --import  # Full pipeline
    python3 brazil_cnpj.py --limit 100000    # Import limited rows
"""

import sys
import os
import csv
import zipfile
import requests
from pathlib import Path
from datetime import datetime
from typing import Iterator, Optional, Dict
import re
import logging

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from base import (
    Company, get_db, insert_companies, download_file,
    sanitize, log, BATCH_SIZE
)

# Setup
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Directories
MERCOSUR_DIR = Path(__file__).parent.parent
DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/brazil_cnpj')
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Receita Federal URLs
RF_BASE = "https://dados.rfb.gov.br/CNPJ/"
RF_DADOS = f"{RF_BASE}dados_abertos_cnpj/"

# File patterns
FILE_PATTERNS = {
    'empresas': 'Empresas',      # Main company data
    'estabelecimentos': 'Estabelecimentos',  # Establishment data (addresses)
    'socios': 'Socios',          # Partners/shareholders
    'simples': 'Simples',        # Simples Nacional status
    'cnaes': 'Cnaes',            # Activity codes reference
    'municipios': 'Municipios',  # Municipality reference
    'naturezas': 'Naturezas',    # Legal nature reference
    'paises': 'Paises',          # Country reference
    'qualificacoes': 'Qualificacoes',  # Qualification reference
    'motivos': 'Motivos',        # Status reason reference
}

# CNAE sector codes (simplified)
CNAE_SECTORS = {
    '01': 'Agriculture',
    '02': 'Forestry',
    '03': 'Fishing',
    '05': 'Coal Mining',
    '06': 'Oil & Gas',
    '07': 'Metal Mining',
    '08': 'Other Mining',
    '10': 'Food Products',
    '11': 'Beverages',
    '12': 'Tobacco',
    '13': 'Textiles',
    '14': 'Apparel',
    '15': 'Leather',
    '16': 'Wood Products',
    '17': 'Paper',
    '18': 'Printing',
    '19': 'Petroleum Products',
    '20': 'Chemicals',
    '21': 'Pharmaceuticals',
    '22': 'Rubber & Plastics',
    '23': 'Non-metallic Minerals',
    '24': 'Basic Metals',
    '25': 'Metal Products',
    '26': 'Electronics',
    '27': 'Electrical Equipment',
    '28': 'Machinery',
    '29': 'Motor Vehicles',
    '30': 'Other Transport',
    '31': 'Furniture',
    '32': 'Other Manufacturing',
    '33': 'Repair & Installation',
    '35': 'Electricity & Gas',
    '36': 'Water Supply',
    '37': 'Sewerage',
    '38': 'Waste Management',
    '39': 'Remediation',
    '41': 'Building Construction',
    '42': 'Civil Engineering',
    '43': 'Specialized Construction',
    '45': 'Vehicle Trade',
    '46': 'Wholesale Trade',
    '47': 'Retail Trade',
    '49': 'Land Transport',
    '50': 'Water Transport',
    '51': 'Air Transport',
    '52': 'Warehousing',
    '53': 'Postal Services',
    '55': 'Accommodation',
    '56': 'Food Service',
    '58': 'Publishing',
    '59': 'Film & Music',
    '60': 'Broadcasting',
    '61': 'Telecommunications',
    '62': 'IT Services',
    '63': 'Information Services',
    '64': 'Financial Services',
    '65': 'Insurance',
    '66': 'Auxiliary Financial',
    '68': 'Real Estate',
    '69': 'Legal & Accounting',
    '70': 'Management Consulting',
    '71': 'Architecture & Engineering',
    '72': 'R&D',
    '73': 'Advertising',
    '74': 'Other Professional',
    '75': 'Veterinary',
    '77': 'Rental',
    '78': 'Employment Activities',
    '79': 'Travel Agencies',
    '80': 'Security Services',
    '81': 'Building Services',
    '82': 'Office Support',
    '84': 'Public Administration',
    '85': 'Education',
    '86': 'Health',
    '87': 'Residential Care',
    '88': 'Social Work',
    '90': 'Arts & Entertainment',
    '91': 'Libraries & Museums',
    '92': 'Gambling',
    '93': 'Sports & Recreation',
    '94': 'Membership Organizations',
    '95': 'Repair Services',
    '96': 'Personal Services',
    '97': 'Households as Employers',
    '99': 'International Organizations',
}


def get_latest_month() -> str:
    """Get the latest available data month."""
    try:
        resp = requests.get(RF_DADOS, timeout=30)
        # Find the latest YYYY-MM folder
        months = re.findall(r'href="(\d{4}-\d{2})/"', resp.text)
        if months:
            return sorted(months)[-1]
    except Exception as e:
        logger.error(f"Error getting latest month: {e}")

    # Fallback to current month
    return datetime.now().strftime('%Y-%m')


def list_data_files(month: str) -> Dict[str, list]:
    """List available data files for a month."""
    url = f"{RF_DADOS}{month}/"
    files = {k: [] for k in FILE_PATTERNS}

    try:
        resp = requests.get(url, timeout=30)
        for pattern_key, pattern in FILE_PATTERNS.items():
            matches = re.findall(rf'href="({pattern}\d*\.zip)"', resp.text)
            files[pattern_key] = matches
    except Exception as e:
        logger.error(f"Error listing files: {e}")

    return files


def download_cnpj_data(month: str = None, file_types: list = None) -> list:
    """Download CNPJ data files."""
    if month is None:
        month = get_latest_month()

    if file_types is None:
        file_types = ['empresas', 'estabelecimentos']

    logger.info(f"Downloading CNPJ data for {month}...")

    files = list_data_files(month)
    downloaded = []

    month_dir = DATA_DIR / month
    month_dir.mkdir(exist_ok=True)

    for file_type in file_types:
        for filename in files.get(file_type, []):
            url = f"{RF_DADOS}{month}/{filename}"
            filepath = month_dir / filename

            if filepath.exists():
                logger.info(f"  {filename} already exists, skipping")
                downloaded.append(filepath)
                continue

            logger.info(f"  Downloading {filename}...")
            if download_file(url, filepath, f"CNPJ {filename}"):
                downloaded.append(filepath)

    return downloaded


def format_cnpj(cnpj: str) -> str:
    """Format CNPJ number."""
    cnpj = re.sub(r'\D', '', str(cnpj))
    if len(cnpj) == 14:
        return f"{cnpj[:2]}.{cnpj[2:5]}.{cnpj[5:8]}/{cnpj[8:12]}-{cnpj[12:14]}"
    return cnpj


def parse_empresa_row(row: list) -> Optional[Dict]:
    """Parse Empresas CSV row."""
    if len(row) < 7:
        return None

    # Columns: cnpj_basico, razao_social, natureza_juridica, qualif_responsavel,
    #          capital_social, porte_empresa, ente_federativo
    cnpj_base = row[0].strip()
    razao_social = row[1].strip()

    if not cnpj_base or not razao_social:
        return None

    # Capital social (in cents, needs conversion)
    try:
        capital = float(row[4].replace(',', '.')) if row[4] else None
    except:
        capital = None

    # Porte (size): 00=N/A, 01=Micro, 03=Small, 05=Other
    porte_map = {'00': None, '01': 'Micro', '03': 'Small', '05': 'Medium/Large'}
    porte = porte_map.get(row[5].strip(), None)

    return {
        'cnpj_base': cnpj_base,
        'name': razao_social,
        'legal_nature': row[2].strip(),
        'capital': capital,
        'size': porte,
    }


def parse_estabelecimento_row(row: list, empresas_cache: dict) -> Optional[Company]:
    """Parse Estabelecimentos CSV row and merge with empresa data."""
    if len(row) < 30:
        return None

    # Key columns
    cnpj_base = row[0].strip()
    cnpj_ordem = row[1].strip()
    cnpj_dv = row[2].strip()

    if not cnpj_base:
        return None

    # Full CNPJ
    cnpj_full = f"{cnpj_base}{cnpj_ordem}{cnpj_dv}"

    # Only process headquarters (matriz) by default - ordem == '0001'
    # if cnpj_ordem != '0001':
    #     return None

    # Status: 01=Null, 02=Active, 03=Suspended, 04=Inapta, 08=Baixada
    situacao = row[5].strip()
    if situacao not in ['02']:  # Only active
        return None

    # Trade name
    nome_fantasia = row[4].strip() or None

    # Get empresa data
    empresa = empresas_cache.get(cnpj_base, {})
    razao_social = empresa.get('name', '')

    name = razao_social or nome_fantasia
    if not name:
        return None

    # Address
    tipo_logradouro = row[11].strip()
    logradouro = row[12].strip()
    numero = row[13].strip()
    complemento = row[14].strip()
    bairro = row[15].strip()
    cep = row[16].strip()

    address_parts = [tipo_logradouro, logradouro, numero, complemento, bairro]
    address = ', '.join(p for p in address_parts if p)

    # City and state
    municipio = row[20].strip()  # Code, needs lookup
    uf = row[19].strip()

    # Contact
    ddd1 = row[21].strip()
    tel1 = row[22].strip()
    phone = f"+55{ddd1}{tel1}" if ddd1 and tel1 else None

    email = row[27].strip().lower() if len(row) > 27 else None
    if email and '@' not in email:
        email = None

    # Activity (CNAE)
    cnae_principal = row[7].strip()
    cnae_sector = CNAE_SECTORS.get(cnae_principal[:2], None) if cnae_principal else None

    return Company(
        name=name,
        cui=cnpj_full,
        country='BR',
        city=f"{municipio}, {uf}" if municipio else uf,
        address=address if address else None,
        phone=phone,
        email=email,
        website=None,
        sector=cnae_principal,
        sector_name=cnae_sector,
        employees_count=None,
        revenue=empresa.get('capital'),
        source='BR_CNPJ',
        source_file=cnpj_base
    )


def iter_csv_in_zip(zip_path: Path, encoding: str = 'latin-1') -> Iterator[list]:
    """Iterate over CSV rows in a ZIP file."""
    with zipfile.ZipFile(zip_path, 'r') as zf:
        for name in zf.namelist():
            if name.endswith('.csv') or name.endswith('.CSV') or '.' not in name:
                logger.info(f"  Reading {name}...")
                with zf.open(name) as f:
                    import io
                    text = io.TextIOWrapper(f, encoding=encoding, errors='ignore')
                    reader = csv.reader(text, delimiter=';')
                    for row in reader:
                        yield row


def load_empresas_cache(zip_files: list) -> dict:
    """Load empresa base data into memory cache."""
    cache = {}

    for zf in zip_files:
        if 'Empresa' in zf.name:
            logger.info(f"Loading empresas from {zf.name}...")
            for row in iter_csv_in_zip(zf):
                data = parse_empresa_row(row)
                if data:
                    cache[data['cnpj_base']] = data

    logger.info(f"Loaded {len(cache):,} empresas into cache")
    return cache


def import_cnpj(month: str = None, limit: int = 0, dry_run: bool = False):
    """Import CNPJ data to database."""
    if month is None:
        month = get_latest_month()

    month_dir = DATA_DIR / month

    if not month_dir.exists():
        logger.error(f"Data directory not found: {month_dir}")
        logger.info("Run with --download first")
        return

    # Find files
    empresa_files = sorted(month_dir.glob('Empresa*.zip'))
    estab_files = sorted(month_dir.glob('Estabelecimento*.zip'))

    if not estab_files:
        logger.error("No Estabelecimentos files found")
        return

    # Load empresas cache
    empresas_cache = load_empresas_cache(empresa_files)

    # Connect to database
    conn = None
    if not dry_run:
        conn = get_db()

    total = 0
    batch = []

    for zf in estab_files:
        logger.info(f"Processing {zf.name}...")

        for row in iter_csv_in_zip(zf):
            company = parse_estabelecimento_row(row, empresas_cache)
            if company:
                batch.append(company)

            if len(batch) >= BATCH_SIZE:
                if not dry_run:
                    inserted = insert_companies(conn, batch)
                    total += inserted
                else:
                    total += len(batch)
                batch = []

                if total % 100000 == 0:
                    logger.info(f"  Processed {total:,} companies...")

                if limit > 0 and total >= limit:
                    logger.info(f"Reached limit of {limit:,}")
                    break

        if limit > 0 and total >= limit:
            break

    # Final batch
    if batch:
        if not dry_run:
            total += insert_companies(conn, batch)
        else:
            total += len(batch)

    if conn:
        conn.close()

    action = "Would import" if dry_run else "Imported"
    logger.info(f"{action} {total:,} Brazilian companies")


def show_stats():
    """Show current CNPJ data stats."""
    print("\n" + "="*60)
    print("BRAZIL CNPJ DATA STATUS")
    print("="*60)

    # Check latest available
    latest = get_latest_month()
    print(f"\nLatest available: {latest}")

    files = list_data_files(latest)
    print(f"\nFiles available for {latest}:")
    for ftype, flist in files.items():
        if flist:
            print(f"  {ftype}: {len(flist)} files")

    # Check local data
    print(f"\nLocal data directory: {DATA_DIR}")
    if DATA_DIR.exists():
        for month_dir in sorted(DATA_DIR.iterdir()):
            if month_dir.is_dir():
                zips = list(month_dir.glob('*.zip'))
                total_size = sum(z.stat().st_size for z in zips) / 1073741824
                print(f"  {month_dir.name}: {len(zips)} files, {total_size:.1f} GB")

    # Database stats
    print("\n" + "-"*60)
    print("DATABASE STATS")
    print("-"*60)

    try:
        conn = get_db()
        cur = conn.cursor()

        cur.execute("SELECT COUNT(*) FROM companies WHERE source = 'BR_CNPJ'")
        count = cur.fetchone()[0]

        cur.execute("SELECT COUNT(*) FROM companies WHERE country = 'BR'")
        br_count = cur.fetchone()[0]

        cur.execute("""
            SELECT sector_name, COUNT(*)
            FROM companies
            WHERE source = 'BR_CNPJ' AND sector_name IS NOT NULL
            GROUP BY sector_name
            ORDER BY COUNT(*) DESC
            LIMIT 10
        """)
        by_sector = cur.fetchall()

        conn.close()

        print(f"  BR_CNPJ companies: {count:,}")
        print(f"  Total BR companies: {br_count:,}")

        if by_sector:
            print("\n  Top sectors:")
            for sector, cnt in by_sector:
                print(f"    {sector}: {cnt:,}")

    except Exception as e:
        print(f"  Database error: {e}")


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Brazil CNPJ Import')
    parser.add_argument('--stats', '-s', action='store_true', help='Show stats')
    parser.add_argument('--download', '-d', action='store_true', help='Download data')
    parser.add_argument('--import', '-i', dest='do_import', action='store_true', help='Import to DB')
    parser.add_argument('--month', '-m', help='Specific month (YYYY-MM)')
    parser.add_argument('--limit', '-l', type=int, default=0, help='Limit rows')
    parser.add_argument('--dry-run', '-n', action='store_true', help='Dry run')

    args = parser.parse_args()

    if args.stats:
        show_stats()
    elif args.download:
        download_cnpj_data(args.month)
        if args.do_import:
            import_cnpj(args.month, limit=args.limit, dry_run=args.dry_run)
    elif args.do_import:
        import_cnpj(args.month, limit=args.limit, dry_run=args.dry_run)
    else:
        show_stats()
