#!/usr/bin/env python3
"""
EU Buyer Profiles - Filter TED winners by commodity sector.
Extracts potential buyers for MERCOSUR commodities from TED procurement data.

Usage:
    python3 eu_buyer_profiles.py --sector lithium --stats
    python3 eu_buyer_profiles.py --sector beef --export buyers.csv
    python3 eu_buyer_profiles.py --all --stats
"""

import sys
import csv
import argparse
from pathlib import Path
import logging

sys.path.insert(0, '/opt/ACTIVE/DB/GLOBAL')
from base import get_db

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/mercosur_buyers')
DATA_DIR.mkdir(parents=True, exist_ok=True)

# CPV codes and keywords by commodity sector
SECTOR_FILTERS = {
    'lithium': {
        'cpv_prefix': ['314', '271'],  # Batteries, electrical
        'keywords': ['battery', 'lithium', 'automotive', 'electric vehicle', 'EV'],
        'name_keywords': ['automotive', 'battery', 'energy', 'electric'],
    },
    'niobium': {
        'cpv_prefix': ['146', '270', '441'],  # Metal ores, steel products
        'keywords': ['steel', 'alloy', 'metal', 'aerospace', 'pipeline'],
        'name_keywords': ['steel', 'metal', 'aerospace', 'turbine'],
    },
    'beef': {
        'cpv_prefix': ['151', '153'],  # Meat products
        'keywords': ['meat', 'beef', 'food', 'catering'],
        'name_keywords': ['food', 'catering', 'hospital', 'school', 'canteen'],
    },
    'honey': {
        'cpv_prefix': ['158', '153'],  # Food, agricultural
        'keywords': ['honey', 'food', 'organic', 'sweetener'],
        'name_keywords': ['food', 'retail', 'organic', 'confection'],
    },
}

def get_sector_buyers(sector: str, limit: int = 1000) -> list:
    """Query TED winners filtered by sector criteria."""
    if sector not in SECTOR_FILTERS:
        logger.error(f"Unknown sector: {sector}")
        return []

    filters = SECTOR_FILTERS[sector]
    conn = get_db()
    cur = conn.cursor()

    # Build CPV filter (ted_winners uses 'cpv' column)
    cpv_conditions = ' OR '.join([f"cpv LIKE '{p}%'" for p in filters['cpv_prefix']])

    # Build keyword filter on contractor name
    name_conditions = ' OR '.join([f"LOWER(contractor) LIKE '%{k}%'" for k in filters['name_keywords']])

    query = f"""
        SELECT DISTINCT contractor, contractor_country, contractor_email,
               contractor_website, cpv, contract_value
        FROM ted_winners
        WHERE contractor_email IS NOT NULL
          AND ({cpv_conditions} OR {name_conditions})
        ORDER BY contract_value DESC NULLS LAST
        LIMIT {limit}
    """

    try:
        cur.execute(query)
        rows = cur.fetchall()
        results = []
        for row in rows:
            results.append({
                'authority_name': row[0],
                'country': row[1],
                'email': row[2],
                'website': row[3],
                'cpv_code': row[4],
                'award_value': row[5],
            })
        logger.info(f"Found {len(results)} {sector} buyers")
        return results
    except Exception as e:
        logger.error(f"Query error: {e}")
        import traceback
        traceback.print_exc()
        return []
    finally:
        conn.close()


def export_buyers(sector: str, output_file: Path, limit: int = 1000):
    """Export buyers to CSV."""
    buyers = get_sector_buyers(sector, limit)
    if not buyers:
        return

    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=buyers[0].keys())
        writer.writeheader()
        writer.writerows(buyers)

    logger.info(f"Exported {len(buyers)} buyers to {output_file}")


def show_stats(sector: str = None):
    """Show sector buyer statistics."""
    print("\n" + "="*60)
    print("EU BUYER PROFILES - TED WINNERS BY SECTOR")
    print("="*60)

    conn = get_db()
    cur = conn.cursor()

    sectors = [sector] if sector else list(SECTOR_FILTERS.keys())

    for sec in sectors:
        if sec not in SECTOR_FILTERS:
            continue

        filters = SECTOR_FILTERS[sec]
        cpv_conditions = ' OR '.join([f"cpv LIKE '{p}%'" for p in filters['cpv_prefix']])

        cur.execute(f"""
            SELECT COUNT(DISTINCT contractor),
                   COUNT(DISTINCT contractor_email)
            FROM ted_winners
            WHERE ({cpv_conditions}) AND contractor_email IS NOT NULL
        """)
        companies, emails = cur.fetchone()

        print(f"\n{sec.upper()}:")
        print(f"  Companies: {companies:,}")
        print(f"  With email: {emails:,}")

        # Top countries
        cur.execute(f"""
            SELECT contractor_country, COUNT(DISTINCT contractor) as cnt
            FROM ted_winners
            WHERE ({cpv_conditions}) AND contractor_email IS NOT NULL
            GROUP BY contractor_country ORDER BY cnt DESC LIMIT 5
        """)
        countries = cur.fetchall()
        if countries:
            print("  Top countries:", ', '.join([f"{r[0] or 'N/A'}:{r[1]}" for r in countries]))

    conn.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='EU Buyer Profiles')
    parser.add_argument('--sector', '-s', choices=['lithium', 'niobium', 'beef', 'honey', 'all'])
    parser.add_argument('--stats', action='store_true', help='Show statistics')
    parser.add_argument('--export', '-e', type=str, help='Export to CSV')
    parser.add_argument('--limit', '-l', type=int, default=1000)

    args = parser.parse_args()

    if args.stats:
        show_stats(args.sector if args.sector != 'all' else None)
    elif args.export and args.sector:
        export_buyers(args.sector, Path(args.export), args.limit)
    else:
        show_stats()
