#!/usr/bin/env python3
"""
Brazil PNCP Procurement Scraper
Fetches procurement data from Portal Nacional de Contratações Públicas.

API: https://pncp.gov.br/api/pncp/v1/
Note: Old compras.dados.gov.br API is deprecated (404)

Usage:
    python3 brazil_compras.py --stats
    python3 brazil_compras.py --pncp --limit 1000    # Fetch PNCP orgs
    python3 brazil_compras.py --import
"""

import sys
import json
import csv
import requests
from pathlib import Path
from datetime import datetime
from typing import List, Iterator
import logging
import time

sys.path.insert(0, '/opt/ACTIVE/DB/GLOBAL')
from base import get_db, sanitize, BATCH_SIZE

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/brazil_compras')
DATA_DIR.mkdir(parents=True, exist_ok=True)

# PNCP API (new, working)
PNCP_BASE = "https://pncp.gov.br/api/pncp/v1"
PNCP_ORGAOS = f"{PNCP_BASE}/orgaos"
PAGE_SIZE = 500
REQUEST_DELAY = 1.0

# Legacy API (deprecated, returns 404)
API_BASE = "https://dadosabertos.compras.gov.br"
CONTRACTS_URL = f"{API_BASE}/contratos/v1/contratos.json"


def fetch_contracts(offset: int = 0, limit: int = 500) -> dict:
    """Fetch contracts from API."""
    params = {'offset': offset, 'limit': min(limit, PAGE_SIZE)}
    try:
        resp = requests.get(CONTRACTS_URL, params=params, timeout=30)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        logger.error(f"API error: {e}")
        return {}


def fetch_all_contracts(max_records: int = 5000) -> List[dict]:
    """Fetch contracts with pagination."""
    all_contracts = []
    offset = 0

    while len(all_contracts) < max_records:
        logger.info(f"Fetching offset {offset}...")
        data = fetch_contracts(offset, PAGE_SIZE)

        contracts = data.get('_embedded', {}).get('contratos', [])
        if not contracts:
            break

        all_contracts.extend(contracts)
        offset += PAGE_SIZE
        time.sleep(REQUEST_DELAY)

        if len(contracts) < PAGE_SIZE:
            break

    return all_contracts[:max_records]


def fetch_pncp_orgaos(limit: int = 5000) -> List[dict]:
    """Fetch government organizations from PNCP API."""
    all_orgs = []
    page = 1
    page_size = 500

    while len(all_orgs) < limit:
        logger.info(f"Fetching PNCP page {page}...")
        try:
            resp = requests.get(PNCP_ORGAOS, params={
                'pagina': page,
                'tamanhoPagina': page_size
            }, timeout=60)
            resp.raise_for_status()
            orgs = resp.json()

            if not orgs:
                break

            all_orgs.extend(orgs)
            page += 1
            time.sleep(REQUEST_DELAY)

            if len(orgs) < page_size:
                break
        except Exception as e:
            logger.error(f"PNCP error: {e}")
            break

    return all_orgs[:limit]


def extract_pncp_orgs(orgs: List[dict]) -> List[dict]:
    """Extract organization info from PNCP data."""
    results = []
    seen = set()
    for o in orgs:
        cnpj = o.get('cnpj', '')
        if not cnpj or cnpj in seen:
            continue
        seen.add(cnpj)

        results.append({
            'name': sanitize(o.get('razaoSocial', '')),
            'cnpj': cnpj,
            'trade_name': sanitize(o.get('nomeFantasia', '')),
            'country': 'BR',
            'status': o.get('situacaoCadastral', ''),
            'org_type': 'government',
        })
    return results


def extract_winners(contracts: List[dict]) -> List[dict]:
    """Extract winning companies from contracts."""
    winners = []
    for c in contracts:
        fornecedor = c.get('fornecedor', {})
        if fornecedor:
            winners.append({
                'name': sanitize(fornecedor.get('nome', '')),
                'cnpj': fornecedor.get('cnpj_cpf', ''),
                'country': 'BR',
                'contract_value': c.get('valor_inicial'),
                'contract_date': c.get('data_assinatura'),
                'buyer': c.get('unidade_gestora', {}).get('nome', ''),
                'description': sanitize(c.get('objeto', ''))[:500],
            })
    return winners


def save_winners(winners: List[dict], output_file: Path = None):
    """Save winners to CSV."""
    if not output_file:
        output_file = DATA_DIR / f'brazil_winners_{datetime.now():%Y%m%d}.csv'

    if winners:
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=winners[0].keys())
            writer.writeheader()
            writer.writerows(winners)
        logger.info(f"Saved {len(winners)} winners to {output_file}")


def import_to_db(winners: List[dict], dry_run: bool = False):
    """Import winners to database."""
    if dry_run:
        logger.info(f"Would import {len(winners)} winners")
        return

    conn = get_db()
    cur = conn.cursor()

    inserted = 0
    for w in winners:
        try:
            cur.execute("""
                INSERT INTO companies (name, cui, country, source, source_file)
                VALUES (%s, %s, %s, %s, %s)
                ON CONFLICT DO NOTHING
            """, (w['name'], w['cnpj'], 'BR', 'BR_Compras', 'brazil_compras.py'))
            inserted += 1
        except Exception as e:
            logger.warning(f"Insert error: {e}")

    conn.commit()
    conn.close()
    logger.info(f"Imported {inserted} companies")


def show_stats():
    """Show API and local data stats."""
    print("\n" + "="*60)
    print("BRAZIL COMPRAS.GOV.BR STATUS")
    print("="*60)

    # Test API
    print("\nAPI Test:")
    data = fetch_contracts(0, 1)
    if data:
        total = data.get('_total_registros', 'Unknown')
        print(f"  Total contracts available: {total}")
        sample = data.get('_embedded', {}).get('contratos', [])
        if sample:
            print(f"  Sample contract: {sample[0].get('objeto', '')[:60]}...")
    else:
        print("  API not responding")

    # Local data
    print(f"\nLocal data: {DATA_DIR}")
    csvs = list(DATA_DIR.glob('*.csv'))
    for f in csvs[-3:]:
        lines = sum(1 for _ in open(f)) - 1
        print(f"  {f.name}: {lines:,} records")

    # DB stats
    print("\nDatabase:")
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM companies WHERE source = 'BR_Compras'")
        print(f"  BR_Compras companies: {cur.fetchone()[0]:,}")
        conn.close()
    except Exception as e:
        print(f"  DB error: {e}")


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Brazil PNCP Scraper')
    parser.add_argument('--stats', '-s', action='store_true')
    parser.add_argument('--pncp', '-p', action='store_true', help='Fetch PNCP government orgs')
    parser.add_argument('--fetch', '-f', action='store_true', help='Legacy compras API (deprecated)')
    parser.add_argument('--import', '-i', dest='do_import', action='store_true')
    parser.add_argument('--limit', '-l', type=int, default=5000)
    parser.add_argument('--dry-run', '-n', action='store_true')

    args = parser.parse_args()

    if args.pncp:
        orgs = fetch_pncp_orgaos(args.limit)
        logger.info(f"Fetched {len(orgs)} PNCP organizations")

        with open(DATA_DIR / f'pncp_orgaos_{datetime.now():%Y%m%d}.json', 'w') as f:
            json.dump(orgs, f, indent=2, default=str, ensure_ascii=False)

        winners = extract_pncp_orgs(orgs)
        save_winners(winners)

        if args.do_import:
            import_to_db(winners, args.dry_run)

    elif args.fetch:
        logger.warning("Legacy compras API is deprecated (404). Use --pncp instead.")
        contracts = fetch_all_contracts(args.limit)
        if contracts:
            logger.info(f"Fetched {len(contracts)} contracts")
            with open(DATA_DIR / f'contracts_{datetime.now():%Y%m%d}.json', 'w') as f:
                json.dump(contracts, f, indent=2, default=str)
    else:
        show_stats()
