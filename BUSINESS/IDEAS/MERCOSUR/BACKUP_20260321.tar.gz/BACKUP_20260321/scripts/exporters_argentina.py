#!/usr/bin/env python3
"""Argentina Exporter Directory - Major exporters by sector"""

import sys
sys.path.insert(0, '/opt/ACTIVE/SCRAPERS/EUROPE/SCRIPTS/SHARED')

import argparse
import json
import logging
from pathlib import Path
from datetime import datetime
from skills_common import to_ascii

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s [%(name)s] %(message)s')
logger = logging.getLogger(__name__)

OUTPUT_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/mercosur_exporters')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def get_argentina_exporters():
    """Curated list of major Argentine exporters"""
    return [
        # Agribusiness/Grains
        {'name': 'Aceitera General Deheza (AGD)', 'country': 'AR', 'city': 'Cordoba', 'sector': 'Soy/Grains', 'website': 'agd.com.ar'},
        {'name': 'Molinos Agro', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Grains/Oils', 'website': 'molinosagro.com.ar'},
        {'name': 'Vicentin', 'country': 'AR', 'city': 'Avellaneda', 'sector': 'Soy/Grains', 'website': 'vicentin.com.ar'},
        {'name': 'Cargill Argentina', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Grains', 'website': 'cargill.com.ar'},
        {'name': 'Bunge Argentina', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Grains', 'website': 'bunge.com.ar'},
        {'name': 'Louis Dreyfus Argentina', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Commodities', 'website': 'ldc.com'},
        {'name': 'ADM Argentina', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Grains', 'website': 'adm.com'},
        {'name': 'Nidera', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Grains', 'website': 'nidera.com.ar'},
        # Beef
        {'name': 'Frigorifico Gorina', 'country': 'AR', 'city': 'La Plata', 'sector': 'Beef', 'website': 'gorina.com.ar'},
        {'name': 'Quickfood (Marfrig)', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Beef', 'website': 'quickfood.com.ar'},
        {'name': 'Frigorifico Rioplatense', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Beef', 'website': 'rfrioplatense.com.ar'},
        {'name': 'FRIAR S.A.', 'country': 'AR', 'city': 'Santa Fe', 'sector': 'Beef', 'website': 'friar.com.ar'},
        {'name': 'Arre Beef', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Beef', 'website': 'arrebeef.com'},
        {'name': 'Frigorifico Paladini', 'country': 'AR', 'city': 'Santa Fe', 'sector': 'Beef/Pork', 'website': 'paladini.com.ar'},
        {'name': 'Estancias del Sur', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Beef', 'website': 'estanciasdelsur.com.ar'},
        # Wine
        {'name': 'Bodegas Chandon Argentina', 'country': 'AR', 'city': 'Mendoza', 'sector': 'Wine', 'website': 'chandon.com.ar'},
        {'name': 'Bodega Catena Zapata', 'country': 'AR', 'city': 'Mendoza', 'sector': 'Wine', 'website': 'catenawines.com'},
        {'name': 'Trivento Bodegas', 'country': 'AR', 'city': 'Mendoza', 'sector': 'Wine', 'website': 'trivento.com'},
        {'name': 'Bodega Norton', 'country': 'AR', 'city': 'Mendoza', 'sector': 'Wine', 'website': 'norton.com.ar'},
        {'name': 'Familia Zuccardi', 'country': 'AR', 'city': 'Mendoza', 'sector': 'Wine', 'website': 'familiazuccardi.com'},
        {'name': 'Trapiche', 'country': 'AR', 'city': 'Mendoza', 'sector': 'Wine', 'website': 'trapiche.com.ar'},
        {'name': 'Luigi Bosca', 'country': 'AR', 'city': 'Mendoza', 'sector': 'Wine', 'website': 'luigibosca.com.ar'},
        # Lithium
        {'name': 'Livent Argentina', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Lithium', 'website': 'livent.com'},
        {'name': 'Allkem (Olaroz)', 'country': 'AR', 'city': 'Jujuy', 'sector': 'Lithium', 'website': 'allkem.co'},
        {'name': 'Arcadium Lithium', 'country': 'AR', 'city': 'Salta', 'sector': 'Lithium', 'website': 'arcadiumlithium.com'},
        {'name': 'Rio Tinto Rincon', 'country': 'AR', 'city': 'Salta', 'sector': 'Lithium', 'website': 'riotinto.com'},
        {'name': 'Posco Argentina (Sal de Vida)', 'country': 'AR', 'city': 'Catamarca', 'sector': 'Lithium', 'website': 'posco.com'},
        # Honey
        {'name': 'Nexco S.A.', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Honey', 'website': 'nexco.com.ar'},
        {'name': 'HoneyMax', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Honey', 'website': 'honeymax.com.ar'},
        {'name': 'ConexAmericas', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Honey', 'website': 'conexamericas.com'},
        # Fishing/Seafood
        {'name': 'Newsan Food', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Seafood', 'website': 'newsan.com.ar'},
        {'name': 'Pesquera Deseado', 'country': 'AR', 'city': 'Puerto Deseado', 'sector': 'Seafood', 'website': 'pesqueradeseado.com.ar'},
        {'name': 'Argenova', 'country': 'AR', 'city': 'Mar del Plata', 'sector': 'Seafood', 'website': 'argenova.com.ar'},
        # Aluminum
        {'name': 'Aluar Aluminio Argentino', 'country': 'AR', 'city': 'Puerto Madryn', 'sector': 'Aluminum', 'website': 'aluar.com.ar', 'employees': 2500},
        # Steel
        {'name': 'Ternium Argentina', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Steel', 'website': 'ternium.com'},
        {'name': 'Tenaris', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Steel Pipes', 'website': 'tenaris.com'},
        {'name': 'Acindar (ArcelorMittal)', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Steel', 'website': 'acindar.com.ar'},
        # Chemicals
        {'name': 'YPF', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Oil/Gas/Chemicals', 'website': 'ypf.com', 'employees': 20000},
        {'name': 'Dow Argentina', 'country': 'AR', 'city': 'Buenos Aires', 'sector': 'Chemicals', 'website': 'dow.com'},
        # Fruits
        {'name': 'Expofrut Argentina', 'country': 'AR', 'city': 'Rio Negro', 'sector': 'Fruits', 'website': 'expofrut.com.ar'},
        {'name': 'Patagonian Fruits', 'country': 'AR', 'city': 'Neuquen', 'sector': 'Fruits', 'website': 'patagonianfruits.com'},
        # Lemons
        {'name': 'San Miguel S.A.', 'country': 'AR', 'city': 'Tucuman', 'sector': 'Lemons/Citrus', 'website': 'sanmiguelglobal.com'},
        {'name': 'Citrusvil', 'country': 'AR', 'city': 'Tucuman', 'sector': 'Lemons', 'website': 'citrusvil.com.ar'},
        # Peanuts
        {'name': 'Prodeman', 'country': 'AR', 'city': 'Cordoba', 'sector': 'Peanuts', 'website': 'prodeman.com'},
        {'name': 'Lorenzati Ruetsch', 'country': 'AR', 'city': 'Cordoba', 'sector': 'Peanuts', 'website': 'lorenzati.com.ar'},
    ]

def download_exporters():
    """Save exporters to file"""
    exporters = get_argentina_exporters()
    output_file = OUTPUT_DIR / f'argentina_exporters_{datetime.now():%Y%m%d}.json'
    with open(output_file, 'w') as f:
        json.dump(exporters, f, indent=2)
    logger.info(f"Saved {len(exporters)} Argentine exporters to {output_file}")
    return exporters

def show_stats():
    """Show statistics"""
    files = list(OUTPUT_DIR.glob('argentina_exporters_*.json'))
    if not files:
        logger.info("No data. Run --download first.")
        return
    latest = max(files, key=lambda p: p.stat().st_mtime)
    with open(latest) as f:
        data = json.load(f)
    print(f"\n{'='*60}\nARGENTINA EXPORTERS: {len(data)}\n{'='*60}")
    sectors = {}
    for e in data:
        s = e.get('sector', 'Unknown')
        sectors[s] = sectors.get(s, 0) + 1
    for s, c in sorted(sectors.items(), key=lambda x: -x[1]):
        print(f"  {s}: {c}")

def import_to_db():
    """Import to database"""
    import psycopg2
    files = list(OUTPUT_DIR.glob('argentina_exporters_*.json'))
    if not files:
        logger.error("No data files")
        return
    latest = max(files, key=lambda p: p.stat().st_mtime)
    with open(latest) as f:
        data = json.load(f)
    conn = psycopg2.connect(dbname='interjob_master', user='tudor')
    cur = conn.cursor()
    imported = 0
    for e in data:
        try:
            cur.execute("""
                INSERT INTO companies (name, country, city, sector, website, source)
                VALUES (%s, %s, %s, %s, %s, %s)
                ON CONFLICT (name, country) DO UPDATE SET sector=EXCLUDED.sector
            """, (e.get('name'), 'AR', e.get('city'), e.get('sector'), e.get('website'), 'MERCOSUR_AR_Exporters'))
            imported += 1
        except Exception as ex:
            logger.warning(f"Error: {ex}")
    conn.commit()
    conn.close()
    logger.info(f"Imported {imported} Argentine exporters")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--stats', action='store_true')
    parser.add_argument('--download', action='store_true')
    parser.add_argument('--import', dest='do_import', action='store_true')
    args = parser.parse_args()
    if args.stats:
        show_stats()
    elif args.download:
        download_exporters()
    elif args.do_import:
        import_to_db()
    else:
        download_exporters()
