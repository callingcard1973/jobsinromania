#!/usr/bin/env python3
"""
MERCOSUR Honey Exporters (Argentina/Uruguay)
Fetches honey producers and exporters from Argentina and Uruguay.

Sources:
- AR: SENASA apiarios (registered beekeepers)
- AR: Ministry of Agriculture
- UY: MGAP (Ministry of Agriculture)
- UY: DIGEGRA organic registry

Usage:
    python3 honey_exporters.py --stats           # Show stats
    python3 honey_exporters.py --download AR    # Download Argentina data
    python3 honey_exporters.py --download ALL   # Download all countries
    python3 honey_exporters.py --import         # Import to DB
"""

import sys
import json
import requests
from pathlib import Path
from typing import List
import logging
from bs4 import BeautifulSoup

sys.path.insert(0, '/opt/ACTIVE/DB/GLOBAL')

from base import (
    Company, get_db, insert_companies,
    sanitize, log, BATCH_SIZE
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Directories
DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/mercosur_honey')
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Country-specific sources
SOURCES = {
    'AR': {
        'name': 'Argentina',
        'registry': 'SENASA',
        'url': 'https://www.senasa.gob.ar/cadena-vegetal/abejas',
        'api': 'https://datos.gob.ar/api/3/action/package_search?q=apicola',
        'production': '70,000 tonnes/year',
        'export': '65,000 tonnes/year',
        'rank': '3rd world exporter',
        'regions': ['Buenos Aires', 'Entre Rios', 'Santa Fe', 'Cordoba', 'La Pampa'],
    },
    'UY': {
        'name': 'Uruguay',
        'registry': 'MGAP',
        'url': 'https://www.gub.uy/ministerio-ganaderia-agricultura-pesca',
        'digegra': 'https://www.gub.uy/ministerio-ganaderia-agricultura-pesca/politicas-y-gestion/registro-apicola',
        'production': '12,000 tonnes/year',
        'export': '10,000 tonnes/year',
        'regions': ['Artigas', 'Salto', 'Paysandu', 'Flores'],
    },
    'BR': {
        'name': 'Brazil',
        'registry': 'MAPA',
        'url': 'https://www.gov.br/agricultura/',
        'production': '45,000 tonnes/year',
        'export': '35,000 tonnes/year',
        'regions': ['Rio Grande do Sul', 'Parana', 'Santa Catarina', 'Piaui'],
    },
    'CL': {
        'name': 'Chile',
        'registry': 'SAG',
        'url': 'https://www.sag.gob.cl/',
        'production': '10,000 tonnes/year',
        'export': '7,000 tonnes/year',
        'regions': ['O\'Higgins', 'Maule', 'Biobio'],
    },
}

# Known major exporters
HONEY_EXPORTERS = [
    # Argentina - Major exporters
    {
        'name': 'Nexco S.A.',
        'country': 'AR',
        'city': 'Buenos Aires',
        'region': 'Buenos Aires',
        'sector': 'Honey Export',
        'website': 'nexco.com.ar',
        'volume_tonnes': 15000,
        'status': 'Operating',
        'certifications': ['EU Approved', 'HACCP', 'BRC'],
        'products': ['Multiflora', 'Clover', 'Eucalyptus'],
    },
    {
        'name': 'Mieles del Sur S.A.',
        'country': 'AR',
        'city': 'Buenos Aires',
        'sector': 'Honey Processing & Export',
        'website': 'mielesdelsur.com.ar',
        'volume_tonnes': 8000,
        'status': 'Operating',
        'certifications': ['EU Approved', 'HACCP'],
    },
    {
        'name': 'ConAgra Honey',
        'country': 'AR',
        'city': 'Buenos Aires',
        'sector': 'Honey Export',
        'volume_tonnes': 10000,
        'status': 'Operating',
    },
    {
        'name': 'Apicooperativa Apinor',
        'country': 'AR',
        'city': 'Chaco',
        'region': 'Chaco',
        'sector': 'Beekeeping Cooperative',
        'volume_tonnes': 3000,
        'status': 'Operating',
        'organic': True,
    },
    {
        'name': 'Miel Argentina S.A.',
        'country': 'AR',
        'city': 'Santa Fe',
        'region': 'Santa Fe',
        'sector': 'Honey Export',
        'website': 'mielargentina.com',
        'status': 'Operating',
    },
    {
        'name': 'Mieles Argentinas CIAC',
        'country': 'AR',
        'city': 'Buenos Aires',
        'sector': 'Honey Export',
        'status': 'Operating',
    },
    {
        'name': 'API Gourmet',
        'country': 'AR',
        'city': 'Cordoba',
        'region': 'Cordoba',
        'sector': 'Premium Honey',
        'website': 'apigourmet.com.ar',
        'status': 'Operating',
        'products': ['Organic', 'Monofloral', 'Premium'],
    },
    {
        'name': 'Cooperativa Apicola del Norte',
        'country': 'AR',
        'city': 'Entre Rios',
        'region': 'Entre Rios',
        'sector': 'Beekeeping Cooperative',
        'status': 'Operating',
    },
    {
        'name': 'El Refugio Apicola',
        'country': 'AR',
        'city': 'La Pampa',
        'region': 'La Pampa',
        'sector': 'Beekeeping',
        'organic': True,
        'status': 'Operating',
    },

    # Uruguay - Major exporters
    {
        'name': 'Mieles del Uruguay S.A.',
        'country': 'UY',
        'city': 'Montevideo',
        'sector': 'Honey Export',
        'website': 'mielesdeluruguay.com',
        'volume_tonnes': 4000,
        'status': 'Operating',
        'certifications': ['EU Approved', 'Organic'],
    },
    {
        'name': 'Apicola del Uruguay',
        'country': 'UY',
        'city': 'Montevideo',
        'sector': 'Honey Processing',
        'status': 'Operating',
    },
    {
        'name': 'CALNU (Cooperativa Agropecuaria Ltda del Norte Uruguayo)',
        'country': 'UY',
        'city': 'Salto',
        'region': 'Salto',
        'sector': 'Agricultural Cooperative',
        'website': 'calnu.com.uy',
        'status': 'Operating',
        'products': ['Honey', 'Citrus'],
    },
    {
        'name': 'Miel del Bosque',
        'country': 'UY',
        'city': 'Montevideo',
        'sector': 'Organic Honey',
        'organic': True,
        'status': 'Operating',
    },
    {
        'name': 'APIDU (Asociacion de Productores Integrados del Uruguay)',
        'country': 'UY',
        'city': 'Various',
        'sector': 'Producer Association',
        'status': 'Association',
    },

    # Brazil - Honey exporters
    {
        'name': 'Wax Green Natural Products',
        'country': 'BR',
        'city': 'Sao Paulo',
        'sector': 'Bee Products',
        'website': 'waxgreen.com.br',
        'status': 'Operating',
        'products': ['Honey', 'Propolis', 'Royal Jelly'],
    },
    {
        'name': 'Breyer & Cia',
        'country': 'BR',
        'city': 'Rio Grande do Sul',
        'sector': 'Honey Export',
        'website': 'breyer.com.br',
        'status': 'Operating',
    },
    {
        'name': 'COAPI (Cooperativa de Apicultores)',
        'country': 'BR',
        'city': 'Piaui',
        'region': 'Piaui',
        'sector': 'Beekeeping Cooperative',
        'status': 'Operating',
        'products': ['Organic Honey'],
    },
    {
        'name': 'Apis Flora',
        'country': 'BR',
        'city': 'Ribeirao Preto',
        'state': 'Sao Paulo',
        'sector': 'Bee Products',
        'website': 'apisflora.com.br',
        'status': 'Operating',
        'products': ['Propolis', 'Honey', 'Royal Jelly'],
    },

    # Chile
    {
        'name': 'Red Apicola Nacional de Chile',
        'country': 'CL',
        'city': 'Santiago',
        'sector': 'National Beekeeping Network',
        'website': 'redapicola.cl',
        'status': 'Network',
    },
    {
        'name': 'Apicola del Maule',
        'country': 'CL',
        'city': 'Talca',
        'region': 'Maule',
        'sector': 'Beekeeping',
        'status': 'Operating',
    },
]

# EU buyers reference
EU_HONEY_BUYERS = [
    # Retail
    {'name': 'Aldi', 'country': 'DE', 'sector': 'Retail', 'volume': 'Major importer'},
    {'name': 'Lidl', 'country': 'DE', 'sector': 'Retail', 'volume': 'Major importer'},
    {'name': 'Rewe Group', 'country': 'DE', 'sector': 'Retail'},
    {'name': 'Carrefour', 'country': 'FR', 'sector': 'Retail'},
    {'name': 'Tesco', 'country': 'GB', 'sector': 'Retail'},

    # Food industry
    {'name': 'Nestle', 'country': 'CH', 'sector': 'Food Industry', 'use': 'Breakfast cereals, ingredients'},
    {'name': 'Unilever', 'country': 'NL', 'sector': 'Food Industry'},
    {'name': 'Ferrero', 'country': 'IT', 'sector': 'Confectionery'},

    # Specialty/Organic
    {'name': 'Rigoni di Asiago', 'country': 'IT', 'sector': 'Organic Honey', 'website': 'rigonidiasiago.it'},
    {'name': 'Allos', 'country': 'DE', 'sector': 'Organic Food'},
    {'name': 'Sonnentor', 'country': 'AT', 'sector': 'Organic'},
    {'name': 'Mielizia', 'country': 'IT', 'sector': 'Italian Honey Coop'},

    # Packers/Traders
    {'name': 'Langnese Honig', 'country': 'DE', 'sector': 'Honey Packer'},
    {'name': 'Rowse Honey', 'country': 'GB', 'sector': 'Honey Brand'},
    {'name': 'Breitsamer Honig', 'country': 'DE', 'sector': 'Honey Packer'},
]


def fetch_argentina_apiario_data() -> List[dict]:
    """Fetch data from Argentina SENASA/datos.gob.ar."""
    apiarios = []

    try:
        url = SOURCES['AR']['api']
        resp = requests.get(url, timeout=30)
        data = resp.json()

        if 'result' in data and 'results' in data['result']:
            for dataset in data['result']['results']:
                if 'apicol' in dataset.get('title', '').lower() or 'miel' in dataset.get('title', '').lower():
                    apiarios.append({
                        'name': dataset.get('title'),
                        'country': 'AR',
                        'source': 'datos.gob.ar',
                        'dataset_id': dataset.get('id'),
                        'resources': len(dataset.get('resources', [])),
                    })
    except Exception as e:
        logger.warning(f"Argentina API error: {e}")

    return apiarios


def parse_exporter_to_company(data: dict) -> Company:
    """Convert exporter data to Company object."""
    return Company(
        name=data.get('name', ''),
        cui=data.get('tax_id', ''),
        country=data.get('country', ''),
        city=data.get('city', ''),
        address=data.get('address'),
        phone=data.get('phone'),
        email=data.get('email'),
        website=data.get('website'),
        sector='0149',  # Raising of other animals (beekeeping)
        sector_name=f"Honey - {data.get('sector', 'Beekeeping')}",
        employees_count=data.get('employees'),
        revenue=None,
        source=f"MERCOSUR_HONEY_{data.get('country', 'XX')}",
        source_file=data.get('source', 'MANUAL')
    )


def download_honey_exporters(country: str = 'ALL'):
    """Download honey exporter data."""
    all_exporters = []

    countries = [country.upper()] if country.upper() != 'ALL' else ['AR', 'UY', 'BR', 'CL']

    for cc in countries:
        if cc not in SOURCES:
            continue

        logger.info(f"Fetching {SOURCES[cc]['name']} honey exporters...")

        # Start with known exporters
        known = [e for e in HONEY_EXPORTERS if e['country'] == cc]
        all_exporters.extend(known)
        logger.info(f"  {len(known)} known exporters for {cc}")

        # Try to fetch additional data
        if cc == 'AR':
            api_data = fetch_argentina_apiario_data()
            logger.info(f"  {len(api_data)} datasets from API")

    # Save to file
    output_file = DATA_DIR / 'honey_exporters.json'
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(all_exporters, f, indent=2, ensure_ascii=False)

    logger.info(f"Saved {len(all_exporters)} honey exporters to {output_file}")

    # Save EU buyers reference
    buyers_file = DATA_DIR / 'eu_honey_buyers.json'
    with open(buyers_file, 'w', encoding='utf-8') as f:
        json.dump(EU_HONEY_BUYERS, f, indent=2, ensure_ascii=False)
    logger.info(f"Saved {len(EU_HONEY_BUYERS)} EU buyer references")

    return all_exporters


def import_honey_exporters(limit: int = 0, dry_run: bool = False):
    """Import honey exporters to database."""
    data_file = DATA_DIR / 'honey_exporters.json'

    if not data_file.exists():
        logger.info("No data file found, downloading...")
        download_honey_exporters('ALL')

    with open(data_file, 'r', encoding='utf-8') as f:
        exporters = json.load(f)

    logger.info(f"Importing {len(exporters)} honey exporters...")

    conn = None
    if not dry_run:
        conn = get_db()

    batch = []
    total = 0

    for exp in exporters:
        company = parse_exporter_to_company(exp)
        batch.append(company)

        if len(batch) >= BATCH_SIZE:
            if not dry_run:
                total += insert_companies(conn, batch)
            else:
                total += len(batch)
            batch = []

        if limit > 0 and total >= limit:
            break

    if batch:
        if not dry_run:
            total += insert_companies(conn, batch)
        else:
            total += len(batch)

    if conn:
        conn.close()

    action = "Would import" if dry_run else "Imported"
    logger.info(f"{action} {total} honey exporters")


def show_stats():
    """Show honey exporter stats."""
    print("\n" + "="*60)
    print("MERCOSUR HONEY EXPORTERS STATUS")
    print("="*60)

    # Show sources
    print("\nData Sources:")
    for cc, config in SOURCES.items():
        print(f"  {cc} - {config['name']}:")
        print(f"       Registry: {config['registry']}")
        print(f"       Production: {config['production']}")
        print(f"       Export: {config['export']}")

    # Local data
    data_file = DATA_DIR / 'honey_exporters.json'
    if data_file.exists():
        with open(data_file, 'r') as f:
            data = json.load(f)

        print(f"\nLocal data: {len(data)} exporters")

        by_country = {}
        organic_count = 0
        total_volume = 0

        for exp in data:
            cc = exp.get('country', 'XX')
            by_country[cc] = by_country.get(cc, 0) + 1

            if exp.get('organic'):
                organic_count += 1

            vol = exp.get('volume_tonnes', 0) or 0
            total_volume += vol

        print("\n  By country:")
        for cc, cnt in sorted(by_country.items()):
            print(f"    {cc}: {cnt}")

        print(f"\n  Organic certified: {organic_count}")
        print(f"  Known volume: {total_volume:,} tonnes/year")
    else:
        print("\nNo local data. Run --download first.")

    # Database stats
    print("\n" + "-"*60)
    print("DATABASE STATS")
    print("-"*60)

    try:
        conn = get_db()
        cur = conn.cursor()

        cur.execute("""
            SELECT country, COUNT(*)
            FROM companies
            WHERE source LIKE 'MERCOSUR_HONEY_%'
            GROUP BY country
        """)
        by_country = cur.fetchall()

        cur.execute("SELECT COUNT(*) FROM companies WHERE source LIKE 'MERCOSUR_HONEY_%'")
        total = cur.fetchone()[0]

        conn.close()

        print(f"  Total honey exporters: {total:,}")
        for cc, cnt in by_country:
            print(f"    {cc}: {cnt:,}")

    except Exception as e:
        print(f"  Database error: {e}")

    # Market info
    print("\n" + "-"*60)
    print("HONEY MARKET OVERVIEW")
    print("-"*60)
    print("  Argentina: 3rd world exporter (~65K tonnes/year)")
    print("  Uruguay: Premium organic market (~10K tonnes/year)")
    print("  Brazil: Growing exporter (~35K tonnes/year)")
    print("\n  Honey Types:")
    print("    - Multiflora (mixed): Most common")
    print("    - Clover: Premium, mild flavor")
    print("    - Eucalyptus: Strong flavor")
    print("    - Organic: 15-20% price premium")
    print("\n  EU Import: ~300K tonnes/year (main: China, Ukraine, AR)")
    print("  HS Code: 040900 (Natural honey)")
    print("\n  Certifications Required:")
    print("    - EU approved establishments")
    print("    - HACCP, BRC or equivalent")
    print("    - Residue testing (antibiotics, pesticides)")


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='MERCOSUR Honey Exporters')
    parser.add_argument('--stats', '-s', action='store_true', help='Show stats')
    parser.add_argument('--download', '-d', nargs='?', const='ALL', help='Download data (AR/UY/BR/CL/ALL)')
    parser.add_argument('--import', '-i', dest='do_import', action='store_true', help='Import to DB')
    parser.add_argument('--limit', '-l', type=int, default=0, help='Limit rows')
    parser.add_argument('--dry-run', '-n', action='store_true', help='Dry run')

    args = parser.parse_args()

    if args.download:
        download_honey_exporters(args.download)
    elif args.do_import:
        import_honey_exporters(limit=args.limit, dry_run=args.dry_run)
    else:
        show_stats()
