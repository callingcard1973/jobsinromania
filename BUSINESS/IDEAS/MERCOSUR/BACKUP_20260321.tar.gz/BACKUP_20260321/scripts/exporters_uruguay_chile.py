#!/usr/bin/env python3
"""Uruguay and Chile Exporter Directory"""

import sys
sys.path.insert(0, '/opt/ACTIVE/SCRAPERS/EUROPE/SCRIPTS/SHARED')

import argparse
import json
import logging
from pathlib import Path
from datetime import datetime

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s [%(name)s] %(message)s')
logger = logging.getLogger(__name__)

OUTPUT_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/mercosur_exporters')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def get_uruguay_exporters():
    """Uruguay major exporters"""
    return [
        # Beef
        {'name': 'Frigorifico Tacuarembo', 'country': 'UY', 'city': 'Tacuarembo', 'sector': 'Beef', 'website': 'tacuarembo.com.uy'},
        {'name': 'Frigorifico Las Piedras (Marfrig)', 'country': 'UY', 'city': 'Las Piedras', 'sector': 'Beef'},
        {'name': 'BPU - Breeders & Packers Uruguay', 'country': 'UY', 'city': 'Durazno', 'sector': 'Beef', 'website': 'bfrsa.com'},
        {'name': 'Frigorifico San Jacinto (NIREA)', 'country': 'UY', 'city': 'San Jacinto', 'sector': 'Beef', 'website': 'nirea.com.uy'},
        {'name': 'Frigorifico Canelones', 'country': 'UY', 'city': 'Canelones', 'sector': 'Beef'},
        {'name': 'Cledinor S.A.', 'country': 'UY', 'city': 'Salto', 'sector': 'Beef'},
        {'name': 'Frigorifico Carrasco', 'country': 'UY', 'city': 'Montevideo', 'sector': 'Beef', 'website': 'frigorificocarrasco.com'},
        {'name': 'Schneck S.A.', 'country': 'UY', 'city': 'Montevideo', 'sector': 'Beef'},
        # Dairy
        {'name': 'Conaprole', 'country': 'UY', 'city': 'Montevideo', 'sector': 'Dairy', 'website': 'conaprole.com.uy', 'employees': 5000},
        {'name': 'Lactalis Uruguay', 'country': 'UY', 'city': 'Montevideo', 'sector': 'Dairy', 'website': 'lactalis.com'},
        # Rice
        {'name': 'Saman', 'country': 'UY', 'city': 'Treinta y Tres', 'sector': 'Rice', 'website': 'saman.com.uy'},
        {'name': 'Coopar', 'country': 'UY', 'city': 'Treinta y Tres', 'sector': 'Rice', 'website': 'coopar.com.uy'},
        {'name': 'Glencore Uruguay (Arrozal 33)', 'country': 'UY', 'city': 'Treinta y Tres', 'sector': 'Rice'},
        # Soy/Grains
        {'name': 'Barraca Erro', 'country': 'UY', 'city': 'Montevideo', 'sector': 'Grains', 'website': 'barracaerro.com.uy'},
        {'name': 'Cereoil Uruguay', 'country': 'UY', 'city': 'Montevideo', 'sector': 'Grains'},
        # Wood/Pulp
        {'name': 'UPM Uruguay', 'country': 'UY', 'city': 'Fray Bentos', 'sector': 'Pulp', 'website': 'upm.com', 'employees': 3000},
        {'name': 'Montes del Plata', 'country': 'UY', 'city': 'Colonia', 'sector': 'Pulp', 'website': 'montesdelplata.com.uy'},
        # Wool
        {'name': 'Lanas Trinidad', 'country': 'UY', 'city': 'Trinidad', 'sector': 'Wool', 'website': 'lanastrinidad.com'},
        {'name': 'Tops Fray Marcos', 'country': 'UY', 'city': 'Florida', 'sector': 'Wool'},
        # Citrus
        {'name': 'Caputto', 'country': 'UY', 'city': 'Paysandu', 'sector': 'Citrus', 'website': 'caputto.com.uy'},
        {'name': 'Milagro', 'country': 'UY', 'city': 'Salto', 'sector': 'Citrus'},
    ]

def get_chile_exporters():
    """Chile major exporters"""
    return [
        # Copper/Mining
        {'name': 'Codelco', 'country': 'CL', 'city': 'Santiago', 'sector': 'Copper', 'website': 'codelco.com', 'employees': 70000},
        {'name': 'Antofagasta Minerals', 'country': 'CL', 'city': 'Santiago', 'sector': 'Copper', 'website': 'aminerals.cl'},
        {'name': 'BHP Chile', 'country': 'CL', 'city': 'Santiago', 'sector': 'Copper', 'website': 'bhp.com'},
        {'name': 'Anglo American Chile', 'country': 'CL', 'city': 'Santiago', 'sector': 'Copper', 'website': 'angloamerican.com'},
        {'name': 'Freeport McMoRan Chile', 'country': 'CL', 'city': 'Santiago', 'sector': 'Copper'},
        # Lithium
        {'name': 'SQM', 'country': 'CL', 'city': 'Santiago', 'sector': 'Lithium', 'website': 'sqm.com', 'employees': 7000},
        {'name': 'Albemarle Chile', 'country': 'CL', 'city': 'Santiago', 'sector': 'Lithium', 'website': 'albemarle.com'},
        # Salmon
        {'name': 'Empresas AquaChile', 'country': 'CL', 'city': 'Puerto Montt', 'sector': 'Salmon', 'website': 'aquachile.com'},
        {'name': 'Multiexport Foods', 'country': 'CL', 'city': 'Puerto Montt', 'sector': 'Salmon', 'website': 'multiexportfoods.com'},
        {'name': 'Cermaq Chile', 'country': 'CL', 'city': 'Puerto Montt', 'sector': 'Salmon', 'website': 'cermaq.com'},
        {'name': 'Australis Seafoods', 'country': 'CL', 'city': 'Puerto Montt', 'sector': 'Salmon', 'website': 'australis-seafoods.com'},
        {'name': 'Blumar', 'country': 'CL', 'city': 'Santiago', 'sector': 'Salmon/Seafood', 'website': 'blumar.com'},
        {'name': 'Camanchaca', 'country': 'CL', 'city': 'Santiago', 'sector': 'Salmon/Seafood', 'website': 'camanchaca.cl'},
        # Wine
        {'name': 'Concha y Toro', 'country': 'CL', 'city': 'Santiago', 'sector': 'Wine', 'website': 'conchaytoro.com', 'employees': 5000},
        {'name': 'VSPT Wine Group', 'country': 'CL', 'city': 'Santiago', 'sector': 'Wine', 'website': 'vspt.cl'},
        {'name': 'Santa Rita', 'country': 'CL', 'city': 'Santiago', 'sector': 'Wine', 'website': 'santarita.com'},
        {'name': 'Vina San Pedro', 'country': 'CL', 'city': 'Santiago', 'sector': 'Wine', 'website': 'sanpedro.cl'},
        {'name': 'Vina Errazuriz', 'country': 'CL', 'city': 'Aconcagua', 'sector': 'Wine', 'website': 'errazuriz.com'},
        # Fruits
        {'name': 'Dole Chile', 'country': 'CL', 'city': 'Santiago', 'sector': 'Fruits', 'website': 'dole.cl'},
        {'name': 'Del Monte Fresh Chile', 'country': 'CL', 'city': 'Santiago', 'sector': 'Fruits'},
        {'name': 'Agricola Garces', 'country': 'CL', 'city': 'OHiggins', 'sector': 'Fruits', 'website': 'garces.cl'},
        {'name': 'David del Curto', 'country': 'CL', 'city': 'Santiago', 'sector': 'Fruits', 'website': 'daviddelcurto.cl'},
        {'name': 'Copefrut', 'country': 'CL', 'city': 'Curico', 'sector': 'Fruits', 'website': 'copefrut.cl'},
        # Pulp/Wood
        {'name': 'CMPC', 'country': 'CL', 'city': 'Santiago', 'sector': 'Pulp/Paper', 'website': 'cmpc.com', 'employees': 18000},
        {'name': 'Arauco', 'country': 'CL', 'city': 'Santiago', 'sector': 'Pulp/Wood', 'website': 'arauco.cl', 'employees': 15000},
        # Food
        {'name': 'Agrosuper', 'country': 'CL', 'city': 'Rancagua', 'sector': 'Poultry/Pork', 'website': 'agrosuper.cl', 'employees': 20000},
        {'name': 'Carozzi', 'country': 'CL', 'city': 'Santiago', 'sector': 'Food', 'website': 'carozzi.cl'},
    ]

def download_all():
    """Download all exporters"""
    uy = get_uruguay_exporters()
    cl = get_chile_exporters()
    
    with open(OUTPUT_DIR / f'uruguay_exporters_{datetime.now():%Y%m%d}.json', 'w') as f:
        json.dump(uy, f, indent=2)
    logger.info(f"Saved {len(uy)} Uruguay exporters")
    
    with open(OUTPUT_DIR / f'chile_exporters_{datetime.now():%Y%m%d}.json', 'w') as f:
        json.dump(cl, f, indent=2)
    logger.info(f"Saved {len(cl)} Chile exporters")
    
    return uy + cl

def show_stats():
    """Show statistics"""
    for country in ['uruguay', 'chile']:
        files = list(OUTPUT_DIR.glob(f'{country}_exporters_*.json'))
        if files:
            latest = max(files, key=lambda p: p.stat().st_mtime)
            with open(latest) as f:
                data = json.load(f)
            print(f"\n{country.upper()}: {len(data)} exporters")
            sectors = {}
            for e in data:
                s = e.get('sector', 'Unknown')
                sectors[s] = sectors.get(s, 0) + 1
            for s, c in sorted(sectors.items(), key=lambda x: -x[1])[:10]:
                print(f"  {s}: {c}")

def import_to_db():
    """Import to database"""
    import psycopg2
    conn = psycopg2.connect(dbname='interjob_master', user='tudor')
    cur = conn.cursor()
    total = 0
    
    for country, code in [('uruguay', 'UY'), ('chile', 'CL')]:
        files = list(OUTPUT_DIR.glob(f'{country}_exporters_*.json'))
        if not files:
            continue
        latest = max(files, key=lambda p: p.stat().st_mtime)
        with open(latest) as f:
            data = json.load(f)
        for e in data:
            try:
                cur.execute("""
                    INSERT INTO companies (name, country, city, sector, website, source)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    ON CONFLICT (name, country) DO UPDATE SET sector=EXCLUDED.sector
                """, (e.get('name'), code, e.get('city'), e.get('sector'), e.get('website'), f'MERCOSUR_{code}_Exporters'))
                total += 1
            except Exception as ex:
                logger.warning(f"Error: {ex}")
    
    conn.commit()
    conn.close()
    logger.info(f"Imported {total} Uruguay+Chile exporters")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--stats', action='store_true')
    parser.add_argument('--download', action='store_true')
    parser.add_argument('--import', dest='do_import', action='store_true')
    args = parser.parse_args()
    if args.stats:
        show_stats()
    elif args.download:
        download_all()
    elif args.do_import:
        import_to_db()
    else:
        download_all()
