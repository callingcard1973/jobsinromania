#!/usr/bin/env python3
"""
Canada-EU (CETA) Sector Matcher

Matches Canadian exporters to EU buyers BY SECTOR.
Creates outreach-ready lists for trade facilitation.

Usage:
    python3 canada_eu_matcher.py --stats
    python3 canada_eu_matcher.py --commodity seafood
    python3 canada_eu_matcher.py --commodity all --campaign
    python3 canada_eu_matcher.py --scrape  # Fetch Canadian exporters

Output: /mnt/hdd/GLOBAL_DOWNLOADS/canada_eu/
"""

import sys
import os
import csv
import json
import argparse
import requests
from pathlib import Path
from datetime import datetime
from typing import List, Dict
import logging

sys.path.insert(0, '/opt/ACTIVE/DB/GLOBAL')
sys.path.insert(0, '/opt/ACTIVE/SCRAPERS/EUROPE/SCRIPTS/SHARED')

from base import get_db

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s [%(name)s] %(message)s')
logger = logging.getLogger(__name__)

# Directories
DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/canada_eu')
OUTPUT_DIR = DATA_DIR / 'matches'
DATA_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Supplier data files (will be created by scraper)
SUPPLIER_FILES = {
    'seafood': DATA_DIR / 'seafood_exporters.json',
    'aluminum': DATA_DIR / 'aluminum_exporters.json',
    'lumber': DATA_DIR / 'lumber_exporters.json',
    'minerals': DATA_DIR / 'minerals_exporters.json',
    'cleantech': DATA_DIR / 'cleantech_exporters.json',
    'agrifood': DATA_DIR / 'agrifood_exporters.json',
    'machinery': DATA_DIR / 'machinery_exporters.json',
}

# CETA Sector definitions with CPV codes and keywords
# Based on +378% aluminum, +163% ores, +89% vehicles growth
SECTOR_CONFIG = {
    'seafood': {
        'name': 'Seafood & Fishery Products',
        'description': 'Lobster, crab, salmon, shrimp - Canada #1 seafood exporter to EU',
        'cpv_codes': [
            '031',      # Fish and fishery products
            '032',      # Fish, crustaceans
            '151',      # Meat and fish
            '152',      # Processed fish
            '553',      # Restaurant services
            '554',      # Catering
        ],
        'hs_codes': ['0306', '0307', '0302', '0303', '0304'],  # Crustaceans, molluscs, fish
        'keywords': [
            'seafood', 'fish', 'salmon', 'lobster', 'crab', 'shrimp', 'shellfish',
            'restaurant', 'catering', 'food service', 'hotel', 'hospitality'
        ],
        'eu_target_countries': ['FR', 'ES', 'IT', 'DE', 'NL', 'BE', 'PT', 'DK'],
        'trade_growth': '+65%',
    },
    'aluminum': {
        'name': 'Aluminum & Non-Ferrous Metals',
        'description': 'Highest CETA growth sector (+378%)',
        'cpv_codes': [
            '142',      # Non-ferrous metals
            '273',      # Aluminum products
            '441',      # Metal structures
            '452',      # Building aluminum
            '341',      # Motor vehicles
        ],
        'hs_codes': ['7601', '7602', '7604', '7606', '7607'],  # Aluminum unwrought, waste, bars, plates
        'keywords': [
            'aluminum', 'aluminium', 'metal', 'alloy', 'extrusion', 'sheet metal',
            'automotive', 'construction', 'packaging', 'aerospace', 'transport'
        ],
        'eu_target_countries': ['DE', 'IT', 'FR', 'ES', 'PL', 'AT', 'BE', 'NL'],
        'trade_growth': '+378%',
    },
    'lumber': {
        'name': 'Wood & Lumber Products',
        'description': 'Softwood lumber, pulp, paper products',
        'cpv_codes': [
            '031',      # Wood raw
            '032',      # Worked wood
            '441',      # Wooden structures
            '452',      # Building materials
            '211',      # Paper
        ],
        'hs_codes': ['4407', '4409', '4418', '4703', '4704'],  # Lumber, mouldings, builders wood, pulp
        'keywords': [
            'wood', 'lumber', 'timber', 'softwood', 'plywood', 'pulp', 'paper',
            'construction', 'furniture', 'building materials', 'flooring'
        ],
        'eu_target_countries': ['DE', 'UK', 'FR', 'IT', 'NL', 'BE', 'ES', 'AT'],
        'trade_growth': '+45%',
    },
    'minerals': {
        'name': 'Ores, Minerals & Mining Products',
        'description': 'Potash, nickel, uranium, iron ore (+163% growth)',
        'cpv_codes': [
            '142',      # Metal ores
            '143',      # Mining products
            '144',      # Salt and potash
            '145',      # Coal and lignite
            '146',      # Uranium
        ],
        'hs_codes': ['2510', '2612', '2613', '2601', '2603'],  # Potash, uranium, thorium, iron, copper
        'keywords': [
            'mining', 'ore', 'mineral', 'potash', 'nickel', 'uranium', 'copper',
            'fertilizer', 'steel', 'nuclear', 'energy', 'raw materials'
        ],
        'eu_target_countries': ['DE', 'FR', 'BE', 'NL', 'ES', 'IT', 'PL', 'FI'],
        'trade_growth': '+163%',
    },
    'cleantech': {
        'name': 'Clean Technology & Renewables',
        'description': 'Solar, wind, hydrogen, batteries - duty-free under CETA',
        'cpv_codes': [
            '314',      # Batteries and accumulators
            '311',      # Electric motors
            '453',      # Building installations
            '713',      # Environmental services
            '903',      # Environment-related services
        ],
        'hs_codes': ['8541', '8502', '8504', '8419'],  # Semiconductors, generators, transformers, heat exchange
        'keywords': [
            'solar', 'wind', 'renewable', 'clean energy', 'hydrogen', 'battery',
            'electric', 'sustainable', 'green', 'environment', 'climate'
        ],
        'eu_target_countries': ['DE', 'DK', 'NL', 'SE', 'FR', 'ES', 'IT', 'AT'],
        'trade_growth': 'Duty-free',
    },
    'agrifood': {
        'name': 'Agricultural & Food Products',
        'description': 'Maple syrup, grains, canola, beef - 94% tariff-free',
        'cpv_codes': [
            '031',      # Agricultural products
            '033',      # Crops
            '151',      # Meat products
            '156',      # Grain mill products
            '158',      # Various food
        ],
        'hs_codes': ['1702', '1205', '1001', '0201', '0202'],  # Maple sugar, rapeseed, wheat, beef
        'keywords': [
            'maple', 'grain', 'wheat', 'canola', 'rapeseed', 'beef', 'pork',
            'organic', 'food', 'agriculture', 'farm', 'natural'
        ],
        'eu_target_countries': ['DE', 'FR', 'IT', 'NL', 'BE', 'ES', 'PL', 'UK'],
        'trade_growth': '+24%',
    },
    'machinery': {
        'name': 'Machinery & Equipment',
        'description': 'Industrial machinery, vehicles, parts (+89% auto growth)',
        'cpv_codes': [
            '291',      # Agricultural machinery
            '341',      # Motor vehicles
            '421',      # Lifting equipment
            '422',      # Machine tools
            '425',      # Industrial machinery
        ],
        'hs_codes': ['8429', '8430', '8431', '8701', '8704'],  # Construction machinery, tractors, trucks
        'keywords': [
            'machinery', 'equipment', 'vehicle', 'truck', 'tractor', 'excavator',
            'industrial', 'manufacturing', 'automotive', 'parts', 'components'
        ],
        'eu_target_countries': ['DE', 'FR', 'IT', 'PL', 'ES', 'NL', 'BE', 'AT'],
        'trade_growth': '+89%',
    },
}


def load_suppliers(commodity: str) -> List[Dict]:
    """Load Canadian suppliers from JSON file."""
    filepath = SUPPLIER_FILES.get(commodity)
    if not filepath or not filepath.exists():
        logger.warning(f"Supplier file not found: {filepath}")
        return []

    with open(filepath) as f:
        suppliers = json.load(f)

    # Filter active suppliers
    active = [s for s in suppliers if s.get('status', '').lower() in
              ['active', 'operating', 'verified', '']]

    logger.info(f"Loaded {len(active)} active {commodity} suppliers from Canada")
    return active


def query_eu_buyers(commodity: str, limit: int = 2000) -> List[Dict]:
    """Query TED winners for EU buyers in this sector."""
    config = SECTOR_CONFIG.get(commodity)
    if not config:
        logger.error(f"Unknown commodity: {commodity}")
        return []

    conn = get_db()
    cur = conn.cursor()

    # Build CPV filter
    cpv_conditions = []
    for cpv in config['cpv_codes']:
        cpv_conditions.append(f"cpv LIKE '{cpv}%'")
    cpv_filter = ' OR '.join(cpv_conditions)

    # Build keyword filter
    keyword_conditions = []
    for kw in config['keywords'][:10]:
        keyword_conditions.append(f"LOWER(contractor) LIKE '%{kw.lower()}%'")
    keyword_filter = ' OR '.join(keyword_conditions)

    query = f"""
        SELECT DISTINCT ON (contractor_email)
            contractor,
            contractor_country,
            contractor_email,
            contractor_website,
            contractor_city,
            cpv,
            COALESCE(SUM(NULLIF(contract_value, '')::numeric), 0) as total_value,
            COUNT(*) as contract_count
        FROM ted_winners
        WHERE contractor_email IS NOT NULL
          AND contractor_email != ''
          AND LENGTH(contractor_email) > 5
          AND contractor_email !~ '^[0-9]+@'
          AND contractor_email !~ '^(test|example|noreply|no-reply|info@example)'
          AND contractor_email LIKE '%@%.%'
          AND (
              ({cpv_filter})
              OR ({keyword_filter})
          )
        GROUP BY contractor, contractor_country, contractor_email,
                 contractor_website, contractor_city, cpv
        ORDER BY contractor_email, total_value DESC NULLS LAST
        LIMIT {limit}
    """

    try:
        cur.execute(query)
        rows = cur.fetchall()

        buyers = []
        seen_emails = set()

        for row in rows:
            email = row[2]
            if email and email.lower() not in seen_emails:
                seen_emails.add(email.lower())
                buyers.append({
                    'company': row[0],
                    'country': row[1],
                    'email': email,
                    'website': row[3],
                    'city': row[4],
                    'cpv': row[5],
                    'total_contract_value': float(row[6]) if row[6] else 0,
                    'contract_count': row[7],
                })

        logger.info(f"Found {len(buyers)} unique EU buyers for {commodity}")
        return buyers

    except Exception as e:
        logger.error(f"Query error: {e}")
        import traceback
        traceback.print_exc()
        return []
    finally:
        conn.close()


def scrape_canadian_exporters():
    """
    Fetch Canadian exporters from public sources.
    Uses Canadian Trade Commissioner Service data.
    """
    logger.info("Scraping Canadian exporter data...")

    # Canadian Trade Commissioner sectors
    sectors = {
        'seafood': {
            'search_terms': ['seafood', 'fish', 'lobster', 'salmon'],
            'provinces': ['NS', 'NB', 'BC', 'NL', 'PE'],
        },
        'aluminum': {
            'search_terms': ['aluminum', 'metal', 'smelter'],
            'provinces': ['QC', 'BC', 'ON'],
        },
        'lumber': {
            'search_terms': ['lumber', 'wood', 'forestry', 'pulp'],
            'provinces': ['BC', 'QC', 'ON', 'AB'],
        },
        'minerals': {
            'search_terms': ['mining', 'minerals', 'potash', 'nickel'],
            'provinces': ['SK', 'ON', 'QC', 'BC', 'AB'],
        },
        'cleantech': {
            'search_terms': ['cleantech', 'solar', 'renewable', 'hydrogen'],
            'provinces': ['ON', 'QC', 'BC', 'AB'],
        },
        'agrifood': {
            'search_terms': ['maple', 'agriculture', 'grain', 'food'],
            'provinces': ['QC', 'ON', 'MB', 'SK', 'AB'],
        },
        'machinery': {
            'search_terms': ['machinery', 'equipment', 'automotive'],
            'provinces': ['ON', 'QC', 'AB', 'BC'],
        },
    }

    # Known major Canadian exporters (seed data)
    seed_exporters = {
        'seafood': [
            {'name': 'Clearwater Seafoods', 'city': 'Halifax', 'province': 'NS',
             'website': 'clearwater.ca', 'products': 'Lobster, scallops, crab', 'status': 'active'},
            {'name': 'High Liner Foods', 'city': 'Lunenburg', 'province': 'NS',
             'website': 'highlinerfoods.com', 'products': 'Frozen seafood', 'status': 'active'},
            {'name': 'Cooke Aquaculture', 'city': 'Blacks Harbour', 'province': 'NB',
             'website': 'cookeseafood.com', 'products': 'Salmon, sea bass', 'status': 'active'},
            {'name': 'Ocean Choice International', 'city': 'St. Johns', 'province': 'NL',
             'website': 'oceanchoice.com', 'products': 'Shrimp, crab, turbot', 'status': 'active'},
            {'name': 'Grieg Seafood BC', 'city': 'Campbell River', 'province': 'BC',
             'website': 'griegseafood.com', 'products': 'Atlantic salmon', 'status': 'active'},
        ],
        'aluminum': [
            {'name': 'Rio Tinto Alcan', 'city': 'Montreal', 'province': 'QC',
             'website': 'riotinto.com', 'products': 'Primary aluminum', 'status': 'active'},
            {'name': 'Alcoa Canada', 'city': 'Baie-Comeau', 'province': 'QC',
             'website': 'alcoa.com', 'products': 'Aluminum ingots', 'status': 'active'},
            {'name': 'Novelis', 'city': 'Kingston', 'province': 'ON',
             'website': 'novelis.com', 'products': 'Rolled aluminum', 'status': 'active'},
            {'name': 'Alouette', 'city': 'Sept-Iles', 'province': 'QC',
             'website': 'alouette.com', 'products': 'Primary aluminum', 'status': 'active'},
        ],
        'lumber': [
            {'name': 'West Fraser Timber', 'city': 'Vancouver', 'province': 'BC',
             'website': 'westfraser.com', 'products': 'Lumber, panels, pulp', 'status': 'active'},
            {'name': 'Canfor Corporation', 'city': 'Vancouver', 'province': 'BC',
             'website': 'canfor.com', 'products': 'Softwood lumber', 'status': 'active'},
            {'name': 'Resolute Forest Products', 'city': 'Montreal', 'province': 'QC',
             'website': 'resolutefp.com', 'products': 'Pulp, paper, wood', 'status': 'active'},
            {'name': 'Mercer International', 'city': 'Vancouver', 'province': 'BC',
             'website': 'mercerint.com', 'products': 'Pulp products', 'status': 'active'},
        ],
        'minerals': [
            {'name': 'Nutrien', 'city': 'Saskatoon', 'province': 'SK',
             'website': 'nutrien.com', 'products': 'Potash, nitrogen', 'status': 'active'},
            {'name': 'Teck Resources', 'city': 'Vancouver', 'province': 'BC',
             'website': 'teck.com', 'products': 'Copper, zinc, coal', 'status': 'active'},
            {'name': 'Vale Canada', 'city': 'Toronto', 'province': 'ON',
             'website': 'vale.com', 'products': 'Nickel, copper', 'status': 'active'},
            {'name': 'Cameco Corporation', 'city': 'Saskatoon', 'province': 'SK',
             'website': 'cameco.com', 'products': 'Uranium', 'status': 'active'},
        ],
        'cleantech': [
            {'name': 'Ballard Power Systems', 'city': 'Burnaby', 'province': 'BC',
             'website': 'ballard.com', 'products': 'Fuel cells', 'status': 'active'},
            {'name': 'Canadian Solar', 'city': 'Guelph', 'province': 'ON',
             'website': 'canadiansolar.com', 'products': 'Solar panels', 'status': 'active'},
            {'name': 'Loop Energy', 'city': 'Burnaby', 'province': 'BC',
             'website': 'loopenergy.com', 'products': 'Hydrogen fuel cells', 'status': 'active'},
            {'name': 'Hydrogenics (Cummins)', 'city': 'Mississauga', 'province': 'ON',
             'website': 'cummins.com', 'products': 'Electrolyzers', 'status': 'active'},
        ],
        'agrifood': [
            {'name': 'Citadelle Maple Syrup', 'city': 'Plessisville', 'province': 'QC',
             'website': 'citadelle-camp.coop', 'products': 'Maple syrup', 'status': 'active'},
            {'name': 'Richardson International', 'city': 'Winnipeg', 'province': 'MB',
             'website': 'richardson.ca', 'products': 'Grain, oilseeds', 'status': 'active'},
            {'name': 'Viterra', 'city': 'Regina', 'province': 'SK',
             'website': 'viterra.com', 'products': 'Grains, oilseeds', 'status': 'active'},
            {'name': 'Maple Leaf Foods', 'city': 'Mississauga', 'province': 'ON',
             'website': 'mapleleaffoods.com', 'products': 'Meat products', 'status': 'active'},
        ],
        'machinery': [
            {'name': 'Magna International', 'city': 'Aurora', 'province': 'ON',
             'website': 'magna.com', 'products': 'Auto parts', 'status': 'active'},
            {'name': 'Linamar Corporation', 'city': 'Guelph', 'province': 'ON',
             'website': 'linamar.com', 'products': 'Powertrain, machinery', 'status': 'active'},
            {'name': 'Finning International', 'city': 'Vancouver', 'province': 'BC',
             'website': 'finning.com', 'products': 'Heavy equipment', 'status': 'active'},
            {'name': 'Toromont Industries', 'city': 'Concord', 'province': 'ON',
             'website': 'toromont.com', 'products': 'Industrial equipment', 'status': 'active'},
        ],
    }

    # Save seed data
    for sector, exporters in seed_exporters.items():
        for exp in exporters:
            exp['country'] = 'CA'
            exp['source'] = 'seed_data'
            exp['scraped_date'] = datetime.now().isoformat()

        filepath = SUPPLIER_FILES[sector]
        with open(filepath, 'w') as f:
            json.dump(exporters, f, indent=2)
        logger.info(f"Saved {len(exporters)} {sector} exporters to {filepath}")

    return seed_exporters


def export_campaign_csv(commodity: str, output_file: Path = None, buyer_limit: int = 500):
    """Export campaign-ready CSV with unique buyers and supplier summary."""
    suppliers = load_suppliers(commodity)
    buyers = query_eu_buyers(commodity, buyer_limit)

    if not buyers:
        logger.warning(f"No buyers for {commodity} campaign")
        return

    if not output_file:
        output_file = OUTPUT_DIR / f"campaign_{commodity}_{datetime.now():%Y%m%d}.csv"

    # Build supplier summary
    supplier_count = len(suppliers)
    supplier_provinces = list(set(s.get('province', '') for s in suppliers))
    top_suppliers = [s.get('name', '') for s in suppliers[:5]]

    config = SECTOR_CONFIG[commodity]

    # Prepare campaign rows
    campaign_rows = []
    for buyer in buyers:
        row = {
            'email': buyer['email'],
            'company': buyer['company'],
            'country': buyer['country'],
            'city': buyer.get('city', ''),
            'website': buyer.get('website', ''),
            'contract_value_eur': int(buyer.get('total_contract_value', 0)),

            # Template variables
            'commodity': config['name'],
            'commodity_short': commodity,
            'trade_agreement': 'CETA',
            'tariff_benefit': config.get('trade_growth', 'Duty-free'),
            'supplier_count': supplier_count,
            'supplier_provinces': ', '.join(supplier_provinces),
            'top_suppliers': ', '.join(top_suppliers[:3]),
        }
        campaign_rows.append(row)

    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=campaign_rows[0].keys())
        writer.writeheader()
        writer.writerows(campaign_rows)

    logger.info(f"Campaign CSV: {len(campaign_rows)} contacts -> {output_file}")
    return output_file


def show_stats(commodity: str = None):
    """Show matching statistics."""
    print("\n" + "="*70)
    print("CANADA-EU (CETA) SECTOR MATCHER STATISTICS")
    print("="*70)

    commodities = [commodity] if commodity and commodity != 'all' else SECTOR_CONFIG.keys()

    total_suppliers = 0
    total_buyers = 0
    total_matches = 0

    for comm in commodities:
        config = SECTOR_CONFIG[comm]
        suppliers = load_suppliers(comm)
        buyers = query_eu_buyers(comm, limit=5000)

        supplier_count = len(suppliers)
        buyer_count = len(buyers)
        match_count = supplier_count * buyer_count

        total_suppliers += supplier_count
        total_buyers += buyer_count
        total_matches += match_count

        print(f"\n{config['name'].upper()} ({config.get('trade_growth', '')})")
        print("-" * 40)
        print(f"  Canadian Suppliers: {supplier_count:,}")
        print(f"  EU Buyers:          {buyer_count:,}")
        print(f"  Total Matches:      {match_count:,}")

        # Top buyer countries
        country_counts = {}
        for b in buyers:
            c = b.get('country', 'N/A')
            country_counts[c] = country_counts.get(c, 0) + 1
        top_countries = sorted(country_counts.items(), key=lambda x: -x[1])[:5]
        print(f"  Top EU Countries:   {', '.join(f'{c}:{n}' for c,n in top_countries)}")

        # Value stats
        total_value = sum(b.get('total_contract_value', 0) for b in buyers)
        if total_value:
            print(f"  Buyer Value:        EUR {total_value/1e9:.2f}B")

    print("\n" + "="*70)
    print(f"TOTALS: {total_suppliers} suppliers x {total_buyers} buyers = {total_matches:,} matches")
    print("="*70 + "\n")


def main():
    parser = argparse.ArgumentParser(description='Canada-EU (CETA) Sector Matcher')
    parser.add_argument('--commodity', '-c',
                        choices=['seafood', 'aluminum', 'lumber', 'minerals',
                                 'cleantech', 'agrifood', 'machinery', 'all'],
                        help='Commodity to match')
    parser.add_argument('--stats', '-s', action='store_true', help='Show statistics')
    parser.add_argument('--campaign', action='store_true', help='Export campaign CSV')
    parser.add_argument('--scrape', action='store_true', help='Scrape Canadian exporters')
    parser.add_argument('--limit', '-l', type=int, default=500, help='Buyer limit')
    parser.add_argument('--output', '-o', type=str, help='Output file path')

    args = parser.parse_args()

    if args.scrape:
        scrape_canadian_exporters()
        return

    if args.stats:
        show_stats(args.commodity)
        return

    if not args.commodity:
        parser.print_help()
        print("\n\nExamples:")
        print("  python3 canada_eu_matcher.py --scrape")
        print("  python3 canada_eu_matcher.py --stats")
        print("  python3 canada_eu_matcher.py --commodity seafood --campaign")
        print("  python3 canada_eu_matcher.py --commodity all --campaign")
        return

    commodities = list(SECTOR_CONFIG.keys()) if args.commodity == 'all' else [args.commodity]

    for commodity in commodities:
        if args.campaign:
            output = Path(args.output) if args.output else None
            export_campaign_csv(commodity, output, args.limit)
        else:
            # Just show match count
            suppliers = load_suppliers(commodity)
            buyers = query_eu_buyers(commodity, args.limit)
            print(f"\n{commodity.upper()}: {len(suppliers)} suppliers x {len(buyers)} buyers")


if __name__ == '__main__':
    main()
