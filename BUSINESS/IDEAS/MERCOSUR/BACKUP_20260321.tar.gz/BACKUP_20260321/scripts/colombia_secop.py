#!/usr/bin/env python3
"""
Colombia SECOP Procurement Scraper
Fetches procurement data from Colombia Compra Eficiente portal.

API: https://www.colombiacompra.gov.co/secop-ii
Data: https://www.datos.gov.co/

Usage:
    python3 colombia_secop.py --stats
    python3 colombia_secop.py --fetch --limit 1000
    python3 colombia_secop.py --winners
"""

import sys
import json
import csv
import requests
from pathlib import Path
from datetime import datetime
from typing import List
import logging
import time

sys.path.insert(0, '/opt/ACTIVE/DB/GLOBAL')
from base import get_db, sanitize, BATCH_SIZE

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/colombia_secop')
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Colombia datos.gov.co CKAN API
DATOS_API = "https://www.datos.gov.co/api/3/action"
# SECOP II data on Socrata
SOCRATA_BASE = "https://www.datos.gov.co/resource"
# Updated dataset IDs (2026)
SECOP_DATASETS = {
    'contratos': 'jbjy-vk9h',     # SECOP II - Contratos Electrónicos
    'integrado': 'rpmr-utcd',     # SECOP Integrado
}
SECOP_DATASET = SECOP_DATASETS['contratos']
REQUEST_DELAY = 1.0


def fetch_socrata_data(dataset: str = SECOP_DATASET, limit: int = 1000, offset: int = 0) -> List[dict]:
    """Fetch data from Socrata API."""
    url = f"{SOCRATA_BASE}/{dataset}.json"
    params = {
        '$limit': limit,
        '$offset': offset,
        '$order': 'fecha_de_firma DESC',
    }
    try:
        resp = requests.get(url, params=params, timeout=60)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        logger.error(f"Socrata error: {e}")
        return []


def search_procurement_datasets() -> List[dict]:
    """Search for procurement datasets on datos.gov.co."""
    url = f"{DATOS_API}/package_search"
    params = {'q': 'secop contratacion', 'rows': 20}
    try:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()
        return data.get('result', {}).get('results', [])
    except Exception as e:
        logger.error(f"Search error: {e}")
        return []


def fetch_all_contracts(max_records: int = 5000) -> List[dict]:
    """Fetch contracts with pagination."""
    all_records = []
    offset = 0
    batch_size = 1000

    while len(all_records) < max_records:
        logger.info(f"Fetching offset {offset}...")
        records = fetch_socrata_data(SECOP_DATASET, batch_size, offset)

        if not records:
            break

        all_records.extend(records)
        offset += batch_size
        time.sleep(REQUEST_DELAY)

        if len(records) < batch_size:
            break

    return all_records[:max_records]


def extract_winners(records: List[dict]) -> List[dict]:
    """Extract winning companies from SECOP II data."""
    winners = []
    seen = set()
    for r in records:
        name = r.get('proveedor_adjudicado', '')
        nit = r.get('documento_proveedor', '')

        if not name or nit in seen:
            continue
        seen.add(nit)

        winners.append({
            'name': sanitize(str(name)),
            'nit': str(nit) if nit else '',
            'country': 'CO',
            'contract_value': r.get('valor_del_contrato', ''),
            'contract_date': r.get('fecha_de_inicio_del_contrato', '')[:10] if r.get('fecha_de_inicio_del_contrato') else '',
            'buyer': r.get('nombre_entidad', ''),
            'description': sanitize(str(r.get('objeto_del_contrato', '')))[:500],
            'contract_id': r.get('id_contrato', ''),
        })
    return winners


def save_winners(winners: List[dict]):
    """Save winners to CSV."""
    output_file = DATA_DIR / f'colombia_winners_{datetime.now():%Y%m%d}.csv'
    if winners:
        # Dedupe by NIT
        seen = set()
        unique = []
        for w in winners:
            if w['nit'] and w['nit'] not in seen:
                seen.add(w['nit'])
                unique.append(w)
            elif not w['nit']:
                unique.append(w)

        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=unique[0].keys())
            writer.writeheader()
            writer.writerows(unique)
        logger.info(f"Saved {len(unique)} unique winners to {output_file}")
    return unique if winners else []


def import_to_db(winners: List[dict], dry_run: bool = False):
    """Import suppliers to database."""
    if dry_run:
        logger.info(f"Would import {len(winners)} suppliers")
        return

    conn = get_db()
    cur = conn.cursor()
    inserted = 0

    for w in winners:
        try:
            cur.execute("""
                INSERT INTO companies (name, cui, country, source, source_file)
                VALUES (%s, %s, %s, %s, %s)
                ON CONFLICT DO NOTHING
            """, (w['name'], w.get('nit', ''), 'CO', 'CO_SECOP', 'colombia_secop.py'))
            inserted += 1
        except Exception as e:
            logger.warning(f"Insert error: {e}")

    conn.commit()
    conn.close()
    logger.info(f"Imported {inserted} companies")


def show_stats():
    """Show stats."""
    print("\n" + "="*60)
    print("COLOMBIA SECOP STATUS")
    print("="*60)

    # Search datasets
    print("\nProcurement datasets on datos.gov.co:")
    datasets = search_procurement_datasets()
    for ds in datasets[:5]:
        title = ds.get('title', '')[:50]
        print(f"  - {title}...")

    # Test Socrata API
    print("\nSECOP II API Test:")
    records = fetch_socrata_data(SECOP_DATASET, 5)
    if records:
        print(f"  Sample records: {len(records)}")
        if records:
            r = records[0]
            print(f"  Sample: {r.get('objeto_del_contrato', r.get('descripci_n_del_proceso', ''))[:50]}...")
    else:
        print("  API not responding")

    # Local data
    print(f"\nLocal data: {DATA_DIR}")
    csvs = list(DATA_DIR.glob('*.csv'))
    for f in csvs[-3:]:
        lines = sum(1 for _ in open(f)) - 1
        print(f"  {f.name}: {lines:,} records")

    # DB stats
    print("\nDatabase:")
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM companies WHERE source = 'CO_SECOP'")
        print(f"  CO_SECOP companies: {cur.fetchone()[0]:,}")
        conn.close()
    except Exception as e:
        print(f"  DB error: {e}")


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Colombia SECOP Scraper')
    parser.add_argument('--stats', '-s', action='store_true')
    parser.add_argument('--fetch', '-f', action='store_true')
    parser.add_argument('--winners', '-w', action='store_true')
    parser.add_argument('--import', '-i', dest='do_import', action='store_true')
    parser.add_argument('--limit', '-l', type=int, default=1000)
    parser.add_argument('--dry-run', '-n', action='store_true')

    args = parser.parse_args()

    if args.fetch or args.winners:
        records = fetch_all_contracts(args.limit)
        logger.info(f"Fetched {len(records)} contracts")

        with open(DATA_DIR / f'contracts_{datetime.now():%Y%m%d}.json', 'w') as f:
            json.dump(records, f, indent=2, default=str)

        if args.winners:
            winners = extract_winners(records)
            unique = save_winners(winners)

            if args.do_import and unique:
                import_to_db(unique, args.dry_run)
    else:
        show_stats()
