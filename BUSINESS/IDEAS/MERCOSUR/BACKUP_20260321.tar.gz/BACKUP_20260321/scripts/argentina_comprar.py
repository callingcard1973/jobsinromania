#!/usr/bin/env python3
"""
Argentina Comprar.gob.ar Procurement Scraper
Fetches procurement data from Argentina's government portal.

API: https://comprar.gob.ar/PLIEGO/Search
Docs: https://datos.gob.ar/

Usage:
    python3 argentina_comprar.py --stats
    python3 argentina_comprar.py --fetch --limit 1000
    python3 argentina_comprar.py --winners
"""

import sys
import json
import csv
import requests
from pathlib import Path
from datetime import datetime
from typing import List
import logging
import time

sys.path.insert(0, '/opt/ACTIVE/DB/GLOBAL')
from base import get_db, sanitize, BATCH_SIZE

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DATA_DIR = Path('/mnt/hdd/GLOBAL_DOWNLOADS/argentina_comprar')
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Argentina Comprar API / datos.gob.ar
DATOS_API = "https://datos.gob.ar/api/3/action"
COMPRAR_SEARCH = "https://comprar.gob.ar/PLIEGO/Search"
REQUEST_DELAY = 1.5

# Direct CSV downloads for adjudicaciones by year
ADJUDICACIONES_URLS = {
    2020: "https://infra.datos.gob.ar/catalog/jgm/dataset/4/distribution/4.20/download/adjudicaciones-2020.csv",
    2019: "https://infra.datos.gob.ar/catalog/modernizacion/dataset/2/distribution/2.18/download/adjudicaciones-2019.csv",
    2018: "https://infra.datos.gob.ar/catalog/modernizacion/dataset/2/distribution/2.15/download/adjudicaciones-2018.csv",
    2017: "https://infra.datos.gob.ar/catalog/modernizacion/dataset/2/distribution/2.2/download/adjudicaciones-2017.csv",
}


def search_datos_gob(query: str = "contrataciones") -> List[dict]:
    """Search datos.gob.ar for procurement datasets."""
    url = f"{DATOS_API}/package_search"
    params = {'q': query, 'rows': 50}
    try:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()
        return data.get('result', {}).get('results', [])
    except Exception as e:
        logger.error(f"API error: {e}")
        return []


def fetch_comprar_tenders(page: int = 1, size: int = 50) -> dict:
    """Fetch tenders from comprar.gob.ar."""
    # Comprar uses a search form - simulate search
    headers = {
        'User-Agent': 'Mozilla/5.0',
        'Accept': 'application/json',
    }
    params = {
        'page': page,
        'pageSize': size,
        'estado': 'Adjudicado',  # Awarded contracts
    }
    try:
        resp = requests.get(COMPRAR_SEARCH, params=params, headers=headers, timeout=30)
        if resp.status_code == 200:
            return resp.json() if resp.headers.get('content-type', '').startswith('application/json') else {}
        logger.warning(f"Comprar returned {resp.status_code}")
        return {}
    except Exception as e:
        logger.error(f"Comprar error: {e}")
        return {}


def fetch_adjudicaciones(years: List[int] = None) -> List[dict]:
    """Fetch adjudicaciones directly from CSV files."""
    if years is None:
        years = [2020, 2019, 2018, 2017]

    all_records = []
    for year in years:
        url = ADJUDICACIONES_URLS.get(year)
        if not url:
            continue

        logger.info(f"Fetching adjudicaciones {year}...")
        try:
            resp = requests.get(url, timeout=120)
            resp.encoding = 'utf-8'
            import io
            reader = csv.DictReader(io.StringIO(resp.text))
            records = list(reader)
            all_records.extend(records)
            logger.info(f"  Got {len(records)} records")
            time.sleep(REQUEST_DELAY)
        except Exception as e:
            logger.error(f"  Error: {e}")

    return all_records


def fetch_from_datos_resources(limit: int = 1000) -> List[dict]:
    """Fetch actual data from datos.gob.ar resources."""
    records = []
    datasets = search_datos_gob("contrataciones publicas")

    for ds in datasets[:5]:
        resources = ds.get('resources', [])
        for res in resources:
            if res.get('format', '').upper() in ['CSV', 'JSON']:
                url = res.get('url')
                if url:
                    try:
                        logger.info(f"Fetching {res.get('name', url[:50])}...")
                        resp = requests.get(url, timeout=60)
                        if res['format'].upper() == 'JSON':
                            data = resp.json()
                            if isinstance(data, list):
                                records.extend(data[:limit])
                        time.sleep(REQUEST_DELAY)
                    except Exception as e:
                        logger.warning(f"Resource error: {e}")

                if len(records) >= limit:
                    break
        if len(records) >= limit:
            break

    return records[:limit]


def extract_winners(records: List[dict]) -> List[dict]:
    """Extract winning companies from adjudicaciones CSV."""
    winners = []
    seen = set()
    for r in records:
        # Use actual field names from adjudicaciones CSV
        name = r.get('Descripción Proveedor', r.get('proveedor', ''))
        cuit = r.get('CUIT', r.get('cuit', ''))
        if not name:
            continue

        # Dedupe by CUIT
        if cuit in seen:
            continue
        seen.add(cuit)

        winners.append({
            'name': sanitize(str(name)),
            'cuit': str(cuit) if cuit else '',
            'country': 'AR',
            'contract_value': r.get('Monto', r.get('monto', '')),
            'buyer': r.get('Descripcion SAF', '')[:100],
            'procedure': r.get('Tipo de Procedimiento', ''),
        })
    return winners


def save_winners(winners: List[dict]):
    """Save winners to CSV."""
    output_file = DATA_DIR / f'argentina_winners_{datetime.now():%Y%m%d}.csv'
    if winners:
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=winners[0].keys())
            writer.writeheader()
            writer.writerows(winners)
        logger.info(f"Saved {len(winners)} winners to {output_file}")


def show_stats():
    """Show stats."""
    print("\n" + "="*60)
    print("ARGENTINA COMPRAR.GOB.AR STATUS")
    print("="*60)

    # Search datos.gob.ar
    print("\nDatos.gob.ar datasets:")
    datasets = search_datos_gob("contrataciones")
    for ds in datasets[:5]:
        title = ds.get('title', '')[:50]
        resources = len(ds.get('resources', []))
        print(f"  - {title}... ({resources} resources)")

    # Test Comprar API
    print("\nComprar.gob.ar API:")
    data = fetch_comprar_tenders(1, 5)
    if data:
        print(f"  Response: {len(data)} items")
    else:
        print("  API requires browser session")

    # Local data
    print(f"\nLocal data: {DATA_DIR}")
    csvs = list(DATA_DIR.glob('*.csv'))
    for f in csvs[-3:]:
        lines = sum(1 for _ in open(f)) - 1
        print(f"  {f.name}: {lines:,} records")

    # DB stats
    print("\nDatabase:")
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM companies WHERE source = 'AR_Comprar'")
        print(f"  AR_Comprar companies: {cur.fetchone()[0]:,}")
        conn.close()
    except Exception as e:
        print(f"  DB error: {e}")


def import_to_db(winners: List[dict], dry_run: bool = False):
    """Import suppliers to database."""
    if dry_run:
        logger.info(f"Would import {len(winners)} suppliers")
        return

    conn = get_db()
    cur = conn.cursor()

    inserted = 0
    for w in winners:
        try:
            cur.execute("""
                INSERT INTO companies (name, cui, country, source, source_file)
                VALUES (%s, %s, %s, %s, %s)
                ON CONFLICT DO NOTHING
            """, (w['name'], w.get('cuit', ''), 'AR', 'AR_Comprar', 'argentina_comprar.py'))
            inserted += 1
        except Exception as e:
            logger.warning(f"Insert error: {e}")

    conn.commit()
    conn.close()
    logger.info(f"Imported {inserted} companies")


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Argentina Comprar Scraper')
    parser.add_argument('--stats', '-s', action='store_true')
    parser.add_argument('--adjudicaciones', '-a', action='store_true', help='Fetch adjudicaciones CSV')
    parser.add_argument('--fetch', '-f', action='store_true')
    parser.add_argument('--import', '-i', dest='do_import', action='store_true')
    parser.add_argument('--years', '-y', nargs='+', type=int, default=[2020, 2019, 2018, 2017])
    parser.add_argument('--dry-run', '-n', action='store_true')

    args = parser.parse_args()

    if args.adjudicaciones:
        records = fetch_adjudicaciones(args.years)
        logger.info(f"Fetched {len(records)} adjudicaciones records")

        with open(DATA_DIR / f'adjudicaciones_{datetime.now():%Y%m%d}.json', 'w') as f:
            json.dump(records, f, indent=2, default=str, ensure_ascii=False)

        winners = extract_winners(records)
        save_winners(winners)

        if args.do_import:
            import_to_db(winners, args.dry_run)

    elif args.fetch:
        records = fetch_from_datos_resources(1000)
        logger.info(f"Fetched {len(records)} records")

        with open(DATA_DIR / f'contracts_{datetime.now():%Y%m%d}.json', 'w') as f:
            json.dump(records, f, indent=2, default=str)
    else:
        show_stats()
